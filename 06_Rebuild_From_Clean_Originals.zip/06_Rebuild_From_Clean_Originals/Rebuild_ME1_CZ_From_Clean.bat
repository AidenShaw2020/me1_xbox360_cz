﻿@echo off
chcp 65001 >nul
set /p GAME=Koren ciste Xbox 360 hry: 
set /p PC=Koren pocestene PC hry: 
set /p BDTS=Originalni kontejner Bring Down the Sky: 
set /p PIN=Originalni kontejner Pinnacle Station: 
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\Rebuild_ME1_CZ_From_Clean.ps1" -GamePath "%GAME%" -PcCzechPath "%PC%" -BDtSContainer "%BDTS%" -PinnacleContainer "%PIN%"
echo.
pause
