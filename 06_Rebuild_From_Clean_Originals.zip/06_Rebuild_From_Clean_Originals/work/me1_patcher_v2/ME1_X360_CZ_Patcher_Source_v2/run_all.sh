#!/usr/bin/env bash
set -euo pipefail
if [ "$#" -ne 4 ]; then
  echo "Použití: $0 GlobalTlk.xxx BDtS_STFS Pinnacle_STFS OUTPUT_DIR" >&2
  exit 2
fi
python3 "$(dirname "$0")/patch_all.py" "$1" "$2" "$3" --output-dir "$4" --strict-tested-hash
