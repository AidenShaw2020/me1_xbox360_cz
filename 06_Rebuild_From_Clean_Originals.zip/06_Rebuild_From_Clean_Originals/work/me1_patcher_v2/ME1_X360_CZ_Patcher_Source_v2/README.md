# Mass Effect 1 Xbox 360 – zdrojové patchery a Codex handoff

Balíček obsahuje reprodukovatelné Python patchery pro dosavadní české buildy a kompletní technický handoff pro pokračování projektu.

## Aktuální stav

| Část | Stav |
|---|---|
| Globální `GlobalTlk.xxx` v6 | runtime PASS |
| Menu, kodex, deník, názvy a popisy | česky |
| NPC/PC repliky a dialogové volby | stále anglicky |
| `Language=CS` | okamžitý pád hry |
| Prioritní další směr | použít existující jazykový slot `PL` |
| BDtS/Pinnacle globální TLK | staticky validní, obsah čeká na runtime test |

Nejdůležitější dokument je `CODEX_HANDOFF.md`.

## Produkční patchery

```text
patch_base.py
patch_btds.py
patch_pinnacle.py
patch_all.py
```

Požadavky:

```bash
sudo apt install python3 liblzo2-2
```

Kompletní reprodukce stávajících referenčních buildů:

```bash
python3 patch_all.py \
  /path/to/GlobalTlk.xxx \
  /path/to/D1EDA8C7E8AF0B82B742DAB8F0715E48142582104D \
  /path/to/C92DDDB13B6DF5023FF9649D776552E34D6D4E1A4D \
  --output-dir output_all \
  --strict-tested-hash
```

Tyto patchery reprodukují přesně dosavadní výstupy, ale zatím neřeší lokální dialogové tabulky.

## Struktura

```text
assets/                              překladové zdroje
me1lib/                              LZO, TLK a STFS knihovna
reference/                           validační reporty
reproduction_test_reports/           validační report čerstvého přesného testu všech tří patcherů
historical_build_scripts/runtime_pass/ přesné skripty použitých úspěšných testů
historical_build_scripts/failed_experiments/ forenzní nefunkční pokusy
diagnostics/                         INT/CS Coalesced test
CODEX_HANDOFF.md                     další postup, zejména PL slot
```

## Bezpečnost

- Originály se nikdy nemění na místě.
- `--force` obchází hash kontroly a nemá se používat pro běžný build.
- `Language=CS` nepoužívat.
- Skripty ve `failed_experiments/` nespouštět jako doporučený build.
