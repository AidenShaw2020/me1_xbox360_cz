# Handoff pro Codex: Mass Effect 1 Xbox 360 – česká lokalizace

## 0. Co je teď potřeba vyřešit

Projekt má funkční převod **globálního TLK** základní hry do češtiny, ale během reálného hraní se ukázalo zásadní omezení:

- menu, kodex, deník, názvy, popisy a jména postav jsou česky,
- mluvené repliky PC/NPC zobrazené jako titulky zůstávají anglicky,
- texty možností v dialogovém kole zůstávají anglicky,
- jména mluvčích jsou česky.

To znamená, že dosavadní `GlobalTlk.xxx` v6 je runtime stabilní, ale **není úplnou lokalizací dialogů**.

Uživatel upozornil, že v herních souborech existuje například `GlobalTlk_PL.xxx`. Je velmi pravděpodobné, že Xbox build má pevně podporované jazykové sloty a `CS` mezi nimi není. Přímá změna `Language=int` na `Language=CS` způsobila okamžitý pád hry. Prioritní hypotéza je proto:

> Nepřidávat nový slot `CS`, ale použít existující slot `PL`, zachovat názvy a strukturu polských souborů a vložit do nich česká data.

Tato hypotéza zatím není runtime potvrzená a musí se nejprve ověřit kontrolním testem.

---

## 1. Cíl projektu

Převést existující českou PC lokalizaci původního Mass Effectu 1 do formátu použitelného na skutečném Xboxu 360 RGH/JTAG, včetně:

1. globálních textů základní hry,
2. dialogů a dialogových voleb základní hry,
3. Bring Down the Sky,
4. Pinnacle Station,
5. reprodukovatelných patcherů, které pracují pouze s uživatelovými originálními soubory.

Distribuční strategie je přímé patchování souborů. Pokus o vlastní data-only Title Update byl opuštěn: TU se připojil, ale hra po animaci Microsoftu skončila černou obrazovkou. Bez skutečného `default.xexp` navázaného na daný XEX není vlastní TU spolehlivý.

---

## 2. Cílová verze hry

```text
Platforma: Xbox 360, původní Mass Effect 1, TU0
Title ID: 4D5307E8
Media ID: 572BA75D
XEX version: 5
XEX base version: 5
```

Referenční `default.xex`:

```text
velikost: 5 586 944 B
SHA-256: 4beb582540010b25032e3a51e4ce84a6fb1a9f381adddd8b2def0dc5d6bf715d
```

`default.xex` se v aktuálním řešení nemění.

---

## 3. Runtime pravda – co bylo skutečně otestováno

| Verze | Obsah testu | Výsledek na skutečném Xboxu 360 |
|---|---|---|
| v3 | anglický kontrolní rebuild přes nový LZO writer | PASS |
| v5a | in-place ASCII změna `Options -> Cestina` | PASS |
| v5b | diakritika `Čeština` | PASS |
| v5c | nový Huffmanův strom a úplný re-encode | PASS |
| v5d | relokace obou TLK exportů na konec balíčku | PASS |
| v6 | český globální `GlobalTlk.xxx` | PASS, hra stabilní |
| v6 dialogy | NPC/PC titulky a dialogové volby | FAIL funkčně: zůstávají anglicky |
| v7 `Language=CS` | pokus aktivovat neexistující český jazykový slot | FAIL: hra ihned spadne |
| TU v8 | data-only STFS Title Update bez `default.xexp` | FAIL: černá obrazovka po Microsoft animaci |
| BDtS v1 | upravený globální DLC TLK | staticky validní, obsah mise runtime neotestován |
| Pinnacle v1 | upravený globální DLC TLK | staticky validní, obsah mise runtime neotestován |

Důležitá oprava terminologie: dřívější tvrzení „plná česká základní hra“ znamenalo úplné pokrytí aktivních řetězců v globálním `GlobalTlk.xxx`, nikoli úplné pokrytí všech lokálních dialogových tabulek ve všech balíčcích.

---

## 4. Ověřené vstupy a referenční výstupy

### Základní Xbox GlobalTlk

```text
soubor: GlobalTlk.xxx
velikost: 797 358 B
SHA-256: e85d70488852267f49653dc8c364b6bc9192fe407e37de493921abfb3e1bdf1f
```

Vlastnosti:

- UE3 big-endian,
- package version 391/92,
- 113 names,
- 5 imports,
- 4 exports,
- compression type 2 = LZO,
- exporty:
  - `GlobalTlk_tlk`
  - `GlobalTlk_tlk_M`
  - `SeekFreeSaver`
  - `SeekFreeShaderCache`

### Český PC zdroj

```text
soubor: assets/GlobalTlk_CS.upk
velikost: 1 468 033 B
SHA-256: 5d9afea8da2a3f149f5d8dbfdac1317255a01f41f4a73f858216d5c7306b9648
```

### Doplňková mapa xboxových globálních textů

```text
soubor: assets/base_xbox_only_translation_cs.json
SHA-256: dcae93a637f0a12dfa545075e589550746274012dd4fa5f76394c11564e05384
```

### Referenční výstup globální v6

```text
soubor: GlobalTlk.xxx
velikost: 2 185 651 B
SHA-256: 47363c769e9b3ea261043e2cd9b138e1f52a74510b468ceec6a8a132cdb60604
runtime: PASS
omezení: dialogové repliky a volby mimo globální TLK zůstávají anglicky
```

### Bring Down the Sky originál

```text
D1EDA8C7E8AF0B82B742DAB8F0715E48142582104D
velikost: 265 666 560 B
SHA-256: bfc495b1d687015209b830ef7c8097cd6a78fe2d5f7f33868ae41970d053e06c
```

Referenční dosavadní výstup:

```text
Content ID / název: 066134EE0B0841AFB85DE249C968D3BB82627363
SHA-256: fc152e51004e2765c838f1aad6359f093b70321e07cbb96c17e14dd4a4e9d92c
stav: pouze globální DLC TLK, místní dialogy nemusí být česky
```

### Pinnacle Station originál

```text
C92DDDB13B6DF5023FF9649D776552E34D6D4E1A4D
velikost: 257 900 544 B
SHA-256: a893369bb08393e5660c75591f8af653af8ccb5200df30dee50290a8f221e71a
```

Překladová mapa:

```text
assets/DLC_Vegas_translation_cs.json
SHA-256: 69f79046f49ce97aa15f1055efea84d76de377fcdb1b0b2c18ddacfe1f716876
```

Referenční dosavadní výstup:

```text
Content ID / název: FE46A00A9CC91D9982ADD6815E30E0607B2B52A9
SHA-256: c61721df77ea5912810afa3fee06d5f82c445732eba6c0b25d2bb044b07891c3
stav: pouze globální DLC TLK, místní dialogy nemusí být česky
```

---

## 5. Technicky ověřený formát

### UE3 komprese Xbox ME1

```text
CompressionFlags/type: 2
algoritmus: LZO1X
max. velikost bloku: 0x20000
chunk magic: 0x9E2A83C1
endianness: big-endian
```

Typ `2` je v tomto konkrétním ME1 Xbox formátu LZO. Rané pokusy postavené jako LZX padaly.

### BioTlkFile

Po 40bajtovém prefixu exportu:

```text
int32 entry_count
entry_count × (int32 StringID, int32 Flags, int32 Index)
int32 node_count
Huffman nodes
int32 string_count
string_count × (int32 string_length, int32 encoded_length, bytes payload)
```

- Xbox data jsou big-endian.
- PC český zdroj je little-endian.
- Huffmanovy bity se čtou LSB-first.
- Strom je serializován BFS, pravý potomek před levým.
- Funkční writer přidává trailing bit za NUL kódem kvůli chování ME1 dekodéru na hranici bajtu.

### Citlivé exporty

`SeekFreeSaver` a `SeekFreeShaderCache` musí zůstat na původních offsetech a obsahově beze změny. Funkční v6 zachovává celý původní logický balíček, nové větší TLK připojí na konec a přepíše pouze `DataSize/DataOffset` prvních dvou exportů.

---

## 6. Produkční patchery v tomto balíčku

```text
patch_base.py       reprodukuje globální v6
patch_btds.py       reprodukuje dosavadní BDtS v1
patch_pinnacle.py   reprodukuje dosavadní Pinnacle v1
patch_all.py        spustí všechny tři
me1lib/             LZO, UE3/TLK a STFS implementace
assets/             české zdroje a překladové mapy
reference/          validační reporty referenčních buildů
```

Tyto patchery byly znovu spuštěny na originálních souborech a s `--strict-tested-hash` vytvořily bajtově přesné referenční výstupy. To však neřeší chybějící dialogové tabulky.

Adresář `historical_build_scripts/runtime_pass/` obsahuje přesné vývojové skripty použité pro runtime testy v3, v5a–v6 a pro oba DLC buildy. Některé mají historické absolutní cesty a nejsou zamýšlené jako finální uživatelské CLI; jsou určené ke studiu a porovnání algoritmů.

Adresář `historical_build_scripts/failed_experiments/` obsahuje pouze forenzní kopie nefunkčních pokusů. Nesmí se použít jako doporučený build.

---

## 7. Prioritní úkol: ověřit a použít polský jazykový slot

Codex má pracovat přímo s úplným stromem herních souborů, ke kterému má přístup. Nezačínej přepisem XEX. Nejdřív proveď inventuru a kontrolní testy.

### 7.1 Inventura jazykových souborů

Najdi a zapiš:

```text
GlobalTlk_PL.xxx
GlobalTlk.xxx
všechny *_PL.xxx
všechny adresáře Localised/PL nebo obdobné
všechny *_INT.xxx nebo neoznačené INT protějšky
Coalesced.ini
Coalesced.int
```

Pro každý `*_PL.xxx` najdi odpovídající INT/neutrální soubor a porovnej:

- package GUID,
- names/imports/exports,
- exporty třídy `BioTlkFile`,
- názvy `tlk`, `tlk_M`, `tlk_PL`, `tlk_M_PL` apod.,
- String ID a počet aktivních řetězců,
- zda jde o kompletní lokalizovaný balíček, nebo jen samostatnou talk table.

### 7.2 Kontrolní runtime test PL slotu

Nejdřív vytvoř nejmenší možný test, který nemění obsah polských dat:

1. originální soubory hry,
2. `Language=PL`, přesně ve formátu, který očekává hra,
3. všechny originální polské soubory ponechané beze změny.

Očekávaný výsledek:

- hra naběhne,
- menu/dialogy jsou polsky.

Když tento test spadne, problém není překlad, ale nesprávné nastavení slotu nebo chybějící polská sada souborů.

### 7.3 Český globální TLK v polském slotu

Nevkládej existující v6 slepě jako `GlobalTlk_PL.xxx`. Vezmi originální `GlobalTlk_PL.xxx` jako strukturální šablonu a:

1. rozbal jej stejným LZO readerem,
2. zjisti přesné názvy/exporty polského balíčku,
3. nahraď obsah obou BioTlkFile exportů českými texty,
4. zachovej package identity, helper exporty a všechny ostatní offsetově citlivé části,
5. ulož pod původním názvem `GlobalTlk_PL.xxx`,
6. aktivuj `Language=PL`.

Tím se ověří globální čeština přes existující slot bez zavádění `CS`.

### 7.4 Jeden časný dialog jako minimální důkaz

Vyber balíček rozhovoru dostupný během prvních minut hry. Najdi jeho polský lokalizovaný protějšek a český PC zdroj. Vytvoř pouze jednu upravenou polskou lokalizovanou kopii se stejným názvem a strukturou.

Kritérium PASS:

- NPC replika je česky,
- Shepardova replika/titulky jsou česky,
- volba v dialogovém kole je česky,
- hra nepřestane načítat audio/FaceFX.

Teprve po tomto testu automatizuj převod všech dialogových balíčků.

### 7.5 Párování PC českých a Xbox PL/INT balíčků

Preferované pořadí párování:

1. stejný relativní název balíčku,
2. stejné exporty `BioConversation` a jejich `srText` String ID,
3. stejné aktivní String ID v lokálních `BioTlkFile`,
4. textové párování až jako fallback.

Nevycházej z předpokladu, že všechny dialogy jsou v `GlobalTlk_CS.upk`. Pro kompletní překlad mohou být nutné všechny české PC lokalizované `.upk` soubory.

---

## 8. Dopad na DLC

Dosavadní `patch_btds.py` a `patch_pinnacle.py` překládají pouze jejich globální talk table. Pro finální verzi je nutné stejnou inventuru provést uvnitř STFS kontejnerů:

- najít polské lokalizované balíčky,
- porovnat je s INT a PC českým zdrojem,
- vložit české texty do existujícího PL slotu,
- zachovat názvy, cesty, chainy a STFS metadata,
- kompletně přepočítat L0/L1/L2, root hash a Content ID.

Pokud se použije PL slot, současné využití ES souborů jako donorů nemusí být finální správná strategie. Nejprve zjisti, zda česká data vejdou do polských alokací nebo zda lze bezpečně prodloužit jejich STFS chain.

---

## 9. Co nesmí regrese rozbít

- Neměnit `default.xex`, dokud nebude prokázáno, že PL slot nestačí.
- Nepoužívat `Language=CS`; tento test na konzoli okamžitě padá.
- Nevracet se k LZX pro zde analyzované `.xxx` balíčky.
- Nepřesouvat ani nepřebudovávat `SeekFreeSaver` a `SeekFreeShaderCache`.
- Nezahazovat původní names/imports/exports a package identity.
- Neprovádět patch originálu na místě.
- Neoznačovat dialogy ani DLC jako runtime PASS bez konkrétního testu.
- Nepovažovat správný STFS hash tree za důkaz herní kompatibility.
- Nezaměňovat globální překlad s úplnou lokalizací.

---

## 10. Reprodukce současných referenčních buildů

```bash
sudo apt install python3 liblzo2-2
python3 patch_all.py \
  /path/to/GlobalTlk.xxx \
  /path/to/D1EDA8C7E8AF0B82B742DAB8F0715E48142582104D \
  /path/to/C92DDDB13B6DF5023FF9649D776552E34D6D4E1A4D \
  --output-dir output_all \
  --strict-tested-hash
```

Očekávané:

```json
"all_exact_reference_matches": true
```

Tento test potvrzuje, že stávající algoritmy nebyly regresně změněny. Nepotvrzuje úplnost dialogů.

---

## 11. Relevantní soubory dostupné v pracovním prostoru

### Originály a zdroje

```text
GlobalTlk.xxx
GlobalTlk_CS.upk
Coalesced.ini
Coalesced.int
default(1).xex
D1EDA8C7E8AF0B82B742DAB8F0715E48142582104D
C92DDDB13B6DF5023FF9649D776552E34D6D4E1A4D
```

### Ověřené/aktuální výstupy

```text
ME1_X360_CZ_Relocated_v6/GlobalTlk.xxx
ME1_X360_CZ_BDtS_v1/066134EE0B0841AFB85DE249C968D3BB82627363
ME1_X360_CZ_Pinnacle_v1/FE46A00A9CC91D9982ADD6815E30E0607B2B52A9
```

### Diagnostické soubory

```text
diagnostics/Coalesced_original_INT.ini
diagnostics/Coalesced_CS_crash_test.ini
```

V úplném stromu hry navíc vyhledej uživatelem zmíněný `GlobalTlk_PL.xxx` a všechny související polské soubory. Tento soubor nebyl součástí dosavadního minimálního vstupního setu patcheru, ale je nyní hlavním kandidátem pro správnou implementaci.

---

## 12. Požadovaný výstup od Codexu

1. Inventární report všech PL/INT lokalizačních souborů základní hry a obou DLC.
2. Vysvětlení skutečného mechanismu výběru lokálních dialogových TLK na Xboxu.
3. Minimální kontrolní build `Language=PL` s originální polštinou.
4. Český globální build založený na originálním `GlobalTlk_PL.xxx`.
5. Jeden časný dialogový balíček převedený do češtiny přes PL slot.
6. Po runtime potvrzení obecný patcher pro všechny základní dialogové balíčky.
7. Následně rozšíření stejného mechanismu na BDtS a Pinnacle Station.
8. Aktualizované validační reporty a rollback instrukce.
