@echo off
setlocal
if "%~4"=="" (
  echo Pouziti: %~nx0 GlobalTlk.xxx BDtS_STFS Pinnacle_STFS OUTPUT_DIR
  exit /b 2
)
python "%~dp0patch_all.py" "%~1" "%~2" "%~3" --output-dir "%~4" --strict-tested-hash
exit /b %ERRORLEVEL%
