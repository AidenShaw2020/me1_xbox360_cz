#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import hashlib
import importlib.util
import json
import shutil
import struct
import sys
import zipfile

ROOT = Path('/mnt/data')
SRC = ROOT / 'GlobalTlk.xxx'
OUTDIR = ROOT / 'ME1_X360_CZ_Relocated_v6'
OUT = OUTDIR / 'GlobalTlk.xxx'
OUTZIP = ROOT / 'ME1_X360_CZ_Relocated_v6.zip'


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


lzo = load_module('lzoctl_v6', ROOT / 'build_me1_xenon_lzo_control.py')
v4 = load_module('basev4_v6', ROOT / 'build_me1_x360_cz_base_v4.py')


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def patch_export_size_offset(logical: bytearray, exp, new_size: int, new_offset: int) -> None:
    # ME1 Xenon common export header: DataSize at +32, DataOffset at +36.
    struct.pack_into('>ii', logical, exp.start + 32, new_size, new_offset)


def build_multichunk(source_pkg: bytes, logical: bytes, ranges: list[tuple[int, int]], package_source: bytes):
    physical_header_size = 125 + 16 * len(ranges) + 4
    header = bytearray(source_pkg[:125])
    struct.pack_into('>i', header, 121, len(ranges))

    chunks = []
    compressed_offset = physical_header_size
    for uncompressed_offset, uncompressed_size in ranges:
        raw = logical[uncompressed_offset:uncompressed_offset + uncompressed_size]
        if len(raw) != uncompressed_size:
            raise RuntimeError((uncompressed_offset, uncompressed_size, len(raw)))
        chunk, blocks = lzo.build_chunk(raw)
        chunks.append({
            'uoff': uncompressed_offset,
            'usize': uncompressed_size,
            'coff': compressed_offset,
            'csize': len(chunk),
            'chunk': chunk,
            'blocks': blocks,
        })
        compressed_offset += len(chunk)

    for chunk in chunks:
        header += struct.pack('>iiii', chunk['uoff'], chunk['usize'], chunk['coff'], chunk['csize'])
    header += package_source
    if len(header) != physical_header_size:
        raise RuntimeError((len(header), physical_header_size))

    return bytes(header) + b''.join(c['chunk'] for c in chunks), chunks


def active_map(entries):
    return {entry.string_id: entry.text for entry in entries if entry.flags == 1}


def main() -> None:
    source_pkg = SRC.read_bytes()
    original_logical, source_records, source_blocks, _ = lzo.decompress_package(source_pkg)
    tables = v4.parse_package_tables(original_logical, '>')
    exports = tables['exports']
    names = tables['names']

    expected_exports = ['GlobalTlk_tlk', 'GlobalTlk_tlk_M', 'SeekFreeSaver', 'SeekFreeShaderCache']
    actual_exports = [names[e.name_index] for e in exports]
    if actual_exports != expected_exports:
        raise RuntimeError(f'unexpected exports: {actual_exports}')

    # Parse the original Xbox TLKs and the Czech PC source TLKs.
    source_upk, source_tables, source_exports = v4.parse_source_upk()
    source_names = source_tables['names']
    if [source_names[e.name_index] for e in source_exports] != ['GlobalTlk_tlk', 'GlobalTlk_tlk_M']:
        raise RuntimeError('unexpected Czech source exports')

    original_parsed = []
    czech_source_parsed = []
    for i in range(2):
        xbox_exp = exports[i]
        xbox_blob = original_logical[xbox_exp.data_offset:xbox_exp.data_offset + xbox_exp.data_size]
        original_parsed.append(v4.parse_tlk_export(xbox_blob, '>'))

        pc_exp = source_exports[i]
        pc_blob = source_upk[pc_exp.data_offset:pc_exp.data_offset + pc_exp.data_size]
        czech_source_parsed.append(v4.parse_tlk_export(pc_blob, '<'))

    xbox_only = json.loads(v4.XBOX_ONLY_JSON.read_text(encoding='utf-8'))
    merged_entries = []
    coverage = []
    for i in range(2):
        merged, cov = v4.merge_translation(original_parsed[i][1], czech_source_parsed[i][1], xbox_only)
        if cov['retained_english'] != 0:
            raise RuntimeError(f'gender {i}: {cov["retained_english"]} active strings remain untranslated')
        merged_entries.append(merged)
        coverage.append(cov)

    new_tlks = [
        v4.build_tlk_export(original_parsed[0][0], merged_entries[0]),
        v4.build_tlk_export(original_parsed[1][0], merged_entries[1]),
    ]

    # The v5d runtime test proved that TLKs can be appended while helper exports stay fixed.
    # Preserve the complete original logical package and append the larger Czech TLKs.
    patched = bytearray(original_logical)
    new_offsets = []
    for blob in new_tlks:
        new_offsets.append(len(patched))
        patched += blob

    for i in range(2):
        patch_export_size_offset(patched, exports[i], len(new_tlks[i]), new_offsets[i])

    # Two original chunks + one chunk per appended TLK.
    ranges = [(uoff, usize) for uoff, usize, _coff, _csize in source_records]
    ranges.extend((new_offsets[i], len(new_tlks[i])) for i in range(2))
    struct.pack_into('>i', patched, 121, len(ranges))
    intended_logical = bytes(patched)

    package_source_pos = 125 + 16 * len(source_records)
    package_source = source_pkg[package_source_pos:package_source_pos + 4]
    output_pkg, built_chunks = build_multichunk(source_pkg, intended_logical, ranges, package_source)

    # Full LZO/package round trip.
    rebuilt_logical, rebuilt_records, rebuilt_blocks, _ = lzo.decompress_package(output_pkg)
    if rebuilt_logical != intended_logical:
        raise RuntimeError('LZO logical round-trip mismatch')

    rebuilt_tables = v4.parse_package_tables(rebuilt_logical, '>')
    rebuilt_exports = rebuilt_tables['exports']
    if rebuilt_tables['names'] != tables['names']:
        raise RuntimeError('name table changed')
    if rebuilt_tables['import_count'] != tables['import_count']:
        raise RuntimeError('import count changed')
    if [rebuilt_tables['names'][e.name_index] for e in rebuilt_exports] != expected_exports:
        raise RuntimeError('final export identity changed')

    # Validate offsets, sizes, decoded Czech text and helper preservation.
    tlk_validation = []
    for i in range(2):
        exp = rebuilt_exports[i]
        if exp.data_offset != new_offsets[i] or exp.data_size != len(new_tlks[i]):
            raise RuntimeError(f'TLK export {i} header mismatch')
        blob = rebuilt_logical[exp.data_offset:exp.data_offset + exp.data_size]
        prefix, decoded_entries, stats = v4.parse_tlk_export(blob, '>')
        if prefix != original_parsed[i][0]:
            raise RuntimeError(f'TLK export {i} property prefix changed')
        if active_map(decoded_entries) != active_map(merged_entries[i]):
            raise RuntimeError(f'TLK export {i} decoded Czech mapping mismatch')
        stats['export_name'] = expected_exports[i]
        stats['size'] = exp.data_size
        stats['offset'] = exp.data_offset
        tlk_validation.append(stats)

    helper_validation = []
    for i in (2, 3):
        old_exp = exports[i]
        new_exp = rebuilt_exports[i]
        old_blob = original_logical[old_exp.data_offset:old_exp.data_offset + old_exp.data_size]
        new_blob = rebuilt_logical[new_exp.data_offset:new_exp.data_offset + new_exp.data_size]
        if new_exp.data_offset != old_exp.data_offset or new_exp.data_size != old_exp.data_size:
            raise RuntimeError(f'helper export {i} offset/size changed')
        if new_blob != old_blob:
            raise RuntimeError(f'helper export {i} payload changed')
        helper_validation.append({
            'name': expected_exports[i],
            'offset': new_exp.data_offset,
            'size': new_exp.data_size,
            'sha256': sha256(new_blob),
            'byte_identical_to_original': True,
        })

    # The old TLK areas remain byte-identical and are now unreferenced; this is intentional.
    for i in range(2):
        old_exp = exports[i]
        old_blob = original_logical[old_exp.data_offset:old_exp.data_offset + old_exp.data_size]
        retained_blob = rebuilt_logical[old_exp.data_offset:old_exp.data_offset + old_exp.data_size]
        if retained_blob != old_blob:
            raise RuntimeError(f'original unreferenced TLK area {i} changed')

    OUTDIR.mkdir(parents=True, exist_ok=True)
    OUT.write_bytes(output_pkg)
    shutil.copy2(SRC, OUTDIR / 'GlobalTlk_original_backup.xxx')
    shutil.copy2(Path(__file__), OUTDIR / Path(__file__).name)

    report = {
        'build': 'ME1 Xbox 360 Czech relocated base TLK v6',
        'runtime_basis': {
            'v3_lzo_control': 'PASS on Xbox 360',
            'v5a_in_place_ASCII': 'PASS on Xbox 360',
            'v5b_diacritics': 'PASS on Xbox 360',
            'v5c_full_Huffman_reencode': 'PASS on Xbox 360',
            'v5d_TLK_relocation': 'PASS on Xbox 360',
        },
        'source_files': {
            'original_xbox_globaltlk_sha256': sha256(source_pkg),
            'czech_pc_globaltlk_upk_sha256': sha256(source_upk),
            'xbox_only_translation_json_sha256': sha256(v4.XBOX_ONLY_JSON.read_bytes()),
        },
        'output': {
            'file': OUT.name,
            'size': len(output_pkg),
            'sha256': sha256(output_pkg),
            'logical_size': len(rebuilt_logical),
            'logical_sha256': sha256(rebuilt_logical),
        },
        'package_structure': {
            'full_header_size': rebuilt_tables['full_header_size'],
            'name_count': rebuilt_tables['name_count'],
            'import_count': rebuilt_tables['import_count'],
            'export_count': rebuilt_tables['export_count'],
            'compression': 'UE3 type 2 / LZO1X',
            'chunk_records': rebuilt_records,
            'blocks': rebuilt_blocks,
            'exports': [
                {
                    'name': rebuilt_tables['names'][e.name_index],
                    'old_offset': exports[i].data_offset,
                    'new_offset': e.data_offset,
                    'old_size': exports[i].data_size,
                    'new_size': e.data_size,
                }
                for i, e in enumerate(rebuilt_exports)
            ],
        },
        'translation_coverage': {
            'female': {k: v for k, v in coverage[0].items() if k != 'missing'},
            'male': {k: v for k, v in coverage[1].items() if k != 'missing'},
        },
        'tlk_validation': tlk_validation,
        'helper_validation': helper_validation,
        'checks': [
            'original 113-name table preserved',
            'original 5 imports preserved',
            'all 4 export identities preserved',
            'Czech TLKs appended at new offsets proven viable by v5d',
            'SeekFreeSaver remains at original offset and is byte-identical',
            'SeekFreeShaderCache remains at original offset and is byte-identical',
            'all active base-game strings translated in both gender tables',
            'Czech diacritics decoded correctly after serialization',
            'all LZO blocks decompressed successfully',
            'complete rebuilt logical package matches intended bytes',
        ],
        'runtime_status': 'PENDING XBOX 360 TEST',
    }
    (OUTDIR / 'validation.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')

    readme = f'''Mass Effect 1 Xbox 360 – česká základní hra v6 (relokované TLK)\n\nTato verze kombinuje všechny úspěšné runtime testy v3 až v5d.\nVětší české BioTlkFile exporty jsou přidány na konec balíčku.\nSeekFreeSaver a SeekFreeShaderCache zůstávají na původních offsetech a jsou bitově shodné s originálem.\n\nTESTUJ NYNÍ JEN ZÁKLADNÍ HRU:\n1. Zálohuj Hdd1:/Games/Mass Effect 1/Layer0/MEInit/GlobalTlk.xxx\n2. Nahraď jej tímto GlobalTlk.xxx.\n3. Obě oficiální DLC ponech originální.\n4. Odstraň nebo vypni dřívější experimentální česká DLC.\n5. Proveď úplný restart konzole a spusť hru.\n\nOčekávání: hra normálně naběhne a nabídka i texty základní hry budou česky.\n\nNový SHA-256: {sha256(output_pkg)}\nPůvodní SHA-256: {sha256(source_pkg)}\nPro návrat použij GlobalTlk_original_backup.xxx.\n'''
    (OUTDIR / 'README_CS.txt').write_text(readme, encoding='utf-8')

    with zipfile.ZipFile(OUTZIP, 'w', zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(OUTDIR.iterdir()):
            zf.write(path, path.name)

    print(json.dumps(report, ensure_ascii=False, indent=2))
    print('OUTPUT', OUT)
    print('ZIP', OUTZIP)


if __name__ == '__main__':
    main()
