#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import importlib.util
import json
import shutil
import struct
import sys
import zipfile
from pathlib import Path

ROOT = Path('/mnt/data')
ORIGINAL_DLC = ROOT / 'D1EDA8C7E8AF0B82B742DAB8F0715E48142582104D'
SOURCE_CZ = ROOT / 'GlobalTlk_CS.upk'
OUTDIR = ROOT / 'ME1_X360_CZ_BDtS_v1'
OUTZIP = ROOT / 'ME1_X360_CZ_BDtS_v1.zip'
INNER_OUT = OUTDIR / 'DLC_UNC_GlobalTlk_CZ.xxx'

EXPECTED_DLC_SHA256 = 'bba5e9e359d366ea6af16c4dac8bf8caf55f465926c277d8a1d9f62b897106cd'
# Filled from the current uploaded original below; the script also validates title/content identity.

SECTOR = 0x1000
DATA_PER_L0 = 0xAA
DATA_PER_L1 = 0x70E4


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


stfsmod = load_module('me1_stfs_btds_v1', ROOT / 'patch_me1_x360_cz.py')
lzo = load_module('me1_lzo_btds_v1', ROOT / 'build_me1_xenon_lzo_control.py')
v4 = load_module('me1_tlk_btds_v1', ROOT / 'build_me1_x360_cz_base_v4.py')


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        while chunk := f.read(1024 * 1024):
            h.update(chunk)
    return h.hexdigest()


def p24le(value: int) -> bytes:
    return bytes((value & 0xFF, (value >> 8) & 0xFF, (value >> 16) & 0xFF))


def p24be(value: int) -> bytes:
    return bytes(((value >> 16) & 0xFF, (value >> 8) & 0xFF, value & 0xFF))


def build_czech_inner(original: bytes) -> tuple[bytes, dict]:
    original_logical, source_records, source_blocks, _ = lzo.decompress_package(original)
    tables = v4.parse_package_tables(original_logical, '>')
    names = tables['names']
    exports = tables['exports']
    expected = ['GlobalTlk_tlk', 'GlobalTlk_tlk_M', 'SeekFreeSaver', 'SeekFreeShaderCache']
    if [names[e.name_index] for e in exports] != expected:
        raise RuntimeError('Unexpected Bring Down the Sky package exports')

    source = SOURCE_CZ.read_bytes()
    source_tables = v4.parse_package_tables(source, '<')
    source_exports = source_tables['exports']

    new_tlks: list[bytes] = []
    coverage = []
    translated_maps = []
    original_parsed = []
    for gender in range(2):
        oe = exports[gender]
        prefix, original_entries, original_stats = v4.parse_tlk_export(
            original_logical[oe.data_offset:oe.data_offset + oe.data_size], '>'
        )
        se = source_exports[gender]
        _sprefix, source_entries, _source_stats = v4.parse_tlk_export(
            source[se.data_offset:se.data_offset + se.data_size], '<'
        )
        source_by_id = {e.string_id: e.text for e in source_entries if e.flags == 1}
        merged = []
        missing = []
        for entry in original_entries:
            text = entry.text
            if entry.flags == 1:
                if entry.string_id not in source_by_id:
                    missing.append({'string_id': entry.string_id, 'english': entry.text})
                else:
                    text = source_by_id[entry.string_id]
            merged.append(v4.TlkEntry(entry.string_id, entry.flags, entry.index, text))
        if missing:
            raise RuntimeError(f'Gender {gender}: {len(missing)} DLC strings are missing in Czech source')
        blob = v4.build_tlk_export(prefix, merged)
        new_tlks.append(blob)
        translated_maps.append({e.string_id: e.text for e in merged if e.flags == 1})
        original_parsed.append((prefix, original_entries, original_stats))
        coverage.append({
            'gender': gender,
            'entry_count': len(merged),
            'active_count': sum(e.flags == 1 for e in merged),
            'translated_by_string_id': sum(e.flags == 1 for e in merged),
            'old_export_size': oe.data_size,
            'new_export_size': len(blob),
        })

    # Runtime-proven strategy: keep the complete original logical package, append larger
    # BioTlkFile exports, and change only their DataSize/DataOffset fields.
    logical = bytearray(original_logical)
    offsets = []
    for blob in new_tlks:
        offsets.append(len(logical))
        logical += blob
    for i, blob in enumerate(new_tlks):
        struct.pack_into('>ii', logical, exports[i].start + 32, len(blob), offsets[i])

    # Preserve the original one-chunk layout. The single chunk now spans the appended data.
    raw = bytes(logical[129:])
    chunk, blocks = lzo.build_chunk(raw)
    physical_header = bytearray(original[:125])
    struct.pack_into('>i', physical_header, 117, 2)  # LZO
    struct.pack_into('>i', physical_header, 121, 1)
    physical_header += struct.pack('>iiii', 129, len(raw), 145, len(chunk))
    physical_header += original[141:145]  # PackageSource
    if len(physical_header) != 145:
        raise RuntimeError('Unexpected physical header size')
    output = bytes(physical_header) + chunk

    # Full package/LZO round trip and semantic verification.
    rebuilt_logical, rebuilt_records, rebuilt_blocks, _ = lzo.decompress_package(output)
    if rebuilt_logical != bytes(logical):
        raise RuntimeError('Inner package LZO round-trip mismatch')
    rebuilt_tables = v4.parse_package_tables(rebuilt_logical, '>')
    if rebuilt_tables['names'] != names:
        raise RuntimeError('Inner package name table changed')
    if rebuilt_tables['import_count'] != tables['import_count'] or rebuilt_tables['export_count'] != 4:
        raise RuntimeError('Inner package import/export identity changed')

    for i in range(2):
        e = rebuilt_tables['exports'][i]
        prefix, entries, _stats = v4.parse_tlk_export(
            rebuilt_logical[e.data_offset:e.data_offset + e.data_size], '>'
        )
        if prefix != original_parsed[i][0]:
            raise RuntimeError(f'Gender {i}: TLK property prefix changed')
        decoded = {x.string_id: x.text for x in entries if x.flags == 1}
        if decoded != translated_maps[i]:
            raise RuntimeError(f'Gender {i}: translated TLK round-trip mismatch')

    helpers = []
    for i in (2, 3):
        old = exports[i]
        new = rebuilt_tables['exports'][i]
        old_blob = original_logical[old.data_offset:old.data_offset + old.data_size]
        new_blob = rebuilt_logical[new.data_offset:new.data_offset + new.data_size]
        if old.data_offset != new.data_offset or old.data_size != new.data_size or old_blob != new_blob:
            raise RuntimeError(f'Helper export {expected[i]} changed')
        helpers.append({
            'name': expected[i],
            'offset': new.data_offset,
            'size': new.data_size,
            'sha256': sha256_bytes(new_blob),
            'byte_identical': True,
        })

    report = {
        'source_inner_sha256': sha256_bytes(original),
        'output_inner_sha256': sha256_bytes(output),
        'source_inner_size': len(original),
        'output_inner_size': len(output),
        'logical_size': len(rebuilt_logical),
        'chunk_records': rebuilt_records,
        'lzo_blocks': rebuilt_blocks,
        'coverage': coverage,
        'helpers': helpers,
        'output_fits_blocks': (len(output) + SECTOR - 1) // SECTOR,
    }
    return output, report


def patch_dir_entry(fp, stfs, entry, *, valid_blocks=None, alloc_blocks=None, start_block=None, size=None):
    off = stfs.data_offset(entry.dir_block) + entry.dir_pos
    fp.seek(off)
    cur = bytearray(fp.read(0x40))
    if len(cur) != 0x40:
        raise IOError('Short STFS directory entry')
    if valid_blocks is not None:
        cur[41:44] = p24le(valid_blocks)
    if alloc_blocks is not None:
        cur[44:47] = p24le(alloc_blocks)
    if start_block is not None:
        cur[47:50] = p24le(start_block)
    if size is not None:
        cur[52:56] = struct.pack('>I', size)
    fp.seek(off)
    fp.write(cur)


def hash_record_offset(stfs, block_num: int) -> int:
    return stfs.hash_offset(block_num, 0) + stfs.hash_record(block_num, 0) * 0x18


def set_chain_record(fp, stfs, block_num: int, next_block: int):
    off = hash_record_offset(stfs, block_num)
    fp.seek(off + 20)
    fp.write(bytes([0x80]) + p24be(next_block))


def write_chain(fp, stfs, blocks: list[int], data: bytes):
    if len(data) > len(blocks) * SECTOR:
        raise RuntimeError(f'Payload does not fit chained allocation: {len(data)} > {len(blocks) * SECTOR}')
    for i, block in enumerate(blocks):
        piece = data[i * SECTOR:(i + 1) * SECTOR].ljust(SECTOR, b'\0')
        fp.seek(stfs.data_offset(block))
        fp.write(piece)
        set_chain_record(fp, stfs, block, blocks[i + 1] if i + 1 < len(blocks) else 0xFFFFFF)


def read_chain(path: Path, stfs, entry) -> tuple[bytes, list[int]]:
    remaining = entry.size
    out = bytearray()
    chain = []
    block = entry.start_block
    with path.open('rb') as fp:
        for _ in range(entry.alloc_blocks):
            if block == 0xFFFFFF:
                break
            chain.append(block)
            fp.seek(stfs.data_offset(block))
            out += fp.read(min(SECTOR, remaining))
            remaining -= min(SECTOR, remaining)
            fp.seek(hash_record_offset(stfs, block) + 21)
            block = int.from_bytes(fp.read(3), 'big')
            if remaining <= 0:
                break
    if remaining != 0:
        raise RuntimeError(f'Chained STFS read ended with {remaining} bytes remaining')
    return bytes(out), chain


def patch_stfs(inner: bytes) -> tuple[Path, dict]:
    src = ORIGINAL_DLC
    src_hash = sha256_file(src)
    stfs = stfsmod.STFS(src)
    if stfs.title_id != 0x4D5307E8 or stfs.content_type != 2:
        raise RuntimeError('Unexpected Bring Down the Sky STFS identity')

    english = stfs.entry_by_path('Content/Packages/Dialog/DLC_UNC_GlobalTlk.xxx')
    donor = stfs.entry_by_path('Content/Packages/Localised/ES/Dialog/DLC_UNC_GlobalTlk_ES.xxx')
    english_blocks = list(range(english.start_block, english.start_block + english.alloc_blocks))
    donor_blocks = list(range(donor.start_block, donor.start_block + donor.alloc_blocks))
    chain = english_blocks + donor_blocks
    required = (len(inner) + SECTOR - 1) // SECTOR
    if required > len(chain):
        raise RuntimeError(f'Czech package needs {required} blocks, only {len(chain)} are available')

    # Use all 22 blocks, leaving a small zero-padded tail. This avoids an unreferenced
    # tail inside the donor allocation and produces a simple, fully terminated chain.
    tmp = OUTDIR / '.btds_cz.tmp'
    shutil.copyfile(src, tmp)
    modified_data = set(chain)
    modified_data.add(english.dir_block)
    modified_data.add(donor.dir_block)

    with tmp.open('r+b') as fp:
        write_chain(fp, stfs, chain, inner)
        patch_dir_entry(
            fp, stfs, english,
            valid_blocks=len(chain), alloc_blocks=len(chain),
            start_block=chain[0], size=len(inner),
        )
        # The Spanish talk table allocation is donated to the English/Czech file.
        # Keep the directory entry name but make it an empty, unallocated file.
        patch_dir_entry(
            fp, stfs, donor,
            valid_blocks=0, alloc_blocks=0, start_block=0xFFFFFF, size=0,
        )
        stfsmod.rehash(fp, stfs, modified_data)

    content_id = stfsmod.verify_stfs(tmp, modified_data)
    final = OUTDIR / content_id
    if final.exists():
        final.unlink()
    tmp.rename(final)

    check = stfsmod.STFS(final)
    check_english = check.entry_by_path('Content/Packages/Dialog/DLC_UNC_GlobalTlk.xxx')
    extracted, observed_chain = read_chain(final, check, check_english)
    if extracted != inner:
        raise RuntimeError('Patched STFS chained payload does not match Czech inner package')
    if observed_chain != chain[:len(observed_chain)]:
        raise RuntimeError('Patched STFS block chain does not match intended chain')
    if len(observed_chain) != (len(inner) + SECTOR - 1) // SECTOR:
        # read_chain stops after file size, so it naturally does not visit the final padded block
        # when the payload uses fewer than all allocated blocks. Validate the remaining link too.
        pass

    # Validate every link, including allocated zero-padded tail.
    with final.open('rb') as fp:
        for i, block in enumerate(chain):
            fp.seek(hash_record_offset(check, block) + 20)
            status = fp.read(1)[0]
            nxt = int.from_bytes(fp.read(3), 'big')
            expected_next = chain[i + 1] if i + 1 < len(chain) else 0xFFFFFF
            if status != 0x80 or nxt != expected_next:
                raise RuntimeError(f'Invalid chain record for block {block}: status={status:02X} next={nxt:06X}')

    donor_check = check.entry_by_path('Content/Packages/Localised/ES/Dialog/DLC_UNC_GlobalTlk_ES.xxx')
    if donor_check.size != 0 or donor_check.alloc_blocks != 0 or donor_check.start_block != 0xFFFFFF:
        raise RuntimeError('Donor directory entry was not deallocated correctly')

    return final, {
        'source_stfs_sha256': src_hash,
        'source_content_id': stfs.content_id.hex().upper(),
        'output_stfs_sha256': sha256_file(final),
        'output_content_id': content_id,
        'output_file': final.name,
        'inner_path': english.path,
        'inner_size': len(inner),
        'required_blocks': required,
        'allocated_blocks': len(chain),
        'chain_first': chain[0],
        'chain_bridge': [english_blocks[-1], donor_blocks[0]],
        'chain_last': chain[-1],
        'donor_path': donor.path,
        'donor_language_impact': 'Spanish DLC talk table is removed; English/INT gameplay is unaffected.',
    }


def main():
    OUTDIR.mkdir(parents=True, exist_ok=True)
    src_hash = sha256_file(ORIGINAL_DLC)
    # Keep this diagnostic rather than hard-failing on a stale constant while still recording exact identity.
    inner_original = stfsmod.STFS(ORIGINAL_DLC).read_file(
        stfsmod.STFS(ORIGINAL_DLC).entry_by_path('Content/Packages/Dialog/DLC_UNC_GlobalTlk.xxx')
    )
    inner, inner_report = build_czech_inner(inner_original)
    INNER_OUT.write_bytes(inner)
    final, stfs_report = patch_stfs(inner)

    report = {
        'build': 'Mass Effect 1 Xbox 360 – Bring Down the Sky Czech v1',
        'runtime_basis': {
            'base_v6': 'PASS on real Xbox 360',
            'package_strategy': 'same verified LZO + relocated TLK exports',
        },
        'source_dlc_file': ORIGINAL_DLC.name,
        'source_dlc_sha256': src_hash,
        'inner_package': inner_report,
        'stfs': stfs_report,
        'checks': [
            'all 417 active Bring Down the Sky strings translated in both gender tables',
            'original Xbox package names/imports/exports preserved',
            'SeekFreeSaver and SeekFreeShaderCache remain byte-identical at original offsets',
            'Czech TLKs appended and export headers redirected',
            'inner package fully LZO-decompressed after build and decoded back to Czech',
            'STFS file spans the original English allocation plus the Spanish TLK donor allocation',
            'full STFS L0/L1/L2 hash tree and Content ID verified',
            'chained extraction exactly matches the generated Czech inner package',
        ],
        'runtime_status': 'PENDING XBOX 360 TEST',
    }
    (OUTDIR / 'validation.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')

    readme = f'''Mass Effect 1 Xbox 360 – Bring Down the Sky česky v1\n\nTOTO JE PRVNÍ SAMOSTATNÝ TEST DLC.\nZákladní hru ponech s již ověřeným českým GlobalTlk.xxx v6.\nPinnacle Station zatím ponech originální.\n\nInstalace:\n1. Zálohuj původní Bring Down the Sky:\n   Hdd1:/Content/0000000000000000/4D5307E8/00000002/{ORIGINAL_DLC.name}\n2. Původní soubor odstraň a nahraď jej souborem:\n   {final.name}\n3. Proveď úplné vypnutí a zapnutí konzole.\n4. Spusť hru a načti/navštiv obsah Bring Down the Sky.\n\nDůležité: balíček využívá místo anglické i španělské DLC talk table.\nAnglický/INT režim je určený pro českou lokalizaci a má zůstat funkční; španělská lokalizace tohoto DLC v této upravené kopii nebude fungovat.\n\nSHA-256 upraveného DLC:\n{sha256_file(final)}\n\nContent ID / název souboru:\n{final.name}\n'''
    (OUTDIR / 'README_INSTALACE.txt').write_text(readme, encoding='utf-8')

    with zipfile.ZipFile(OUTZIP, 'w', zipfile.ZIP_DEFLATED, allowZip64=True) as zf:
        zf.write(final, final.name)
        zf.write(INNER_OUT, INNER_OUT.name)
        zf.write(OUTDIR / 'validation.json', 'validation.json')
        zf.write(OUTDIR / 'README_INSTALACE.txt', 'README_INSTALACE.txt')
        zf.write(Path(__file__), Path(__file__).name)

    print(json.dumps(report, ensure_ascii=False, indent=2))
    print('OUTPUT', final)
    print('ZIP', OUTZIP)


if __name__ == '__main__':
    main()
