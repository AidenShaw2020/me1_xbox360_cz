#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import importlib.util
import json
import shutil
import struct
import sys
import zipfile
from pathlib import Path

ROOT = Path('/mnt/data')
ORIGINAL_DLC = ROOT / 'C92DDDB13B6DF5023FF9649D776552E34D6D4E1A4D'
TRANSLATIONS = ROOT / 'me1_smoke_inspect/ME1_X360_CZ/DLC_Vegas_translation_cs.json'
OUTDIR = ROOT / 'ME1_X360_CZ_Pinnacle_v1'
OUTZIP = ROOT / 'ME1_X360_CZ_Pinnacle_v1.zip'
INNER_OUT = OUTDIR / 'DLC_Vegas_GlobalTlk_CZ.xxx'

SECTOR = 0x1000


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


stfsmod = load_module('me1_stfs_pinnacle_v1', ROOT / 'patch_me1_x360_cz.py')
v4 = load_module('me1_tlk_pinnacle_v1', ROOT / 'build_me1_x360_cz_base_v4.py')


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        while chunk := f.read(1024 * 1024):
            h.update(chunk)
    return h.hexdigest()


def p24le(value: int) -> bytes:
    return bytes((value & 0xFF, (value >> 8) & 0xFF, (value >> 16) & 0xFF))


def p24be(value: int) -> bytes:
    return bytes(((value >> 16) & 0xFF, (value >> 8) & 0xFF, value & 0xFF))


def hash_record_offset(stfs, block_num: int) -> int:
    return stfs.hash_offset(block_num, 0) + stfs.hash_record(block_num, 0) * 0x18


def set_chain_record(fp, stfs, block_num: int, next_block: int) -> None:
    off = hash_record_offset(stfs, block_num)
    fp.seek(off + 20)
    fp.write(bytes([0x80]) + p24be(next_block))


def patch_dir_entry(fp, stfs, entry, *, valid_blocks=None, alloc_blocks=None,
                    start_block=None, size=None) -> None:
    off = stfs.data_offset(entry.dir_block) + entry.dir_pos
    fp.seek(off)
    cur = bytearray(fp.read(0x40))
    if len(cur) != 0x40:
        raise IOError('Short STFS directory entry')
    if valid_blocks is not None:
        cur[41:44] = p24le(valid_blocks)
    if alloc_blocks is not None:
        cur[44:47] = p24le(alloc_blocks)
    if start_block is not None:
        cur[47:50] = p24le(start_block)
    if size is not None:
        cur[52:56] = struct.pack('>I', size)
    fp.seek(off)
    fp.write(cur)


def build_czech_inner(original: bytes) -> tuple[bytes, dict]:
    if len(original) < 129:
        raise RuntimeError('Pinnacle talk table package is unexpectedly short')
    compression_type = struct.unpack_from('>i', original, 117)[0]
    chunk_count = struct.unpack_from('>i', original, 121)[0]
    if compression_type != 0 or chunk_count != 0:
        raise RuntimeError(
            f'Expected original Pinnacle package to be uncompressed, got type={compression_type}, chunks={chunk_count}'
        )

    tables = v4.parse_package_tables(original, '>')
    names = tables['names']
    exports = tables['exports']
    expected = ['GlobalTlk_tlk', 'GlobalTlk_tlk_M']
    actual = [names[e.name_index] for e in exports]
    if actual != expected:
        raise RuntimeError(f'Unexpected Pinnacle package exports: {actual}')

    translations = json.loads(TRANSLATIONS.read_text(encoding='utf-8'))
    if not isinstance(translations, dict):
        raise RuntimeError('Pinnacle translation source is not a JSON object')

    new_tlks: list[bytes] = []
    translated_maps: list[dict[int, str]] = []
    original_prefixes: list[bytes] = []
    coverage = []

    for gender in range(2):
        oe = exports[gender]
        prefix, original_entries, original_stats = v4.parse_tlk_export(
            original[oe.data_offset:oe.data_offset + oe.data_size], '>'
        )
        missing = []
        merged = []
        for entry in original_entries:
            text = entry.text
            if entry.flags == 1:
                if text not in translations:
                    missing.append({'string_id': entry.string_id, 'english': text})
                else:
                    text = translations[text]
            merged.append(v4.TlkEntry(entry.string_id, entry.flags, entry.index, text))
        if missing:
            raise RuntimeError(
                f'Gender {gender}: {len(missing)} active Pinnacle strings are missing in Czech source; first={missing[:3]}'
            )

        blob = v4.build_tlk_export(prefix, merged)
        new_tlks.append(blob)
        translated_maps.append({e.string_id: e.text for e in merged if e.flags == 1})
        original_prefixes.append(prefix)
        coverage.append({
            'gender': gender,
            'entry_count': len(merged),
            'active_count': sum(e.flags == 1 for e in merged),
            'unique_source_strings': len({e.text for e in original_entries if e.flags == 1}),
            'translated_source_strings': len({e.text for e in original_entries if e.flags == 1}),
            'old_export_size': oe.data_size,
            'new_export_size': len(blob),
            'original_tlk_stats': original_stats,
        })

    # Preserve the exact original package header, tables and old payloads. Append the
    # two rebuilt Czech TLKs and redirect only DataSize/DataOffset in the export table.
    logical = bytearray(original)
    offsets: list[int] = []
    for blob in new_tlks:
        offsets.append(len(logical))
        logical += blob
    for i, blob in enumerate(new_tlks):
        struct.pack_into('>ii', logical, exports[i].start + 32, len(blob), offsets[i])
    output = bytes(logical)

    # Complete semantic round trip.
    rebuilt_tables = v4.parse_package_tables(output, '>')
    if rebuilt_tables['names'] != names:
        raise RuntimeError('Pinnacle package name table changed')
    if rebuilt_tables['import_count'] != tables['import_count'] or rebuilt_tables['export_count'] != 2:
        raise RuntimeError('Pinnacle package import/export identity changed')
    for i in range(2):
        e = rebuilt_tables['exports'][i]
        prefix, entries, stats = v4.parse_tlk_export(
            output[e.data_offset:e.data_offset + e.data_size], '>'
        )
        if prefix != original_prefixes[i]:
            raise RuntimeError(f'Gender {i}: TLK property prefix changed')
        decoded = {x.string_id: x.text for x in entries if x.flags == 1}
        if decoded != translated_maps[i]:
            raise RuntimeError(f'Gender {i}: translated TLK round-trip mismatch')
        if stats['active_count'] != coverage[i]['active_count']:
            raise RuntimeError(f'Gender {i}: active-string count changed')

    # The original prefix and all old data remain byte-identical except for the two
    # export table DataSize/DataOffset pairs.
    allowed = set()
    for e in exports:
        allowed.update(range(e.start + 32, e.start + 40))
    changed_prefix = [i for i, (a, b) in enumerate(zip(original, output[:len(original)])) if a != b]
    if any(i not in allowed for i in changed_prefix):
        raise RuntimeError('Unexpected modification inside original Pinnacle package prefix')

    return output, {
        'source_inner_sha256': sha256_bytes(original),
        'output_inner_sha256': sha256_bytes(output),
        'source_inner_size': len(original),
        'output_inner_size': len(output),
        'compression_type': 0,
        'chunk_count': 0,
        'coverage': coverage,
        'changed_original_prefix_bytes': len(changed_prefix),
        'appended_tlk_offsets': offsets,
        'required_stfs_blocks': (len(output) + SECTOR - 1) // SECTOR,
    }


def write_contiguous_payload(fp, stfs, start_block: int, block_count: int, data: bytes) -> None:
    if len(data) > block_count * SECTOR:
        raise RuntimeError('Payload does not fit selected contiguous STFS allocation')
    for i in range(block_count):
        piece = data[i * SECTOR:(i + 1) * SECTOR].ljust(SECTOR, b'\0')
        fp.seek(stfs.data_offset(start_block + i))
        fp.write(piece)
        set_chain_record(
            fp, stfs, start_block + i,
            start_block + i + 1 if i + 1 < block_count else 0xFFFFFF,
        )


def patch_stfs(inner: bytes) -> tuple[Path, dict]:
    src = ORIGINAL_DLC
    stfs = stfsmod.STFS(src)
    if stfs.title_id != 0x4D5307E8 or stfs.content_type != 2:
        raise RuntimeError('Unexpected Pinnacle Station STFS identity')

    english = stfs.entry_by_path('Content/Packages/Dialog/DLC_Vegas_GlobalTlk.xxx')
    # Large Spanish-only package. Its contiguous allocation is reused for the Czech
    # INT talk table, avoiding a fragmented cross-file chain.
    donor = stfs.entry_by_path('Content/Packages/Localised/ES/bioa_prc2_ccscoreboard_dsg_ES.xxx')
    required = (len(inner) + SECTOR - 1) // SECTOR
    if required > donor.alloc_blocks:
        raise RuntimeError(
            f'Czech package needs {required} blocks, donor has only {donor.alloc_blocks}'
        )

    tmp = OUTDIR / '.pinnacle_cz.tmp'
    shutil.copyfile(src, tmp)
    used_blocks = list(range(donor.start_block, donor.start_block + required))
    modified_data = set(used_blocks)
    modified_data.add(english.dir_block)
    modified_data.add(donor.dir_block)

    with tmp.open('r+b') as fp:
        write_contiguous_payload(fp, stfs, donor.start_block, required, inner)
        patch_dir_entry(
            fp, stfs, english,
            valid_blocks=required, alloc_blocks=required,
            start_block=donor.start_block, size=len(inner),
        )
        patch_dir_entry(
            fp, stfs, donor,
            valid_blocks=0, alloc_blocks=0,
            start_block=0xFFFFFF, size=0,
        )
        stfsmod.rehash(fp, stfs, modified_data)

    content_id = stfsmod.verify_stfs(tmp, modified_data)
    final = OUTDIR / content_id
    if final.exists():
        final.unlink()
    tmp.rename(final)

    check = stfsmod.STFS(final)
    check_english = check.entry_by_path('Content/Packages/Dialog/DLC_Vegas_GlobalTlk.xxx')
    extracted = check.read_file(check_english)
    if extracted != inner:
        raise RuntimeError('Patched Pinnacle STFS payload does not match generated Czech package')
    if check_english.start_block != donor.start_block or check_english.alloc_blocks != required:
        raise RuntimeError('Patched Pinnacle directory entry points to an unexpected allocation')

    donor_check = check.entry_by_path('Content/Packages/Localised/ES/bioa_prc2_ccscoreboard_dsg_ES.xxx')
    if donor_check.size != 0 or donor_check.alloc_blocks != 0 or donor_check.start_block != 0xFFFFFF:
        raise RuntimeError('Spanish donor directory entry was not deallocated correctly')

    with final.open('rb') as fp:
        for i, block in enumerate(used_blocks):
            fp.seek(hash_record_offset(check, block) + 20)
            status = fp.read(1)[0]
            nxt = int.from_bytes(fp.read(3), 'big')
            expected_next = used_blocks[i + 1] if i + 1 < len(used_blocks) else 0xFFFFFF
            if status != 0x80 or nxt != expected_next:
                raise RuntimeError(
                    f'Invalid Pinnacle allocation chain at block {block}: status={status:02X}, next={nxt:06X}'
                )

    return final, {
        'source_stfs_sha256': sha256_file(src),
        'source_content_id': stfs.content_id.hex().upper(),
        'output_stfs_sha256': sha256_file(final),
        'output_content_id': content_id,
        'output_file': final.name,
        'inner_path': english.path,
        'inner_size': len(inner),
        'required_blocks': required,
        'allocation_start': donor.start_block,
        'allocation_last': donor.start_block + required - 1,
        'donor_path': donor.path,
        'donor_original_blocks': donor.alloc_blocks,
        'donor_language_impact': 'The Spanish-only scoreboard package is removed; English/INT gameplay is the supported mode.',
    }


def main() -> None:
    OUTDIR.mkdir(parents=True, exist_ok=True)
    stfs = stfsmod.STFS(ORIGINAL_DLC)
    original_inner = stfs.read_file(
        stfs.entry_by_path('Content/Packages/Dialog/DLC_Vegas_GlobalTlk.xxx')
    )
    inner, inner_report = build_czech_inner(original_inner)
    INNER_OUT.write_bytes(inner)
    final, stfs_report = patch_stfs(inner)

    report = {
        'build': 'Mass Effect 1 Xbox 360 – Pinnacle Station Czech v1',
        'runtime_basis': {
            'base_v6': 'PASS on real Xbox 360',
            'huffman_rebuild': 'PASS on real Xbox 360',
            'diacritics': 'PASS on real Xbox 360',
            'relocated_tlk_exports': 'PASS on real Xbox 360',
            'pinnacle_dlc_runtime': 'PENDING XBOX 360 TEST',
        },
        'source_dlc_file': ORIGINAL_DLC.name,
        'source_dlc_sha256': sha256_file(ORIGINAL_DLC),
        'translation_source': str(TRANSLATIONS),
        'inner_package': inner_report,
        'stfs': stfs_report,
        'checks': [
            'all 1412 active Pinnacle Station entries translated in both gender tables',
            'all 1077 unique source strings covered by the Czech translation map',
            'original Xbox package names/imports/exports preserved',
            'original package remains uncompressed as shipped by the DLC',
            'new Czech TLKs appended and only export DataSize/DataOffset fields redirected',
            'both rebuilt TLKs decoded back and matched the Czech string maps',
            'Czech package stored in one contiguous Spanish-only donor allocation',
            'full STFS L0/L1/L2 hash tree and Content ID verified',
            'STFS extraction exactly matches the generated Czech inner package',
        ],
        'runtime_status': 'PENDING XBOX 360 TEST',
    }
    (OUTDIR / 'validation.json').write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8'
    )

    readme = f'''Mass Effect 1 Xbox 360 – Pinnacle Station česky v1\n\nTOTO JE PRVNÍ SAMOSTATNÝ TEST PINNACLE STATION.\nZákladní hru ponech s ověřeným českým GlobalTlk.xxx v6.\nBring Down the Sky může zůstat v české testovací verzi v1 nebo originální.\n\nInstalace:\n1. Zálohuj původní Pinnacle Station:\n   Hdd1:/Content/0000000000000000/4D5307E8/00000002/{ORIGINAL_DLC.name}\n2. Původní soubor odstraň a nahraď jej souborem:\n   {final.name}\n3. Proveď úplné vypnutí a zapnutí konzole.\n4. Až se ve hře dostaneš k Pinnacle Station, ověř dialogy, nabídky simulátoru a popisy misí.\n\nDůležité: upravený balíček využívá místo jednoho španělského lokalizovaného balíčku.\nČeská lokalizace je určena pro anglický/INT režim. Španělská lokalizace tohoto upraveného DLC nebude úplná.\n\nSHA-256 upraveného DLC:\n{sha256_file(final)}\n\nContent ID / název souboru:\n{final.name}\n'''
    (OUTDIR / 'README_INSTALACE.txt').write_text(readme, encoding='utf-8')

    if OUTZIP.exists():
        OUTZIP.unlink()
    with zipfile.ZipFile(OUTZIP, 'w', zipfile.ZIP_DEFLATED, allowZip64=True) as zf:
        zf.write(final, final.name)
        zf.write(INNER_OUT, INNER_OUT.name)
        zf.write(OUTDIR / 'validation.json', 'validation.json')
        zf.write(OUTDIR / 'README_INSTALACE.txt', 'README_INSTALACE.txt')
        zf.write(Path(__file__), Path(__file__).name)

    print(json.dumps(report, ensure_ascii=False, indent=2))
    print('OUTPUT', final)
    print('ZIP', OUTZIP)


if __name__ == '__main__':
    main()
