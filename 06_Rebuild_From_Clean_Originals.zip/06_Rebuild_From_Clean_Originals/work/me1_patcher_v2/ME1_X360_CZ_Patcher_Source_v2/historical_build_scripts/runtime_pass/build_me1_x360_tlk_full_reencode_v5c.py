#!/usr/bin/env python3
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from pathlib import Path
import hashlib
import heapq
import importlib.util
import json
import shutil
import struct
import sys
import zipfile

ROOT = Path('/mnt/data')
SRC = ROOT / 'GlobalTlk.xxx'
OUTDIR = ROOT / 'ME1_X360_TLK_Full_Reencode_v5c'
OUT = OUTDIR / 'GlobalTlk.xxx'
OUTZIP = ROOT / 'ME1_X360_TLK_Full_Reencode_v5c.zip'

spec = importlib.util.spec_from_file_location('lzoctl', ROOT / 'build_me1_xenon_lzo_control.py')
lzoctl = importlib.util.module_from_spec(spec)
sys.modules['lzoctl'] = lzoctl
assert spec.loader is not None
spec.loader.exec_module(lzoctl)

spec2 = importlib.util.spec_from_file_location('basev4', ROOT / 'build_me1_x360_cz_base_v4.py')
basev4 = importlib.util.module_from_spec(spec2)
sys.modules['basev4'] = basev4
assert spec2.loader is not None
spec2.loader.exec_module(basev4)


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


@dataclass
class Node:
    char: str | None
    freq: int
    left: 'Node | None' = None
    right: 'Node | None' = None
    node_id: int = -1

    @property
    def leaf(self) -> bool:
        return self.char is not None


def parse_raw_tlk(blob: bytes):
    prefix = blob[:40]
    pos = 40
    entry_count = struct.unpack_from('>i', blob, pos)[0]
    pos += 4
    entries = []
    for _ in range(entry_count):
        entries.append(struct.unpack_from('>iii', blob, pos))
        pos += 12

    node_count = struct.unpack_from('>i', blob, pos)[0]
    pos += 4
    nodes = []
    for _ in range(node_count):
        leaf = blob[pos] != 0
        pos += 1
        if leaf:
            cp = struct.unpack_from('>H', blob, pos)[0]
            pos += 2
            nodes.append(('leaf', chr(cp)))
        else:
            right, left = struct.unpack_from('>hh', blob, pos)
            pos += 4
            nodes.append(('node', right, left))

    string_count = struct.unpack_from('>i', blob, pos)[0]
    pos += 4
    strings = []
    slots = []
    for _ in range(string_count):
        header_pos = pos
        string_length, encoded_length = struct.unpack_from('>ii', blob, pos)
        pos += 8
        payload = blob[pos:pos + encoded_length]
        pos += encoded_length
        text = decode_payload(payload, nodes)
        strings.append(text)
        slots.append((header_pos, string_length, encoded_length))
    if pos != len(blob):
        raise ValueError(f'Raw TLK parse ended at {pos}, expected {len(blob)}')
    return prefix, entries, strings, node_count, slots




def decode_payload(payload: bytes, nodes):
    cur = 0
    chars = []
    for bit_pos in range(len(payload) * 8):
        node = nodes[cur]
        if node[0] == 'leaf':
            ch = node[1]
            if ch == '\0':
                return ''.join(chars)
            chars.append(ch)
            cur = 0
            # Re-process the same bit from the root, matching the game decoder's i--.
            node = nodes[cur]
        bit = (payload[bit_pos // 8] >> (bit_pos % 8)) & 1
        cur = node[1] if bit else node[2]
    # Xbox/LegendaryExplorer accepts a leaf reached exactly on the final bit.
    node = nodes[cur]
    if node[0] == 'leaf' and node[1] == '\0':
        return ''.join(chars)
    if node[0] == 'leaf':
        chars.append(node[1])
    raise ValueError('unterminated Huffman string')

def build_tree(strings: list[str]):
    freq = Counter()
    for text in strings:
        freq.update(text + '\0')
    if not freq:
        raise ValueError('empty TLK string set')

    heap = []
    serial = 0
    for ch in sorted(freq):
        heapq.heappush(heap, (freq[ch], serial, Node(ch, freq[ch])))
        serial += 1
    while len(heap) > 1:
        f1, _s1, left = heapq.heappop(heap)
        f2, _s2, right = heapq.heappop(heap)
        parent = Node(None, f1 + f2, left=left, right=right)
        heapq.heappush(heap, (parent.freq, serial, parent))
        serial += 1
    root = heap[0][2]

    codes: dict[str, list[int]] = {}
    def walk(node: Node, path: list[int]):
        if node.leaf:
            codes[node.char] = path[:] if path else [0]
            return
        assert node.left is not None and node.right is not None
        walk(node.left, path + [0])
        walk(node.right, path + [1])
    walk(root, [])
    return root, codes


def serialize_tree(root: Node) -> bytes:
    queue = [root]
    nodes = []
    while queue:
        node = queue.pop(0)
        node.node_id = len(nodes)
        nodes.append(node)
        if not node.leaf:
            assert node.right is not None and node.left is not None
            queue.append(node.right)
            queue.append(node.left)

    out = bytearray(struct.pack('>i', len(nodes)))
    for node in nodes:
        if node.leaf:
            cp = ord(node.char)
            if cp > 0xFFFF:
                raise ValueError(f'non-BMP character U+{cp:06X}')
            out.append(1)
            out += struct.pack('>H', cp)
        else:
            assert node.right is not None and node.left is not None
            out.append(0)
            out += struct.pack('>hh', node.right.node_id, node.left.node_id)
    return bytes(out)


def encode(text: str, codes: dict[str, list[int]]) -> bytes:
    bits = []
    for ch in text + '\0':
        bits.extend(codes[ch])
    out = bytearray((len(bits) + 7) // 8)
    for i, bit in enumerate(bits):
        if bit:
            out[i // 8] |= 1 << (i % 8)
    return bytes(out)


def rebuild_tlk_exact_size(blob: bytes):
    prefix, entries, strings, old_node_count, old_slots = parse_raw_tlk(blob)
    root, codes = build_tree(strings)
    tree = serialize_tree(root)

    out = bytearray(prefix)
    out += struct.pack('>i', len(entries))
    for sid, flags, index in entries:
        out += struct.pack('>iii', sid, flags, index)
    out += tree
    out += struct.pack('>i', len(strings))

    payloads = [encode(text, codes) for text in strings]
    base_size = len(out) + sum(8 + len(p) for p in payloads)
    slack = len(blob) - base_size
    if slack < 0:
        raise RuntimeError(f'reencoded English TLK exceeds original slot by {-slack} bytes')

    for i, (text, payload) in enumerate(zip(strings, payloads)):
        if i == len(payloads) - 1:
            payload = payload + b'\0' * slack
        out += struct.pack('>ii', len(text) + 1, len(payload))
        out += payload

    if len(out) != len(blob):
        raise RuntimeError((len(out), len(blob)))

    # Validate the complete rebuilt raw string array and active StringRef mapping.
    _p2, entries2, strings2, new_node_count, _slots2 = parse_raw_tlk(bytes(out))
    if entries2 != entries or strings2 != strings:
        raise RuntimeError('full TLK re-encode decode mismatch')

    return bytes(out), {
        'entry_count': len(entries),
        'string_count': len(strings),
        'old_node_count': old_node_count,
        'new_node_count': new_node_count,
        'slot_size': len(blob),
        'unpadded_reencoded_size': base_size,
        'padding_added_to_last_payload': slack,
        'active_count': sum(flags == 1 for _sid, flags, _index in entries),
    }


def main():
    src_pkg = SRC.read_bytes()
    logical, source_records, source_blocks, _ = lzoctl.decompress_package(src_pkg)
    tables = basev4.parse_package_tables(logical, '>')
    names = tables['names']
    exports = tables['exports']
    expected = ['GlobalTlk_tlk', 'GlobalTlk_tlk_M', 'SeekFreeSaver', 'SeekFreeShaderCache']
    if [names[e.name_index] for e in exports] != expected:
        raise RuntimeError('unexpected export layout')

    patched = bytearray(logical)
    reports = []
    for exp in exports[:2]:
        old_blob = logical[exp.data_offset:exp.data_offset + exp.data_size]
        new_blob, report = rebuild_tlk_exact_size(old_blob)
        patched[exp.data_offset:exp.data_offset + exp.data_size] = new_blob
        report['export_name'] = names[exp.name_index]
        report['offset_unchanged'] = exp.data_offset
        report['size_unchanged'] = exp.data_size
        reports.append(report)

    # Helpers and the complete package layout must remain exactly where they were.
    for exp in exports[2:]:
        old = logical[exp.data_offset:exp.data_offset + exp.data_size]
        new = patched[exp.data_offset:exp.data_offset + exp.data_size]
        if old != new:
            raise RuntimeError(f'helper export changed: {names[exp.name_index]}')

    package_source_pos = 125 + 16 * len(source_records)
    package_source = src_pkg[package_source_pos:package_source_pos + 4]
    output_pkg, built_chunks = lzoctl.build_control(src_pkg, bytes(patched), source_records, package_source)
    rebuilt_logical, rebuilt_records, rebuilt_blocks, _ = lzoctl.decompress_package(output_pkg)
    if rebuilt_logical != bytes(patched):
        raise RuntimeError('LZO logical round-trip mismatch')
    if len(rebuilt_logical) != len(logical):
        raise RuntimeError('logical package size changed')

    # Reparse final package and prove every raw string and active mapping is still original English.
    final_tables = basev4.parse_package_tables(rebuilt_logical, '>')
    for i, exp in enumerate(final_tables['exports'][:2]):
        _np, new_entries, new_strings, _nn, _ns = parse_raw_tlk(
            rebuilt_logical[exp.data_offset:exp.data_offset + exp.data_size]
        )
        old_exp = exports[i]
        _op, old_entries, old_strings, _on, _os = parse_raw_tlk(
            logical[old_exp.data_offset:old_exp.data_offset + old_exp.data_size]
        )
        if new_entries != old_entries or new_strings != old_strings:
            raise RuntimeError(f'English content changed in export {i}')

    OUTDIR.mkdir(parents=True, exist_ok=True)
    OUT.write_bytes(output_pkg)
    shutil.copy2(SRC, OUTDIR / 'GlobalTlk_original_backup.xxx')
    shutil.copy2(Path(__file__), OUTDIR / Path(__file__).name)

    validation = {
        'build': 'ME1 Xbox 360 full TLK re-encode control v5c',
        'purpose': 'Isolate complete Huffman/tree/string serialization while preserving every package/export offset and size.',
        'expected_runtime': 'Game boots normally and remains fully English.',
        'source_sha256': sha256(src_pkg),
        'output_sha256': sha256(output_pkg),
        'source_size': len(src_pkg),
        'output_size': len(output_pkg),
        'logical_size_unchanged': len(rebuilt_logical) == len(logical),
        'package_header_tables_unchanged': True,
        'all_export_offsets_sizes_unchanged': True,
        'helper_exports_byte_identical': True,
        'all_active_English_StringRefs_identical_after_decode': True,
        'tlk_exports': reports,
        'chunk_records': rebuilt_records,
        'blocks': rebuilt_blocks,
        'runtime_status': 'PENDING XBOX 360 TEST',
    }
    (OUTDIR / 'validation.json').write_text(json.dumps(validation, ensure_ascii=False, indent=2), encoding='utf-8')
    (OUTDIR / 'README_CS.txt').write_text(
        'Mass Effect 1 Xbox 360 – úplný kontrolní přepis TLK v5c\n\n'
        'Tato verze je záměrně stále ANGLICKY. Obě talk table byly kompletně znovu sestaveny, '
        'včetně nového Huffmanova stromu a všech 7000 uložených textů.\n'
        'Současně zůstaly beze změny velikosti a offsety všech čtyř exportů, celý layout balíčku '
        'a oba pomocné exporty.\n\n'
        'Test:\n'
        '1. Nahraď pouze Hdd1:/Games/Mass Effect 1/Layer0/MEInit/GlobalTlk.xxx.\n'
        '2. Oficiální DLC nech originální a stará experimentální česká DLC odstraň.\n'
        '3. Proveď úplný restart konzole.\n\n'
        'Očekávání: hra normálně naběhne a zůstane anglicky.\n'
        'Úspěch potvrdí, že Xbox přijímá kompletně nově vytvořený Huffmanův strom a problém v4 '
        'způsobilo zvětšení/přesunutí exportů, nikoliv samotná serializace TLK.\n',
        encoding='utf-8'
    )
    with zipfile.ZipFile(OUTZIP, 'w', zipfile.ZIP_DEFLATED) as z:
        for p in sorted(OUTDIR.iterdir()):
            z.write(p, p.name)

    print(json.dumps(validation, ensure_ascii=False, indent=2))
    print(OUT)
    print(OUTZIP)


if __name__ == '__main__':
    main()
