#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import ctypes, hashlib, json, struct, zipfile, shutil

SRC = Path('/mnt/data/GlobalTlk.xxx')
OUTDIR = Path('/mnt/data/ME1_X360_LZO_Control_v3')
OUT = OUTDIR / 'GlobalTlk.xxx'
ZIP = Path('/mnt/data/ME1_X360_LZO_Control_v3.zip')

MAGIC = 0x9E2A83C1
BLOCK_SIZE = 0x20000

lib = ctypes.CDLL('liblzo2.so.2')
_lzo_dec = lib.lzo1x_decompress_safe
_lzo_dec.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p, ctypes.POINTER(ctypes.c_size_t), ctypes.c_void_p]
_lzo_dec.restype = ctypes.c_int
_lzo_comp = lib.lzo1x_1_compress
_lzo_comp.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p, ctypes.POINTER(ctypes.c_size_t), ctypes.c_void_p]
_lzo_comp.restype = ctypes.c_int


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def lzo_decompress(data: bytes, expected_size: int) -> bytes:
    src = ctypes.create_string_buffer(data)
    dst = ctypes.create_string_buffer(expected_size)
    out_len = ctypes.c_size_t(expected_size)
    rc = _lzo_dec(src, len(data), dst, ctypes.byref(out_len), None)
    if rc != 0 or out_len.value != expected_size:
        raise RuntimeError(f'LZO decompress failed: rc={rc}, out={out_len.value}, expected={expected_size}')
    return dst.raw[:out_len.value]


def lzo_compress(data: bytes) -> bytes:
    # LZO documented worst-case output bound.
    cap = len(data) + len(data) // 16 + 64 + 3
    src = ctypes.create_string_buffer(data)
    dst = ctypes.create_string_buffer(cap)
    out_len = ctypes.c_size_t(cap)
    # More than enough for LZO1X_1_MEM_COMPRESS on 64-bit builds.
    work = ctypes.create_string_buffer(1024 * 1024)
    rc = _lzo_comp(src, len(data), dst, ctypes.byref(out_len), work)
    if rc != 0:
        raise RuntimeError(f'LZO compress failed: rc={rc}')
    out = dst.raw[:out_len.value]
    if lzo_decompress(out, len(data)) != data:
        raise RuntimeError('LZO round-trip mismatch')
    return out


def read_chunk_records(pkg: bytes):
    ctype, count = struct.unpack_from('>ii', pkg, 117)
    if ctype != 2:
        raise ValueError(f'Expected UE3 LZO compression type 2, got {ctype}')
    records = []
    pos = 125
    for _ in range(count):
        records.append(struct.unpack_from('>iiii', pkg, pos))
        pos += 16
    package_source = pkg[pos:pos+4]
    return ctype, records, package_source, pos + 4


def decompress_package(pkg: bytes):
    _, records, _, physical_header_size = read_chunk_records(pkg)
    logical_size = max(uoff + usize for uoff, usize, _, _ in records)
    logical = bytearray(logical_size)
    # Bytes before first compressed range are stored directly in package header.
    first_uoff = min(r[0] for r in records)
    logical[:first_uoff] = pkg[:first_uoff]
    block_meta = []
    for ci, (uoff, usize, coff, csize) in enumerate(records):
        chunk = pkg[coff:coff+csize]
        if len(chunk) != csize:
            raise ValueError(f'Truncated chunk {ci}')
        m1, m2, payload_csize, total_usize = struct.unpack_from('>IIII', chunk, 0)
        if (m1, m2) != (MAGIC, MAGIC) or total_usize != usize:
            raise ValueError(f'Invalid chunk header {ci}')
        block_count = (usize + BLOCK_SIZE - 1) // BLOCK_SIZE
        table_end = 16 + block_count * 8
        pos = table_end
        out = bytearray()
        metas = []
        for bi in range(block_count):
            bcs, bus = struct.unpack_from('>II', chunk, 16 + bi * 8)
            comp = chunk[pos:pos+bcs]
            pos += bcs
            raw = lzo_decompress(comp, bus)
            out += raw
            metas.append({'compressed_size': bcs, 'uncompressed_size': bus})
        if pos != len(chunk):
            raise ValueError(f'Chunk {ci} length mismatch: {pos} != {len(chunk)}')
        if payload_csize != len(chunk) - table_end:
            raise ValueError(f'Chunk {ci} payload size mismatch')
        if len(out) != usize:
            raise ValueError(f'Chunk {ci} output mismatch')
        logical[uoff:uoff+usize] = out
        block_meta.append(metas)
    return bytes(logical), records, block_meta, physical_header_size


def build_chunk(raw: bytes):
    blocks = []
    payload = bytearray()
    table = bytearray()
    for pos in range(0, len(raw), BLOCK_SIZE):
        plain = raw[pos:pos+BLOCK_SIZE]
        comp = lzo_compress(plain)
        blocks.append((len(comp), len(plain)))
        table += struct.pack('>II', len(comp), len(plain))
        payload += comp
    header = struct.pack('>IIII', MAGIC, MAGIC, len(payload), len(raw))
    return header + table + payload, blocks


def build_control(src_pkg: bytes, logical: bytes, source_records, package_source: bytes):
    # Preserve the exact original uncompressed chunk partitioning.
    chunks = []
    physical_header_size = 125 + len(source_records) * 16 + 4
    cur = physical_header_size
    for uoff, usize, _old_coff, _old_csize in source_records:
        raw = logical[uoff:uoff+usize]
        chunk, blocks = build_chunk(raw)
        chunks.append({
            'uoff': uoff, 'usize': usize,
            'coff': cur, 'csize': len(chunk),
            'chunk': chunk, 'blocks': blocks,
        })
        cur += len(chunk)

    header = bytearray(src_pkg[:125])
    for c in chunks:
        header += struct.pack('>iiii', c['uoff'], c['usize'], c['coff'], c['csize'])
    header += package_source
    if len(header) != physical_header_size:
        raise AssertionError((len(header), physical_header_size))
    return bytes(header) + b''.join(c['chunk'] for c in chunks), chunks


def parse_summary(logical: bytes):
    full_header_size = struct.unpack_from('>i', logical, 8)[0]
    name_count, name_offset, export_count, export_offset, import_count, import_offset = struct.unpack_from('>iiiiii', logical, 25)
    return {
        'full_header_size': full_header_size,
        'name_count': name_count,
        'name_offset': name_offset,
        'export_count': export_count,
        'export_offset': export_offset,
        'import_count': import_count,
        'import_offset': import_offset,
        'logical_size': len(logical),
    }


def main():
    src_pkg = SRC.read_bytes()
    logical, source_records, source_blocks, source_phys_header = decompress_package(src_pkg)
    control, control_chunks = build_control(src_pkg, logical, source_records, src_pkg[125+16*len(source_records):125+16*len(source_records)+4])
    rebuilt_logical, rebuilt_records, rebuilt_blocks, rebuilt_phys_header = decompress_package(control)
    if rebuilt_logical != logical:
        raise RuntimeError('Rebuilt package does not reproduce original logical bytes')
    if parse_summary(rebuilt_logical) != parse_summary(logical):
        raise RuntimeError('Package table summary changed')

    OUTDIR.mkdir(parents=True, exist_ok=True)
    OUT.write_bytes(control)
    shutil.copy2(SRC, OUTDIR / 'GlobalTlk_original_backup.xxx')

    report = {
        'purpose': 'English control rebuild before inserting Czech text',
        'compression': 'UE3 compression type 2 / LZO1X',
        'source': {
            'size': len(src_pkg),
            'sha256': sha256(src_pkg),
            'chunk_records': source_records,
            'blocks': source_blocks,
        },
        'rebuilt': {
            'size': len(control),
            'sha256': sha256(control),
            'chunk_records': rebuilt_records,
            'blocks': rebuilt_blocks,
        },
        'logical': {
            'size': len(logical),
            'sha256': sha256(logical),
            'round_trip_identical': rebuilt_logical == logical,
            'summary': parse_summary(logical),
        },
        'checks': [
            'all original LZO blocks decompressed successfully',
            'all rebuilt LZO blocks decompressed successfully',
            'rebuilt uncompressed package is byte-for-byte identical to original',
            '113 names, 5 imports, 4 exports and helper exports are preserved implicitly by identical logical data',
        ],
        'runtime_status': 'pending Xbox 360 test',
    }
    (OUTDIR / 'validation.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    readme = f'''Mass Effect 1 Xbox 360 – LZO control rebuild v3\n\nThis is deliberately still ENGLISH. It is a diagnostic rebuild of the original GlobalTlk.xxx.\nThe complete uncompressed package is byte-for-byte identical to the original; only the LZO-compressed representation differs.\n\nTEST:\n1. Back up Hdd1:/Games/Mass Effect 1/Layer0/MEInit/GlobalTlk.xxx\n2. Copy this GlobalTlk.xxx into that path.\n3. Keep both official DLC original and disable all earlier experimental Czech DLC.\n4. Cold reboot the console and launch the game.\n\nExpected result: the game boots normally and remains English.\nIf it boots, the Xbox package writer/compressor is confirmed and the Czech TLK exports can be inserted safely in the next build.\n\nRebuilt SHA-256: {sha256(control)}\nOriginal SHA-256: {sha256(src_pkg)}\nRollback: restore GlobalTlk_original_backup.xxx.\n'''
    (OUTDIR / 'README.txt').write_text(readme, encoding='utf-8')

    with zipfile.ZipFile(ZIP, 'w', zipfile.ZIP_DEFLATED) as z:
        for p in sorted(OUTDIR.iterdir()):
            z.write(p, p.name)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    print('OUTPUT', OUT)
    print('ZIP', ZIP)

if __name__ == '__main__':
    main()
