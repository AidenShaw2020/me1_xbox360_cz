#!/usr/bin/env python3
from pathlib import Path
import importlib.util, sys, struct, hashlib, json, shutil, zipfile

ROOT = Path('/mnt/data')
SRC = ROOT / 'GlobalTlk.xxx'
OUTDIR = ROOT / 'ME1_X360_TLK_ASCII_InPlace_v5a'
OUT = OUTDIR / 'GlobalTlk.xxx'
OUTZIP = ROOT / 'ME1_X360_TLK_ASCII_InPlace_v5a.zip'
TARGET_INDEX = 214
NEW_TEXT = 'Cestina'  # ASCII-only diagnostic replacement for "Options"

# Runtime-proven LZO package reader/writer
spec = importlib.util.spec_from_file_location('lzoctl', ROOT / 'build_me1_xenon_lzo_control.py')
lzoctl = importlib.util.module_from_spec(spec)
sys.modules['lzoctl'] = lzoctl
assert spec.loader is not None
spec.loader.exec_module(lzoctl)

# Package/TLK table helpers
spec2 = importlib.util.spec_from_file_location('basev4', ROOT / 'build_me1_x360_cz_base_v4.py')
basev4 = importlib.util.module_from_spec(spec2)
sys.modules['basev4'] = basev4
assert spec2.loader is not None
spec2.loader.exec_module(basev4)


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def parse_raw_tlk(blob: bytes):
    pos = 40
    entry_count = struct.unpack_from('>i', blob, pos)[0]
    pos += 4
    entries = []
    for _ in range(entry_count):
        entries.append(struct.unpack_from('>iii', blob, pos))
        pos += 12

    node_count = struct.unpack_from('>i', blob, pos)[0]
    pos += 4
    nodes = []
    for _ in range(node_count):
        leaf = blob[pos] != 0
        pos += 1
        if leaf:
            cp = struct.unpack_from('>H', blob, pos)[0]
            pos += 2
            nodes.append(('leaf', chr(cp)))
        else:
            right, left = struct.unpack_from('>hh', blob, pos)
            pos += 4
            nodes.append(('node', right, left))

    string_count = struct.unpack_from('>i', blob, pos)[0]
    pos += 4
    strings = []
    for _ in range(string_count):
        header_pos = pos
        string_length, encoded_length = struct.unpack_from('>ii', blob, pos)
        pos += 8
        payload_pos = pos
        payload = blob[pos:pos + encoded_length]
        pos += encoded_length
        strings.append({
            'header_pos': header_pos,
            'payload_pos': payload_pos,
            'string_length': string_length,
            'encoded_length': encoded_length,
            'payload': payload,
        })
    if pos != len(blob):
        raise ValueError(f'TLK parse ended at {pos}, file size {len(blob)}')
    return entries, nodes, strings


def make_codes(nodes):
    codes = {}
    def walk(idx: int, path: list[int]):
        node = nodes[idx]
        if node[0] == 'leaf':
            codes[node[1]] = path[:]
            return
        # tuple is ('node', right, left); bit 0 selects left, bit 1 right
        walk(node[2], path + [0])
        walk(node[1], path + [1])
    walk(0, [])
    return codes


def encode_text(text: str, codes: dict[str, list[int]], byte_length: int) -> bytes:
    terminated = text + '\0'
    missing = sorted(set(terminated) - set(codes))
    if missing:
        raise ValueError(f'Characters not in original Xbox Huffman tree: {missing!r}')
    bits = []
    for ch in terminated:
        bits.extend(codes[ch])
    # Keep at least one look-ahead/padding bit after the NUL leaf.
    bits.append(0)
    if len(bits) > byte_length * 8:
        raise ValueError(f'Encoded text needs {len(bits)} bits, slot has only {byte_length * 8}')
    out = bytearray(byte_length)
    for i, bit in enumerate(bits):
        if bit:
            out[i // 8] |= 1 << (i % 8)
    return bytes(out)


def main():
    src_pkg = SRC.read_bytes()
    logical, source_records, source_blocks, _ = lzoctl.decompress_package(src_pkg)
    tables = basev4.parse_package_tables(logical, '>')
    names = tables['names']
    exports = tables['exports']
    if [names[e.name_index] for e in exports[:2]] != ['GlobalTlk_tlk', 'GlobalTlk_tlk_M']:
        raise ValueError('Unexpected TLK exports')

    patched = bytearray(logical)
    changes = []
    for gender, exp in enumerate(exports[:2]):
        blob = bytearray(logical[exp.data_offset:exp.data_offset + exp.data_size])
        entries, nodes, strings = parse_raw_tlk(blob)
        slot = strings[TARGET_INDEX]
        # Verify that this slot is the shared "Options" string in the original.
        _prefix, decoded_entries, _stats = basev4.parse_tlk_export(bytes(blob), '>')
        old_texts = sorted({e.text for e in decoded_entries if e.flags == 1 and e.index == TARGET_INDEX})
        if old_texts != ['Options']:
            raise ValueError(f'Index {TARGET_INDEX} is not Options: {old_texts}')

        codes = make_codes(nodes)
        payload = encode_text(NEW_TEXT, codes, slot['encoded_length'])
        # Cestina has 7 chars + NUL, same string_length as Options (7 + NUL).
        if len(NEW_TEXT) + 1 != slot['string_length']:
            struct.pack_into('>i', blob, slot['header_pos'], len(NEW_TEXT) + 1)
        blob[slot['payload_pos']:slot['payload_pos'] + slot['encoded_length']] = payload

        # Local semantic validation using the package parser.
        _p, check_entries, _s = basev4.parse_tlk_export(bytes(blob), '>')
        check_texts = sorted({e.text for e in check_entries if e.flags == 1 and e.index == TARGET_INDEX})
        if check_texts != [NEW_TEXT]:
            raise RuntimeError(f'Patched TLK did not decode as expected: {check_texts}')

        patched[exp.data_offset:exp.data_offset + exp.data_size] = blob
        changes.append({
            'gender_export': gender,
            'export_name': names[exp.name_index],
            'string_index': TARGET_INDEX,
            'old_text': old_texts[0],
            'new_text': NEW_TEXT,
            'slot_bytes': slot['encoded_length'],
            'export_size_unchanged': len(blob) == exp.data_size,
            'export_offset_unchanged': exp.data_offset,
        })

    # Recompress with exactly the proven original two-chunk partition.
    package_source_pos = 125 + 16 * len(source_records)
    package_source = src_pkg[package_source_pos:package_source_pos + 4]
    output_pkg, built_chunks = lzoctl.build_control(src_pkg, bytes(patched), source_records, package_source)
    rebuilt_logical, rebuilt_records, rebuilt_blocks, _ = lzoctl.decompress_package(output_pkg)
    if rebuilt_logical != bytes(patched):
        raise RuntimeError('Physical LZO round-trip mismatch')
    if len(rebuilt_logical) != len(logical):
        raise RuntimeError('Logical size changed')

    # Confirm only expected in-export bytes changed.
    diffs = [i for i, (a, b) in enumerate(zip(logical, rebuilt_logical)) if a != b]
    allowed = set()
    for exp in exports[:2]:
        blob = logical[exp.data_offset:exp.data_offset + exp.data_size]
        _, _, strings = parse_raw_tlk(blob)
        slot = strings[TARGET_INDEX]
        allowed.update(range(exp.data_offset + slot['payload_pos'], exp.data_offset + slot['payload_pos'] + slot['encoded_length']))
        allowed.update(range(exp.data_offset + slot['header_pos'], exp.data_offset + slot['header_pos'] + 4))
    unexpected = [x for x in diffs if x not in allowed]
    if unexpected:
        raise RuntimeError(f'Unexpected logical changes at {unexpected[:20]}')

    OUTDIR.mkdir(parents=True, exist_ok=True)
    OUT.write_bytes(output_pkg)
    shutil.copy2(SRC, OUTDIR / 'GlobalTlk_original_backup.xxx')
    shutil.copy2(Path(__file__), OUTDIR / Path(__file__).name)

    report = {
        'build': 'ME1 Xbox 360 TLK ASCII in-place smoke test v5a',
        'purpose': 'Isolate TLK payload modification from Czech diacritics, Huffman-tree rebuilding, export relocation and package growth.',
        'expected_runtime': 'Game boots normally and the Options label appears as Cestina.',
        'source_sha256': sha256(src_pkg),
        'output_sha256': sha256(output_pkg),
        'source_size': len(src_pkg),
        'output_size': len(output_pkg),
        'logical_size_unchanged': len(rebuilt_logical) == len(logical),
        'package_table_unchanged': True,
        'export_sizes_offsets_unchanged': True,
        'huffman_trees_unchanged': True,
        'new_characters_added': False,
        'new_text_is_ascii_only': True,
        'changes': changes,
        'logical_changed_byte_count': len(diffs),
        'chunk_records': rebuilt_records,
        'blocks': rebuilt_blocks,
        'validation': [
            'both patched strings decode locally as Cestina',
            'all export sizes and offsets remain unchanged',
            'helper exports remain at their original offsets and are byte-for-byte unchanged',
            'full LZO package round-trip passed',
            'only the two fixed-size string payload slots changed logically',
        ],
        'runtime_status': 'PENDING XBOX 360 TEST',
    }
    (OUTDIR / 'validation.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    (OUTDIR / 'README_CS.txt').write_text(
        'Mass Effect 1 Xbox 360 – TLK ASCII in-place smoke test v5a\n\n'
        'Tato verze NENÍ plná čeština. Mění pouze sdílený text Options na Cestina v ženské i mužské tabulce.\n'
        'Používá výhradně znaky už přítomné v originální anglické Huffmanově tabulce.\n'
        'Nemění Huffmanův strom, velikosti exportů, jejich offsety, pomocné exporty ani logickou velikost balíčku.\n\n'
        'Test:\n'
        '1. Nahraď pouze Hdd1:/Games/Mass Effect 1/Layer0/MEInit/GlobalTlk.xxx.\n'
        '2. Oficiální DLC ponech originální a vypni předchozí experimentální česká DLC.\n'
        '3. Proveď úplný restart konzole.\n\n'
        'Očekávání: hra naběhne a položka Options bude zobrazena jako Cestina.\n'
        'Pokud hra naběhne, přímá změna TLK payloadu je potvrzena a problém v4 není samotná cesta ani LZO.\n'
        'Pokud spadne, problém je v našem způsobu zápisu bitového payloadu, nikoli v české diakritice.\n',
        encoding='utf-8'
    )
    with zipfile.ZipFile(OUTZIP, 'w', zipfile.ZIP_DEFLATED) as z:
        for p in sorted(OUTDIR.iterdir()):
            z.write(p, p.name)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    print(OUT)
    print(OUTZIP)

if __name__ == '__main__':
    main()
