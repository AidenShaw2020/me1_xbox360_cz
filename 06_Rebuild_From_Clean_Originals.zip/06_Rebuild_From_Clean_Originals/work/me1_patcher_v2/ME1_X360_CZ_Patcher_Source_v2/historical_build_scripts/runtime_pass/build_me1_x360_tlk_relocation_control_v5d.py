#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import hashlib, importlib.util, json, shutil, struct, sys, zipfile

ROOT=Path('/mnt/data')
SRC=ROOT/'GlobalTlk.xxx'
OUTDIR=ROOT/'ME1_X360_TLK_Relocation_Control_v5d'
OUT=OUTDIR/'GlobalTlk.xxx'
OUTZIP=ROOT/'ME1_X360_TLK_Relocation_Control_v5d.zip'


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec)
    sys.modules[name]=mod
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod

lzo=load('lzoctl_v5d', ROOT/'build_me1_xenon_lzo_control.py')
v4=load('basev4_v5d', ROOT/'build_me1_x360_cz_base_v4.py')

def sha256(b:bytes)->str: return hashlib.sha256(b).hexdigest()

def patch_export_offset(header: bytearray, exp, new_offset:int):
    struct.pack_into('>i', header, exp.start+36, new_offset)

def build_multichunk(src_pkg:bytes, logical:bytes, ranges:list[tuple[int,int]], package_source:bytes):
    header_size=125+16*len(ranges)+4
    header=bytearray(src_pkg[:125])
    struct.pack_into('>i',header,121,len(ranges))
    chunks=[]; cur=header_size
    for uoff,usize in ranges:
        raw=logical[uoff:uoff+usize]
        if len(raw)!=usize: raise RuntimeError((uoff,usize,len(raw)))
        chunk,blocks=lzo.build_chunk(raw)
        chunks.append({'uoff':uoff,'usize':usize,'coff':cur,'csize':len(chunk),'chunk':chunk,'blocks':blocks})
        cur+=len(chunk)
    for c in chunks:
        header += struct.pack('>iiii',c['uoff'],c['usize'],c['coff'],c['csize'])
    header += package_source
    if len(header)!=header_size: raise RuntimeError((len(header),header_size))
    return bytes(header)+b''.join(c['chunk'] for c in chunks),chunks

def main():
    src=SRC.read_bytes()
    logical,src_records,src_blocks,_=lzo.decompress_package(src)
    tables=v4.parse_package_tables(logical,'>')
    ex=tables['exports']; names=tables['names']
    expected=['GlobalTlk_tlk','GlobalTlk_tlk_M','SeekFreeSaver','SeekFreeShaderCache']
    if [names[e.name_index] for e in ex]!=expected: raise RuntimeError('unexpected exports')

    tlk0=logical[ex[0].data_offset:ex[0].data_offset+ex[0].data_size]
    tlk1=logical[ex[1].data_offset:ex[1].data_offset+ex[1].data_size]
    helper2=logical[ex[2].data_offset:ex[2].data_offset+ex[2].data_size]
    helper3=logical[ex[3].data_offset:ex[3].data_offset+ex[3].data_size]

    patched=bytearray(logical)
    off0=len(patched)
    patched += tlk0
    off1=len(patched)
    patched += tlk1
    patch_export_offset(patched,ex[0],off0)
    patch_export_offset(patched,ex[1],off1)
    # The physical compressed header now has four chunk records; mirror the count in the logical package prefix.
    struct.pack_into('>i', patched, 121, 4)
    logical2=bytes(patched)

    # Keep each UE3 compression chunk below 1 MiB and preserve the two original ranges.
    ranges=[(uoff,usize) for uoff,usize,_coff,_csize in src_records]
    ranges += [(off0,len(tlk0)),(off1,len(tlk1))]
    package_source=src[125+16*len(src_records):125+16*len(src_records)+4]
    out,chunks=build_multichunk(src,logical2,ranges,package_source)

    rt,records,blocks,_=lzo.decompress_package(out)
    if rt!=logical2: raise RuntimeError('LZO roundtrip mismatch')
    t2=v4.parse_package_tables(rt,'>'); ex2=t2['exports']
    if ex2[0].data_offset!=off0 or ex2[1].data_offset!=off1: raise RuntimeError('offset patch failed')
    if ex2[0].data_size!=len(tlk0) or ex2[1].data_size!=len(tlk1): raise RuntimeError('sizes changed')
    for i,blob in [(0,tlk0),(1,tlk1),(2,helper2),(3,helper3)]:
        e=ex2[i]; got=rt[e.data_offset:e.data_offset+e.data_size]
        if got!=blob: raise RuntimeError(f'export {i} mismatch')
    if ex2[2].data_offset!=ex[2].data_offset or ex2[3].data_offset!=ex[3].data_offset:
        raise RuntimeError('helper offsets changed')

    OUTDIR.mkdir(parents=True,exist_ok=True)
    OUT.write_bytes(out)
    shutil.copy2(SRC,OUTDIR/'GlobalTlk_original_backup.xxx')
    shutil.copy2(Path(__file__),OUTDIR/Path(__file__).name)
    report={
      'build':'ME1 Xbox 360 TLK relocation control v5d',
      'purpose':'Test whether the two BioTlkFile exports may be relocated after the original package while helper exports remain at their original offsets.',
      'expected_runtime':'Game boots normally and remains English.',
      'source_sha256':sha256(src),'output_sha256':sha256(out),
      'source_size':len(src),'output_size':len(out),
      'logical_source_size':len(logical),'logical_output_size':len(logical2),
      'exports':[{'name':names[e.name_index],'old_offset':ex[i].data_offset,'new_offset':ex2[i].data_offset,'size':ex2[i].data_size} for i,e in enumerate(ex2)],
      'helper_offsets_unchanged':True,
      'all_export_payloads_byte_identical':True,
      'chunk_records':records,'blocks':blocks,
      'runtime_status':'PENDING XBOX 360 TEST'
    }
    (OUTDIR/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    (OUTDIR/'README_CS.txt').write_text(f'''Mass Effect 1 Xbox 360 – kontrolní přesun TLK v5d\n\nTato verze je stále anglická. Oba původní TLK exporty byly beze změny zkopírovány na konec balíčku a v exportní tabulce byly změněny pouze jejich offsety. SeekFreeSaver a SeekFreeShaderCache zůstaly na původních adresách a jsou bitově shodné.\n\nInstalace:\n1. Nahraď Hdd1:/Games/Mass Effect 1/Layer0/MEInit/GlobalTlk.xxx tímto souborem.\n2. DLC nech originální a vypni dřívější experimentální české balíčky.\n3. Proveď úplný restart konzole.\n\nOčekávání: hra normálně naběhne a zůstane anglicky.\n\nSHA-256: {sha256(out)}\n''',encoding='utf-8')
    with zipfile.ZipFile(OUTZIP,'w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(OUTDIR.iterdir()): z.write(p,p.name)
    print(json.dumps(report,ensure_ascii=False,indent=2))
    print('OUTPUT',OUT); print('ZIP',OUTZIP)

if __name__=='__main__': main()
