#!/usr/bin/env python3
from pathlib import Path
import importlib.util, sys, struct, hashlib, json, shutil, zipfile

ROOT = Path('/mnt/data')
SRC = ROOT / 'GlobalTlk.xxx'
OUTDIR = ROOT / 'ME1_X360_TLK_Diacritic_InPlace_v5b'
OUT = OUTDIR / 'GlobalTlk.xxx'
OUTZIP = ROOT / 'ME1_X360_TLK_Diacritic_InPlace_v5b.zip'
TARGET_INDEX = 214
NEW_TEXT = 'Čeština'
REMAP = {'C': 'Č', 'S': 'š'}

spec = importlib.util.spec_from_file_location('lzoctl', ROOT / 'build_me1_xenon_lzo_control.py')
lzoctl = importlib.util.module_from_spec(spec)
sys.modules['lzoctl'] = lzoctl
assert spec.loader is not None
spec.loader.exec_module(lzoctl)

spec2 = importlib.util.spec_from_file_location('basev4', ROOT / 'build_me1_x360_cz_base_v4.py')
basev4 = importlib.util.module_from_spec(spec2)
sys.modules['basev4'] = basev4
assert spec2.loader is not None
spec2.loader.exec_module(basev4)


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def parse_raw_tlk(blob: bytes):
    pos = 40
    entry_count = struct.unpack_from('>i', blob, pos)[0]
    pos += 4
    entries = []
    for _ in range(entry_count):
        entries.append(struct.unpack_from('>iii', blob, pos))
        pos += 12

    node_count = struct.unpack_from('>i', blob, pos)[0]
    pos += 4
    nodes = []
    for _ in range(node_count):
        leaf_flag_pos = pos
        leaf = blob[pos] != 0
        pos += 1
        if leaf:
            char_pos = pos
            cp = struct.unpack_from('>H', blob, pos)[0]
            pos += 2
            nodes.append({'kind': 'leaf', 'char': chr(cp), 'char_pos': char_pos, 'flag_pos': leaf_flag_pos})
        else:
            right, left = struct.unpack_from('>hh', blob, pos)
            pos += 4
            nodes.append({'kind': 'node', 'right': right, 'left': left, 'flag_pos': leaf_flag_pos})

    string_count = struct.unpack_from('>i', blob, pos)[0]
    pos += 4
    strings = []
    for _ in range(string_count):
        header_pos = pos
        string_length, encoded_length = struct.unpack_from('>ii', blob, pos)
        pos += 8
        payload_pos = pos
        payload = blob[pos:pos + encoded_length]
        pos += encoded_length
        strings.append({
            'header_pos': header_pos,
            'payload_pos': payload_pos,
            'string_length': string_length,
            'encoded_length': encoded_length,
            'payload': payload,
        })
    if pos != len(blob):
        raise ValueError(f'TLK parse ended at {pos}, file size {len(blob)}')
    return entries, nodes, strings


def make_codes(nodes):
    codes = {}
    def walk(idx: int, path: list[int]):
        node = nodes[idx]
        if node['kind'] == 'leaf':
            codes[node['char']] = path[:]
            return
        walk(node['left'], path + [0])
        walk(node['right'], path + [1])
    walk(0, [])
    return codes


def encode_text(text: str, codes: dict[str, list[int]], byte_length: int) -> tuple[bytes, int]:
    terminated = text + '\0'
    missing = sorted(set(terminated) - set(codes))
    if missing:
        raise ValueError(f'Characters not in remapped Huffman tree: {missing!r}')
    bits = []
    for ch in terminated:
        bits.extend(codes[ch])
    bits.append(0)  # safe look-ahead padding bit
    if len(bits) > byte_length * 8:
        raise ValueError(f'Encoded text needs {len(bits)} bits, slot has only {byte_length * 8}')
    out = bytearray(byte_length)
    for i, bit in enumerate(bits):
        if bit:
            out[i // 8] |= 1 << (i % 8)
    return bytes(out), len(bits)


def main():
    src_pkg = SRC.read_bytes()
    logical, source_records, source_blocks, _ = lzoctl.decompress_package(src_pkg)
    tables = basev4.parse_package_tables(logical, '>')
    names = tables['names']
    exports = tables['exports']
    if [names[e.name_index] for e in exports[:2]] != ['GlobalTlk_tlk', 'GlobalTlk_tlk_M']:
        raise ValueError('Unexpected TLK exports')

    patched = bytearray(logical)
    changes = []
    allowed = set()

    for gender, exp in enumerate(exports[:2]):
        blob = bytearray(logical[exp.data_offset:exp.data_offset + exp.data_size])
        entries, nodes, strings = parse_raw_tlk(blob)
        slot = strings[TARGET_INDEX]

        _prefix, decoded_entries, _stats = basev4.parse_tlk_export(bytes(blob), '>')
        old_texts = sorted({e.text for e in decoded_entries if e.flags == 1 and e.index == TARGET_INDEX})
        if old_texts != ['Options']:
            raise ValueError(f'Index {TARGET_INDEX} is not Options: {old_texts}')

        leaf_positions = {}
        for node in nodes:
            if node['kind'] == 'leaf':
                leaf_positions[node['char']] = node['char_pos']
        for old, new in REMAP.items():
            if old not in leaf_positions:
                raise ValueError(f'Donor leaf {old!r} not found')
            pos = leaf_positions[old]
            struct.pack_into('>H', blob, pos, ord(new))
            allowed.update(range(exp.data_offset + pos, exp.data_offset + pos + 2))

        # Reparse the changed tree before encoding.
        _entries2, remapped_nodes, _strings2 = parse_raw_tlk(bytes(blob))
        codes = make_codes(remapped_nodes)
        payload, bit_count = encode_text(NEW_TEXT, codes, slot['encoded_length'])
        blob[slot['payload_pos']:slot['payload_pos'] + slot['encoded_length']] = payload
        struct.pack_into('>i', blob, slot['header_pos'], len(NEW_TEXT) + 1)
        allowed.update(range(exp.data_offset + slot['payload_pos'], exp.data_offset + slot['payload_pos'] + slot['encoded_length']))
        allowed.update(range(exp.data_offset + slot['header_pos'], exp.data_offset + slot['header_pos'] + 4))

        _p, check_entries, _s = basev4.parse_tlk_export(bytes(blob), '>')
        check_texts = sorted({e.text for e in check_entries if e.flags == 1 and e.index == TARGET_INDEX})
        if check_texts != [NEW_TEXT]:
            raise RuntimeError(f'Patched TLK did not decode as expected: {check_texts}')

        patched[exp.data_offset:exp.data_offset + exp.data_size] = blob
        changes.append({
            'gender_export': gender,
            'export_name': names[exp.name_index],
            'string_index': TARGET_INDEX,
            'old_text': old_texts[0],
            'new_text': NEW_TEXT,
            'donor_leaf_remap': REMAP,
            'slot_bytes': slot['encoded_length'],
            'encoded_bits_including_padding': bit_count,
            'export_size_unchanged': len(blob) == exp.data_size,
            'export_offset_unchanged': exp.data_offset,
        })

    package_source_pos = 125 + 16 * len(source_records)
    package_source = src_pkg[package_source_pos:package_source_pos + 4]
    output_pkg, built_chunks = lzoctl.build_control(src_pkg, bytes(patched), source_records, package_source)
    rebuilt_logical, rebuilt_records, rebuilt_blocks, _ = lzoctl.decompress_package(output_pkg)
    if rebuilt_logical != bytes(patched):
        raise RuntimeError('Physical LZO round-trip mismatch')
    if len(rebuilt_logical) != len(logical):
        raise RuntimeError('Logical size changed')

    diffs = [i for i, (a, b) in enumerate(zip(logical, rebuilt_logical)) if a != b]
    unexpected = [x for x in diffs if x not in allowed]
    if unexpected:
        raise RuntimeError(f'Unexpected logical changes at {unexpected[:20]}')

    OUTDIR.mkdir(parents=True, exist_ok=True)
    OUT.write_bytes(output_pkg)
    shutil.copy2(SRC, OUTDIR / 'GlobalTlk_original_backup.xxx')
    shutil.copy2(Path(__file__), OUTDIR / Path(__file__).name)

    report = {
        'build': 'ME1 Xbox 360 TLK Czech-diacritic in-place smoke test v5b',
        'purpose': 'Prove that Czech-specific Unicode leaf codepoints are accepted without rebuilding or resizing the TLK.',
        'expected_runtime': 'Game boots normally and Options appears as Čeština.',
        'source_sha256': sha256(src_pkg),
        'output_sha256': sha256(output_pkg),
        'source_size': len(src_pkg),
        'output_size': len(output_pkg),
        'logical_size_unchanged': len(rebuilt_logical) == len(logical),
        'package_table_unchanged': True,
        'export_sizes_offsets_unchanged': True,
        'huffman_tree_structure_unchanged': True,
        'huffman_leaf_codepoints_changed': REMAP,
        'changes': changes,
        'logical_changed_byte_count': len(diffs),
        'chunk_records': rebuilt_records,
        'blocks': rebuilt_blocks,
        'validation': [
            'both patched strings decode locally as Čeština',
            'Czech-specific codepoints Č and š are present in the Xbox big-endian Huffman tree',
            'all export sizes and offsets remain unchanged',
            'helper exports remain byte-for-byte unchanged',
            'full LZO package round-trip passed',
            'only two leaf codepoints and the two fixed-size Options slots changed logically',
        ],
        'runtime_status': 'PENDING XBOX 360 TEST',
        'diagnostic_side_effect': 'The original C and S Huffman leaves are remapped to Č and š in this diagnostic build. Other texts containing C or S will look wrong; do not use it for normal play.',
    }
    (OUTDIR / 'validation.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    (OUTDIR / 'README_CS.txt').write_text(
        'Mass Effect 1 Xbox 360 – test české diakritiky v5b\n\n'
        'Tato verze NENÍ plná čeština. Mění pouze položku Options na Čeština.\n'
        'Nemění strukturu Huffmanova stromu, velikost ani offset exportů a neposouvá pomocné objekty.\n'
        'Původní znaky C a S jsou pouze pro tento test přemapovány na Č a š, takže jiné texty s C/S budou dočasně vypadat chybně.\n\n'
        'Test:\n'
        '1. Nahraď pouze Hdd1:/Games/Mass Effect 1/Layer0/MEInit/GlobalTlk.xxx.\n'
        '2. Oficiální DLC ponech originální a odstraň starší experimentální česká DLC.\n'
        '3. Proveď úplný restart konzole.\n\n'
        'Očekávání: hra normálně naběhne a místo Options uvidíš Čeština.\n'
        'Pokud se znaky zobrazí správně, diakritika ani Unicode kódové body nejsou příčinou pádu v4.\n',
        encoding='utf-8'
    )
    with zipfile.ZipFile(OUTZIP, 'w', zipfile.ZIP_DEFLATED) as z:
        for p in sorted(OUTDIR.iterdir()):
            z.write(p, p.name)
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
