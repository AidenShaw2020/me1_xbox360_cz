#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import math
import shutil
import struct
import zipfile
from pathlib import Path

SECTOR = 0x1000
DATA_PER_L0 = 0xAA
DATA_PER_L1 = 0x70E4
HEADER_CONTENT_ID = 0x32C
HEADER_SIZE_OFF = 0x340
METADATA = 0x344
CONTENT_SIZE = 0x34C
MEDIA_ID_OFF = 0x354
VERSION_OFF = 0x358
BASE_VERSION_OFF = 0x35C
TITLE_ID_OFF = 0x360
DISPLAY_NAMES = 0x411
DESCRIPTIONS = 0xD11
VOL_OFF = 0x379
TUPD_MAGIC = b'TUPD'

EXPECTED_TITLE_ID = 0x4D5307E8
EXPECTED_MEDIA_ID = 0x572BA75D
EXPECTED_BASE_VERSION = 5
NEW_VERSION = 8

ROOT = Path('/mnt/data')
TEMPLATE = ROOT / 'smoketest_unzip/ME1_X360_CZ_TU/ME1_CZ_TU_v1'
CZ_TLK = ROOT / 'ME1_X360_CZ_Relocated_v6/GlobalTlk.xxx'
OUT_DIR = ROOT / 'ME1_X360_CZ_TU_v8'
ZIP_OUT = ROOT / 'ME1_X360_CZ_TU_v8.zip'


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def u24le(b: bytes) -> int:
    return b[0] | (b[1] << 8) | (b[2] << 16)


def p24le(v: int) -> bytes:
    return bytes((v & 0xFF, (v >> 8) & 0xFF, (v >> 16) & 0xFF))


def p24be(v: int) -> bytes:
    return bytes(((v >> 16) & 0xFF, (v >> 8) & 0xFF, v & 0xFF))


class Layout:
    def __init__(self, total_blocks: int, rounded_header: int):
        self.total_blocks = total_blocks
        self.rounded_header = rounded_header

    def backing_offset(self, backing: int) -> int:
        return self.rounded_header + backing * SECTOR

    def data_backing(self, block_num: int) -> int:
        block = block_num
        base = DATA_PER_L0
        for _ in range(3):
            block += (block_num + base) // base
            if block_num < base:
                break
            base *= DATA_PER_L0
        return block

    def data_offset(self, block_num: int) -> int:
        return self.backing_offset(self.data_backing(block_num))

    def l0_backing(self, group: int) -> int:
        block_num = group * DATA_PER_L0
        num = (block_num // DATA_PER_L0) * 0xAB
        if block_num // DATA_PER_L0 == 0:
            return num
        num += (block_num // DATA_PER_L1) + 1
        if block_num // DATA_PER_L1 == 0:
            return num
        return num + 1

    def l0_offset(self, group: int) -> int:
        return self.backing_offset(self.l0_backing(group))

    def l1_offset(self) -> int:
        return self.backing_offset(0xAB)

    def backing_count(self) -> int:
        return self.data_backing(self.total_blocks - 1) + 1


def utf16be_field(text: str, size: int) -> bytes:
    raw = (text + '\0').encode('utf-16-be')
    if len(raw) > size:
        raise ValueError(text)
    return raw.ljust(size, b'\0')


def patch_directory(template: bytes, old_layout: Layout, new_layout: Layout, payload: bytes, file_blocks: int) -> bytes:
    old_vd = template[VOL_OFF:VOL_OFF + 0x24]
    old_dir_first = u24le(old_vd[5:8])
    old_dir = bytearray(template[old_layout.data_offset(old_dir_first):old_layout.data_offset(old_dir_first) + SECTOR])

    # Expected entries: Layer0/, Layer0/MEInit/, Layer0/MEInit/GlobalTlk.xxx
    found = False
    for idx in range(SECTOR // 0x40):
        off = idx * 0x40
        ent = old_dir[off:off + 0x40]
        nlen = ent[40] & 0x3F
        if not nlen:
            break
        name = ent[:nlen].decode('ascii')
        if name == 'GlobalTlk.xxx' and not (ent[40] & 0x80):
            old_dir[off + 41:off + 44] = p24le(file_blocks)
            old_dir[off + 44:off + 47] = p24le(file_blocks)
            old_dir[off + 47:off + 50] = p24le(1)
            old_dir[off + 52:off + 56] = struct.pack('>I', len(payload))
            found = True
            break
    if not found:
        raise RuntimeError('GlobalTlk.xxx entry not found in TU template')
    return bytes(old_dir)


def build() -> tuple[Path, dict]:
    template = TEMPLATE.read_bytes()
    payload = CZ_TLK.read_bytes()
    if template[:4] not in (b'LIVE', b'PIRS', b'CON '):
        raise ValueError('TU template is not STFS')
    if int.from_bytes(template[METADATA:METADATA+4], 'big') != 0x000B0000:
        raise ValueError('Template is not Title Update content type')
    if int.from_bytes(template[MEDIA_ID_OFF:MEDIA_ID_OFF+4], 'big') != EXPECTED_MEDIA_ID:
        raise ValueError('Wrong template Media ID')
    if int.from_bytes(template[TITLE_ID_OFF:TITLE_ID_OFF+4], 'big') != EXPECTED_TITLE_ID:
        raise ValueError('Wrong template Title ID')
    if int.from_bytes(template[BASE_VERSION_OFF:BASE_VERSION_OFF+4], 'big') != EXPECTED_BASE_VERSION:
        raise ValueError('Wrong template base version')

    header_size = int.from_bytes(template[HEADER_SIZE_OFF:HEADER_SIZE_OFF+4], 'big')
    rounded_header = math.ceil(header_size / SECTOR) * SECTOR
    old_total = int.from_bytes(template[VOL_OFF + 28:VOL_OFF + 32], 'big')
    old_layout = Layout(old_total, rounded_header)

    file_blocks = math.ceil(len(payload) / SECTOR)
    total_blocks = 1 + file_blocks  # directory + GlobalTlk payload
    layout = Layout(total_blocks, rounded_header)
    backing_count = layout.backing_count()
    content_size = backing_count * SECTOR
    final_size = rounded_header + content_size

    work = bytearray(final_size)
    work[:rounded_header] = template[:rounded_header]

    # Version metadata: update target version, retain base version 5.
    work[VERSION_OFF:VERSION_OFF+4] = struct.pack('>I', NEW_VERSION)
    work[BASE_VERSION_OFF:BASE_VERSION_OFF+4] = struct.pack('>I', EXPECTED_BASE_VERSION)

    tupd_off = work.find(TUPD_MAGIC, METADATA, rounded_header)
    if tupd_off < 0:
        raise RuntimeError('TUPD installer metadata not found')
    work[tupd_off + 4:tupd_off + 8] = struct.pack('>I', EXPECTED_BASE_VERSION)
    work[tupd_off + 8:tupd_off + 12] = struct.pack('>I', NEW_VERSION)

    # Update display metadata only; package identity remains ME1/Media ID specific.
    title = 'Mass Effect Czech Title Update v8'
    description = 'Czech localization overlay for Mass Effect 1 Xbox 360.'
    for i in range(9):
        work[DISPLAY_NAMES + i * 0x100:DISPLAY_NAMES + (i + 1) * 0x100] = utf16be_field(title, 0x100)
        work[DESCRIPTIONS + i * 0x100:DESCRIPTIONS + (i + 1) * 0x100] = utf16be_field(description, 0x100)

    # Metadata / volume descriptor.
    work[CONTENT_SIZE:CONTENT_SIZE+8] = struct.pack('>Q', content_size)
    work[VOL_OFF + 3:VOL_OFF + 5] = struct.pack('<H', 1)
    work[VOL_OFF + 5:VOL_OFF + 8] = p24le(0)  # directory logical block
    work[VOL_OFF + 28:VOL_OFF + 32] = struct.pack('>I', total_blocks)
    work[VOL_OFF + 32:VOL_OFF + 36] = struct.pack('>I', 0)

    directory = patch_directory(template, old_layout, layout, payload, file_blocks)
    work[layout.data_offset(0):layout.data_offset(0)+SECTOR] = directory

    for i in range(file_blocks):
        chunk = payload[i*SECTOR:(i+1)*SECTOR].ljust(SECTOR, b'\0')
        work[layout.data_offset(1+i):layout.data_offset(1+i)+SECTOR] = chunk

    # File chains: directory terminates; payload blocks form one contiguous chain.
    chains: dict[int, int] = {0: 0xFFFFFF}
    for i in range(file_blocks):
        logical = 1 + i
        chains[logical] = logical + 1 if i + 1 < file_blocks else 0xFFFFFF

    l0_count = math.ceil(total_blocks / DATA_PER_L0)
    l1 = bytearray(SECTOR)
    for group in range(l0_count):
        table = bytearray(SECTOR)
        first = group * DATA_PER_L0
        last = min(first + DATA_PER_L0, total_blocks)
        for n in range(first, last):
            data_block = work[layout.data_offset(n):layout.data_offset(n)+SECTOR]
            rec = n - first
            off = rec * 0x18
            table[off:off+20] = hashlib.sha1(data_block).digest()
            table[off+20] = 0x80
            table[off+21:off+24] = p24be(chains[n])
        work[layout.l0_offset(group):layout.l0_offset(group)+SECTOR] = table
        l1[group*0x18:group*0x18+20] = hashlib.sha1(table).digest()
        l1[group*0x18+20] = 0x00
        l1[group*0x18+21:group*0x18+24] = b'\xFF\xFF\xFF'

    work[layout.l1_offset():layout.l1_offset()+SECTOR] = l1
    root_hash = hashlib.sha1(l1).digest()
    work[VOL_OFF + 8:VOL_OFF + 28] = root_hash

    content_id = hashlib.sha1(work[METADATA:rounded_header]).digest()
    work[HEADER_CONTENT_ID:HEADER_CONTENT_ID+20] = content_id

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    canonical_name = content_id.hex().upper()
    out = OUT_DIR / canonical_name
    out.write_bytes(work)

    # A friendly copy for inspection; canonical content-ID filename is the installable one.
    friendly = OUT_DIR / 'ME1_CZ_TU_v8'
    friendly.write_bytes(work)

    validation = verify(out, payload, NEW_VERSION)
    validation.update({
        'template': str(TEMPLATE),
        'template_sha256': sha256(template),
        'payload': str(CZ_TLK),
        'payload_sha256': sha256(payload),
        'output_sha256': sha256(work),
        'canonical_filename': canonical_name,
        'title_id': f'{EXPECTED_TITLE_ID:08X}',
        'media_id': f'{EXPECTED_MEDIA_ID:08X}',
        'base_version': EXPECTED_BASE_VERSION,
        'target_version': NEW_VERSION,
    })
    (OUT_DIR / 'validation.json').write_text(json.dumps(validation, indent=2, ensure_ascii=False), encoding='utf-8')

    readme = f'''Mass Effect 1 Xbox 360 – český Title Update v8 (experimentální)\n\nTento balíček je data-only Title Update pro:\nTitle ID: {EXPECTED_TITLE_ID:08X}\nMedia ID: {EXPECTED_MEDIA_ID:08X}\nBase version: {EXPECTED_BASE_VERSION}\nTarget version: {NEW_VERSION}\n\nObsahuje pouze:\nLayer0/MEInit/GlobalTlk.xxx\n\nDŮLEŽITÝ TESTOVACÍ POSTUP:\n1. Vrať do hry původní anglický GlobalTlk.xxx. Česká v6 nesmí zůstat přímo v adresáři hry, jinak nelze ověřit TU overlay.\n2. Vypni nebo odstraň všechny ostatní TU pro Mass Effect 1.\n3. Zkopíruj soubor {canonical_name} do:\n   Hdd1:/Content/0000000000000000/4D5307E8/000B0000/\n4. V Auroře proveď Scan / Refresh Title Updates a aktivuj TU verze 8.\n5. Proveď úplný restart konzole a spusť hru.\n\nOčekávání: hra naběhne česky, přestože v adresáři hry je původní anglický GlobalTlk.xxx.\n\nJde o experimentální nepodepsaný LIVE/STFS obsah určený pro RGH/JTAG. Musí být aktivní podpora nepodepsaného obsahu (typicky contpatch).\n\nSHA-256 TU: {sha256(work)}\nSHA-256 vložené české v6: {sha256(payload)}\n'''
    (OUT_DIR / 'README_CS.txt').write_text(readme, encoding='utf-8')

    if ZIP_OUT.exists():
        ZIP_OUT.unlink()
    with zipfile.ZipFile(ZIP_OUT, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in sorted(OUT_DIR.iterdir()):
            z.write(p, arcname=f'ME1_X360_CZ_TU_v8/{p.name}')

    return out, validation


def verify(path: Path, expected_payload: bytes, expected_version: int) -> dict:
    d = path.read_bytes()
    header_size = int.from_bytes(d[HEADER_SIZE_OFF:HEADER_SIZE_OFF+4], 'big')
    rounded = math.ceil(header_size / SECTOR) * SECTOR
    total = int.from_bytes(d[VOL_OFF+28:VOL_OFF+32], 'big')
    layout = Layout(total, rounded)
    expected_size = rounded + layout.backing_count() * SECTOR
    if len(d) != expected_size:
        raise RuntimeError(f'Physical size mismatch {len(d)} != {expected_size}')
    if int.from_bytes(d[METADATA:METADATA+4], 'big') != 0x000B0000:
        raise RuntimeError('Content type mismatch')
    if int.from_bytes(d[VERSION_OFF:VERSION_OFF+4], 'big') != expected_version:
        raise RuntimeError('Version mismatch')

    # Verify hash hierarchy.
    l1 = d[layout.l1_offset():layout.l1_offset()+SECTOR]
    if hashlib.sha1(l1).digest() != d[VOL_OFF+8:VOL_OFF+28]:
        raise RuntimeError('Root hash mismatch')
    for group in range(math.ceil(total / DATA_PER_L0)):
        l0 = d[layout.l0_offset(group):layout.l0_offset(group)+SECTOR]
        if hashlib.sha1(l0).digest() != l1[group*0x18:group*0x18+20]:
            raise RuntimeError(f'L0 parent mismatch group {group}')
        first = group * DATA_PER_L0
        for n in range(first, min(first + DATA_PER_L0, total)):
            block = d[layout.data_offset(n):layout.data_offset(n)+SECTOR]
            rec = n - first
            if hashlib.sha1(block).digest() != l0[rec*0x18:rec*0x18+20]:
                raise RuntimeError(f'Data hash mismatch block {n}')

    cid = hashlib.sha1(d[METADATA:rounded]).digest()
    if cid != d[HEADER_CONTENT_ID:HEADER_CONTENT_ID+20]:
        raise RuntimeError('Content ID mismatch')
    if path.name != cid.hex().upper():
        raise RuntimeError('Canonical filename mismatch')

    # Parse directory and extract payload.
    vd = d[VOL_OFF:VOL_OFF+0x24]
    directory = d[layout.data_offset(u24le(vd[5:8])):layout.data_offset(u24le(vd[5:8]))+SECTOR]
    paths = {0xFFFF: ''}
    extracted = None
    entry_info = None
    for idx in range(SECTOR // 0x40):
        e = directory[idx*0x40:(idx+1)*0x40]
        nlen = e[40] & 0x3F
        if not nlen:
            break
        name = e[:nlen].decode('ascii')
        is_dir = bool(e[40] & 0x80)
        parent = int.from_bytes(e[50:52], 'big')
        full = paths.get(parent, '') + name + ('/' if is_dir else '')
        if is_dir:
            paths[idx] = full
            continue
        if full == 'Layer0/MEInit/GlobalTlk.xxx':
            size = int.from_bytes(e[52:56], 'big')
            start = u24le(e[47:50])
            blocks = u24le(e[44:47])
            buf = bytearray()
            for n in range(start, start + blocks):
                buf += d[layout.data_offset(n):layout.data_offset(n)+SECTOR]
            extracted = bytes(buf[:size])
            entry_info = {'path': full, 'size': size, 'start_block': start, 'blocks': blocks}
    if extracted is None:
        raise RuntimeError('GlobalTlk payload not found')
    if extracted != expected_payload:
        raise RuntimeError('Extracted GlobalTlk does not match Czech v6')

    return {
        'status': 'PASS',
        'file_size': len(d),
        'content_size': int.from_bytes(d[CONTENT_SIZE:CONTENT_SIZE+8], 'big'),
        'total_logical_blocks': total,
        'backing_blocks': layout.backing_count(),
        'l0_tables': math.ceil(total / DATA_PER_L0),
        'l1_root_sha1': d[VOL_OFF+8:VOL_OFF+28].hex(),
        'content_id': cid.hex().upper(),
        'entry': entry_info,
        'payload_exact_match': True,
        'hash_tree': 'PASS',
    }


if __name__ == '__main__':
    out, validation = build()
    print(out)
    print(json.dumps(validation, indent=2, ensure_ascii=False))
    print(ZIP_OUT)
