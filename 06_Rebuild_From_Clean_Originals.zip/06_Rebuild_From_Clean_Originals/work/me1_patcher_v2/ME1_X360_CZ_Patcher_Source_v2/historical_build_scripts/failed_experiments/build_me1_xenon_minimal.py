#!/usr/bin/env python3
from pathlib import Path
import struct, hashlib, json, math, shutil, zipfile
from importlib.machinery import SourceFileLoader

SRC=Path('/mnt/data/GlobalTlk_CS.upk')
ORIG=Path('/mnt/data/GlobalTlk.xxx')
OUTDIR=Path('/mnt/data/ME1_X360_CZ_Smoke_v2')
OUT=OUTDIR/'GlobalTlk.xxx'

def fstr_read(b,o,e):
    n=struct.unpack_from(e+'i',b,o)[0];o+=4
    if n>0:
        raw=b[o:o+n];o+=n; return raw[:-1].decode('latin1'),o
    if n<0:
        nn=-n;raw=b[o:o+nn*2];o+=nn*2;return raw[:-2].decode('utf-16le' if e=='<' else 'utf-16be'),o
    return '',o

def fstr_write(s,e='>'):
    raw=s.encode('latin1')+b'\0'
    return struct.pack(e+'i',len(raw))+raw

def parse_source():
    b=SRC.read_bytes();e='<'
    # known hybrid Xenon layout
    full=struct.unpack_from('<i',b,8)[0]
    o=12;folder,o=fstr_read(b,o,e)
    flags=struct.unpack_from('<I',b,o)[0];o+=4
    nc,no,ec,eo,ic,io=struct.unpack_from('<iiiiii',b,o);o+=24
    # no dependency offset
    guid=b[o:o+16];o+=16
    gen_count=struct.unpack_from('<I',b,o)[0];o+=4
    gens=b[o:o+gen_count*12];o+=gen_count*12
    tail_to_comp=b[o:117] # engine/build fields
    ctype,nchunks=struct.unpack_from('<ii',b,117)
    pkg_source=struct.unpack_from('<I',b,125)[0]
    # names, retain flags
    names=[];name_flags=[];p=no
    for _ in range(nc):
        s,p=fstr_read(b,p,'<');names.append(s);name_flags.append(b[p:p+8]);p+=8
    # imports raw values
    imports=[];p=io
    for _ in range(ic):
        imports.append(struct.unpack_from('<iiiiiii',b,p));p+=28
    exports=[];p=eo
    for _ in range(ec):
        st=p
        vals=struct.unpack_from('<iiiiiiQii',b,p);p+=40
        cmn=struct.unpack_from('<i',b,p)[0];p+=4
        cmap=b[p:p+cmn*12];p+=cmn*12
        exflags=struct.unpack_from('<I',b,p)[0];p+=4
        genn=struct.unpack_from('<i',b,p)[0];p+=4
        gen=b[p:p+genn*4];p+=genn*4
        eguid=b[p:p+16];p+=16
        exports.append(dict(vals=vals,cmn=cmn,cmap=cmap,exflags=exflags,genn=genn,gen=gen,guid=eguid,header_start=st,header_end=p))
    for x in exports:
        *_,size,offset=x['vals']
        x['data']=b[offset:offset+size]
    return locals()

def convert_tlk_export(data:bytes, gender:int, target_name_indices:dict):
    # source property binary starts at 40; source entry count at 40
    # parse little-endian TLK binary and serialize big-endian. Encoded bit bytes stay unchanged.
    o=40
    entry_count=struct.unpack_from('<i',data,o)[0];o+=4
    entries=[]
    for _ in range(entry_count):
        entries.append(struct.unpack_from('<iii',data,o));o+=12
    node_count=struct.unpack_from('<i',data,o)[0];o+=4
    nodes=[]
    for _ in range(node_count):
        leaf=data[o];o+=1
        if leaf:
            ch=struct.unpack_from('<H',data,o)[0];o+=2
            nodes.append((1,ch))
        else:
            right,left=struct.unpack_from('<hh',data,o);o+=4
            nodes.append((0,right,left))
    string_count=struct.unpack_from('<i',data,o)[0];o+=4
    strings=[]
    for _ in range(string_count):
        sl,el=struct.unpack_from('<ii',data,o);o+=8
        payload=data[o:o+el];o+=el
        strings.append((sl,el,payload))
    if o != len(data):
        raise ValueError(f'TLK parse did not consume data: {o} != {len(data)}')
    # properties: NetIndex, m_nHashTableSize IntProperty, None
    out=bytearray()
    out += struct.pack('>i',gender)
    out += struct.pack('>ii',target_name_indices['m_nHashTableSize'],0)
    out += struct.pack('>ii',target_name_indices['IntProperty'],0)
    out += struct.pack('>ii',4,0)
    out += struct.pack('>i',entry_count)
    out += struct.pack('>ii',target_name_indices['None'],0)
    assert len(out)==40
    out += struct.pack('>i',entry_count)
    for sid,fl,idx in entries: out += struct.pack('>iii',sid,fl,idx)
    out += struct.pack('>i',node_count)
    for n in nodes:
        out.append(n[0])
        if n[0]: out += struct.pack('>H',n[1])
        else: out += struct.pack('>hh',n[1],n[2])
    out += struct.pack('>i',string_count)
    for sl,el,payload in strings:
        out += struct.pack('>ii',sl,el); out += payload
    return bytes(out),dict(entry_count=entry_count,node_count=node_count,string_count=string_count)

def lzx_uncompressed(data:bytes)->bytes:
    n=len(data)
    if n>0xFFFFFF: raise ValueError(n)
    bits=[]
    def put(v,k): bits.extend((v>>(k-1-i))&1 for i in range(k))
    put(0,1) # no intel E8 translation
    put(3,3) # uncompressed block
    put(n>>8,16); put(n&0xff,8)
    while len(bits)%16: bits.append(0)
    out=bytearray()
    for i in range(0,len(bits),16):
        v=0
        for bit in bits[i:i+16]: v=(v<<1)|bit
        out += struct.pack('<H',v)
    out += struct.pack('<III',1,1,1)
    out += data
    # Xbox/Gildor decoder intentionally does not consume odd padding.
    return bytes(out)

def xbox_lzx_wrap(raw:bytes)->bytes:
    # UEViewer Xbox wrapper: 2-byte BE compressed segment length, followed by bytes.
    # Keep first byte != 0xFF so it cannot be mistaken for the extended 5-byte header.
    out=bytearray();pos=0;maxseg=0x7F00
    while pos<len(raw):
        seg=raw[pos:pos+maxseg];pos+=len(seg)
        out += struct.pack('>H',len(seg));out += seg
    return bytes(out)

def xbox_lzx_unwrap(wrapped:bytes)->bytes:
    out=bytearray();p=0
    while p<len(wrapped):
        if wrapped[p]==0xFF:
            if p+5>len(wrapped): raise ValueError('short ext wrapper')
            cs=int.from_bytes(wrapped[p+3:p+5],'big');p+=5
        else:
            if p+2>len(wrapped): raise ValueError('short wrapper')
            cs=int.from_bytes(wrapped[p:p+2],'big');p+=2
        out+=wrapped[p:p+cs];p+=cs
    return bytes(out)

def make_ue_chunk(data:bytes):
    blocks=[]
    for pos in range(0,len(data),0x20000):
        plain=data[pos:pos+0x20000]
        raw=lzx_uncompressed(plain)
        wrapped=xbox_lzx_wrap(raw)
        blocks.append((plain,wrapped))
    table=bytearray()
    for plain,comp in blocks: table += struct.pack('>II',len(comp),len(plain))
    payload=b''.join(comp for _,comp in blocks)
    hdr=struct.pack('>IIII',0x9E2A83C1,0x9E2A83C1,len(payload),len(data))
    chunk=hdr+table+payload
    return chunk,blocks

def build(package_flags:int):
    s=parse_source(); b=s['b']; names=s['names']; nflags=s['name_flags']; imports=s['imports']; exps=s['exports']
    names=[('GlobalTlk' if x=='GlobalTlk_CS' else x) for x in names]
    idx={n:i for i,n in enumerate(names)}
    d0,st0=convert_tlk_export(exps[0]['data'],0,idx)
    d1,st1=convert_tlk_export(exps[1]['data'],1,idx)
    # logical tables start at 129
    name_blob=bytearray()
    for n,fl in zip(names,nflags):
        name_blob += fstr_write(n,'>')
        # preserve 64-bit name flags numerically, not raw byte order
        name_blob += struct.pack('>Q',struct.unpack('<Q',fl)[0])
    name_offset=129
    import_offset=name_offset+len(name_blob)
    import_blob=bytearray()
    for vals in imports: import_blob += struct.pack('>iiiiiii',*vals)
    export_offset=import_offset+len(import_blob)
    # two export headers, 68 bytes each
    full_header_size=export_offset+68*2
    data0_off=full_header_size
    data1_off=data0_off+len(d0)
    export_blob=bytearray()
    for x,data,off in [(exps[0],d0,data0_off),(exps[1],d1,data1_off)]:
        cls,sup,link,oname,inum,arch,oflags,oldsize,oldoff=x['vals']
        export_blob += struct.pack('>iiiiiiQii',cls,sup,link,oname,inum,arch,oflags,len(data),off)
        export_blob += struct.pack('>i',0) # component map count
        export_blob += struct.pack('>I',x['exflags'])
        export_blob += struct.pack('>i',0) # generation net object count
        export_blob += x['guid']
        assert len(export_blob)%68==0
    logical=bytearray(b'\0'*name_offset)
    logical += name_blob+import_blob+export_blob+d0+d1
    # build max 1MB UE chunks from logical name offset onward
    chunk_plain=[]
    for p in range(name_offset,len(logical),0x100000): chunk_plain.append(bytes(logical[p:p+0x100000]))
    chunks=[]
    # physical header size depends on chunk count: 125 + records + packageSource
    phys_data_off=125+16*len(chunk_plain)+4
    cur=phys_data_off
    for i,plain in enumerate(chunk_plain):
        c,blocks=make_ue_chunk(plain)
        chunks.append(dict(uncompressed_offset=name_offset+i*0x100000,uncompressed_size=len(plain),compressed_offset=cur,compressed_size=len(c),data=c,blocks=blocks))
        cur += len(c)
    # physical header
    hdr=bytearray()
    hdr += bytes.fromhex('9e2a83c1')
    hdr += struct.pack('>I',(92<<16)|391)
    hdr += struct.pack('>i',full_header_size)
    hdr += fstr_write('None','>')
    assert len(hdr)==21
    hdr += struct.pack('>I',package_flags)
    hdr += struct.pack('>iiiiii',len(names),name_offset,2,export_offset,len(imports),import_offset)
    # source GUID bytes need UE GUID component endian conversion? copy source bytes for now; loader treats opaque.
    hdr += s['guid']
    hdr += struct.pack('>I',s['gen_count'])
    # convert generation tuples
    for i in range(s['gen_count']):
        vals=struct.unpack_from('<iii',s['gens'],i*12);hdr += struct.pack('>iii',*vals)
    # convert 9 int fields from offsets 81..116
    for off in range(81,117,4): hdr += struct.pack('>i',struct.unpack_from('<i',b,off)[0])
    assert len(hdr)==117
    hdr += struct.pack('>ii',2,len(chunks))
    for c in chunks: hdr += struct.pack('>iiii',c['uncompressed_offset'],c['uncompressed_size'],c['compressed_offset'],c['compressed_size'])
    hdr += struct.pack('>I',s['pkg_source'])
    assert len(hdr)==phys_data_off
    out=hdr+b''.join(c['data'] for c in chunks)
    return out,logical,chunks,dict(source=st0,source_m=st1,names=names,full_header_size=full_header_size,export_offsets=[data0_off,data1_off],package_flags=package_flags)

def validate(out:bytes,logical:bytes,chunks):
    decmod=SourceFileLoader('lzxd','/mnt/data/lzx_decoder.py').load_module()
    rebuilt=bytearray(b'\0'*129)
    for c in chunks:
        ch=out[c['compressed_offset']:c['compressed_offset']+c['compressed_size']]
        magic1,magic2,cs,us=struct.unpack_from('>IIII',ch,0)
        n=(us+0x1ffff)//0x20000; p=16+8*n; plain=bytearray()
        for j in range(n):
            bcs,bus=struct.unpack_from('>II',ch,16+j*8)
            wrapped=ch[p:p+bcs];p+=bcs
            raw=xbox_lzx_unwrap(wrapped)
            got=decmod.decompress_lzx(raw,bus,window_bits=17)
            expect=c['blocks'][j][0]
            if got!=expect: raise AssertionError(('block mismatch',j,len(got),len(expect)))
            plain+=got
        if bytes(plain)!=logical[c['uncompressed_offset']:c['uncompressed_offset']+c['uncompressed_size']]: raise AssertionError('chunk mismatch')
        rebuilt+=plain
    if bytes(rebuilt)!=bytes(logical):
        raise AssertionError((len(rebuilt),len(logical),'logical mismatch'))
    return True

def main():
    OUTDIR.mkdir(exist_ok=True)
    out,logical,chunks,meta=build(0x22080009)
    validate(out,logical,chunks)
    OUT.write_bytes(out)
    # also source-flags fallback
    out2,logical2,chunks2,meta2=build(0x1)
    validate(out2,logical2,chunks2)
    (OUTDIR/'GlobalTlk_sourceflags.xxx').write_bytes(out2)
    report={
      'build':'minimal Xenon package from GlobalTlk_CS.upk',
      'primary':{'file':'GlobalTlk.xxx','size':len(out),'sha256':hashlib.sha256(out).hexdigest(),'flags':'0x22080009'},
      'fallback':{'file':'GlobalTlk_sourceflags.xxx','size':len(out2),'sha256':hashlib.sha256(out2).hexdigest(),'flags':'0x00000001'},
      'source_upk_sha256':hashlib.sha256(SRC.read_bytes()).hexdigest(),
      'original_xbox_sha256':hashlib.sha256(ORIG.read_bytes()).hexdigest(),
      'tlk_stats':meta['source'],
      'logical_size':len(logical),
      'chunks':[{k:c[k] for k in ('uncompressed_offset','uncompressed_size','compressed_offset','compressed_size')} for c in chunks],
      'validation':['all generated LZX blocks decoded byte-for-byte','all UE chunks reconstructed byte-for-byte','package tables/offsets internally consistent'],
      'runtime_test':'pending'
    }
    (OUTDIR/'validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    readme=f'''Mass Effect 1 Xbox 360 – base-game Czech smoke test v2\n\nIMPORTANT: Test only the base game first. Keep official DLC files original.\n\n1. Back up Hdd1:/Games/Mass Effect 1/Layer0/MEInit/GlobalTlk.xxx\n2. Copy GlobalTlk.xxx to that path.\n3. Remove/disable all previous experimental Czech DLC and modified official DLC.\n4. Cold restart the console and launch the game.\n\nRollback: restore the original GlobalTlk.xxx (SHA-256 {hashlib.sha256(ORIG.read_bytes()).hexdigest()}).\n\nThis build is not the previous broken package. It uses valid Xbox/Gildor LZX framing with uncompressed LZX blocks and was fully decoded after construction. It currently uses the Czech PC GlobalTlk source directly (16,376 entries); Xbox-only string merging and official DLC patching will follow after this boot smoke test succeeds.\n\nFallback: GlobalTlk_sourceflags.xxx is the same data with source package flags. Do not test it unless the primary build still black-screens.\n'''
    (OUTDIR/'README.txt').write_text(readme,encoding='utf-8')
    shutil.copy2(ORIG,OUTDIR/'GlobalTlk_original_backup.xxx')
    z=Path('/mnt/data/ME1_X360_CZ_Base_Smoke_v2.zip')
    with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as q:
        for p in OUTDIR.iterdir():q.write(p,p.name)
    print(json.dumps(report,indent=2));print('ZIP',z,z.stat().st_size)
if __name__=='__main__':main()
