#!/usr/bin/env python3
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from collections import Counter
import ctypes
import hashlib
import heapq
import importlib.util
import json
import shutil
import struct
import zipfile

ROOT = Path('/mnt/data')
ORIGINAL_XBOX = ROOT / 'GlobalTlk.xxx'
SOURCE_CZ_UPK = ROOT / 'GlobalTlk_CS.upk'
XBOX_ONLY_JSON = ROOT / 'me1_smoke_inspect/ME1_X360_CZ/base_xbox_only_translation_cs.json'
OUTDIR = ROOT / 'ME1_X360_CZ_Base_v4'
OUTFILE = OUTDIR / 'GlobalTlk.xxx'
OUTZIP = ROOT / 'ME1_X360_CZ_Base_v4.zip'

MAGIC = 0x9E2A83C1
BLOCK_SIZE = 0x20000

# Reuse the now runtime-proven Xbox UE3/LZO reader/writer.
spec = importlib.util.spec_from_file_location('lzoctl', ROOT / 'build_me1_xenon_lzo_control.py')
lzoctl = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(lzoctl)


@dataclass
class ExportHeader:
    index: int
    start: int
    end: int
    values: tuple[int, int, int, int, int, int, int, int, int]
    component_count: int
    export_flags: int
    generation_count: int
    guid: bytes

    @property
    def name_index(self) -> int:
        return self.values[3]

    @property
    def data_size(self) -> int:
        return self.values[7]

    @property
    def data_offset(self) -> int:
        return self.values[8]


@dataclass
class TlkEntry:
    string_id: int
    flags: int
    index: int
    text: str | None = None


@dataclass
class HuffNode:
    char: str | None
    freq: int
    left: 'HuffNode | None' = None
    right: 'HuffNode | None' = None
    node_id: int = -1

    @property
    def leaf(self) -> bool:
        return self.char is not None


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def read_fstring(data: bytes, offset: int, endian: str) -> tuple[str, int]:
    n = struct.unpack_from(endian + 'i', data, offset)[0]
    offset += 4
    if n > 0:
        raw = data[offset:offset + n]
        return raw[:-1].decode('latin1'), offset + n
    if n < 0:
        count = -n
        raw = data[offset:offset + count * 2]
        enc = 'utf-16le' if endian == '<' else 'utf-16be'
        return raw[:-2].decode(enc), offset + count * 2
    return '', offset


def parse_package_tables(logical: bytes, endian: str = '>'):
    full_header_size = struct.unpack_from(endian + 'i', logical, 8)[0]
    name_count, name_offset, export_count, export_offset, import_count, import_offset = struct.unpack_from(
        endian + 'iiiiii', logical, 25
    )

    names: list[str] = []
    pos = name_offset
    for _ in range(name_count):
        name, pos = read_fstring(logical, pos, endian)
        names.append(name)
        pos += 8  # 64-bit name flags
    if pos != import_offset:
        raise ValueError(f'name table ended at {pos}, expected import offset {import_offset}')

    exports: list[ExportHeader] = []
    pos = export_offset
    for i in range(export_count):
        start = pos
        values = struct.unpack_from(endian + 'iiiiiiQii', logical, pos)
        pos += 40
        component_count = struct.unpack_from(endian + 'i', logical, pos)[0]
        pos += 4 + component_count * 12
        export_flags = struct.unpack_from(endian + 'I', logical, pos)[0]
        pos += 4
        generation_count = struct.unpack_from(endian + 'i', logical, pos)[0]
        pos += 4 + generation_count * 4
        guid = logical[pos:pos + 16]
        pos += 16
        exports.append(ExportHeader(i, start, pos, values, component_count, export_flags, generation_count, guid))
    if pos != full_header_size:
        raise ValueError(f'export table ended at {pos}, expected full header size {full_header_size}')

    return {
        'full_header_size': full_header_size,
        'name_count': name_count,
        'name_offset': name_offset,
        'export_count': export_count,
        'export_offset': export_offset,
        'import_count': import_count,
        'import_offset': import_offset,
        'names': names,
        'exports': exports,
    }


def parse_source_upk() -> tuple[bytes, dict, list[ExportHeader]]:
    data = SOURCE_CZ_UPK.read_bytes()
    # Source is a little-endian, uncompressed ME1 package.
    tables = parse_package_tables(data, '<')
    return data, tables, tables['exports']


def parse_tlk_export(export_data: bytes, endian: str) -> tuple[bytes, list[TlkEntry], dict]:
    # All ME1 BioTlkFile exports here use a 40-byte NetIndex + property prefix.
    prefix = export_data[:40]
    pos = 40
    entry_count = struct.unpack_from(endian + 'i', export_data, pos)[0]
    pos += 4
    entries: list[TlkEntry] = []
    for _ in range(entry_count):
        sid, flags, index = struct.unpack_from(endian + 'iii', export_data, pos)
        pos += 12
        entries.append(TlkEntry(sid, flags, index))

    node_count = struct.unpack_from(endian + 'i', export_data, pos)[0]
    pos += 4
    nodes: list[tuple] = []
    for _ in range(node_count):
        leaf = export_data[pos] != 0
        pos += 1
        if leaf:
            codepoint = struct.unpack_from(endian + 'H', export_data, pos)[0]
            pos += 2
            nodes.append(('leaf', chr(codepoint)))
        else:
            right, left = struct.unpack_from(endian + 'hh', export_data, pos)
            pos += 4
            nodes.append(('node', right, left))

    string_count = struct.unpack_from(endian + 'i', export_data, pos)[0]
    pos += 4
    strings: list[str] = []
    for _ in range(string_count):
        _string_length, encoded_length = struct.unpack_from(endian + 'ii', export_data, pos)
        pos += 8
        payload = export_data[pos:pos + encoded_length]
        pos += encoded_length
        strings.append(decode_huffman_string(payload, nodes, endian == '>'))

    if pos != len(export_data):
        raise ValueError(f'TLK parser consumed {pos} of {len(export_data)} bytes')

    for entry in entries:
        if entry.flags == 1:
            if not (0 <= entry.index < len(strings)):
                raise ValueError(f'invalid active TLK index {entry.index}')
            entry.text = strings[entry.index]

    stats = {
        'entry_count': entry_count,
        'node_count': node_count,
        'string_count': string_count,
        'active_count': sum(e.flags == 1 for e in entries),
    }
    return prefix, entries, stats


def decode_huffman_string(payload: bytes, nodes: list[tuple], swap_char_endian: bool) -> str:
    # swap_char_endian is already accounted for while reading the 16-bit leaf codepoint.
    del swap_char_endian
    cur = 0
    chars: list[str] = []
    bit_pos = 0
    max_bits = len(payload) * 8
    while bit_pos < max_bits:
        node = nodes[cur]
        if node[0] == 'leaf':
            ch = node[1]
            if ch == '\0':
                return ''.join(chars)
            chars.append(ch)
            cur = 0
            # Do not consume this bit: the game decoder decrements i after emitting a leaf.
            continue
        bit = (payload[bit_pos // 8] >> (bit_pos % 8)) & 1
        bit_pos += 1
        next_id = node[1] if bit else node[2]  # tuple is ('node', right, left)
        if next_id < 0:
            raise ValueError('internal node unexpectedly points to a negative child')
        cur = next_id
    # A valid TLK string must terminate with NUL.
    raise ValueError('unterminated Huffman string')


def build_huffman(entries: list[TlkEntry]) -> tuple[HuffNode, dict[str, list[int]]]:
    frequency = Counter()
    active_texts = []
    for entry in entries:
        if entry.flags == 1:
            text = (entry.text or '') + '\0'
            active_texts.append(text)
            frequency.update(text)
    if not frequency:
        raise ValueError('cannot build empty Huffman tree')

    heap: list[tuple[int, int, HuffNode]] = []
    serial = 0
    # Character ordering makes the build deterministic when frequencies tie.
    for ch in sorted(frequency):
        heapq.heappush(heap, (frequency[ch], serial, HuffNode(ch, frequency[ch])))
        serial += 1
    while len(heap) > 1:
        f1, _s1, left = heapq.heappop(heap)
        f2, _s2, right = heapq.heappop(heap)
        parent = HuffNode(None, f1 + f2, left=left, right=right)
        heapq.heappush(heap, (parent.freq, serial, parent))
        serial += 1
    root = heap[0][2]

    codes: dict[str, list[int]] = {}
    def walk(node: HuffNode, path: list[int]):
        if node.leaf:
            codes[node.char] = path[:] if path else [0]
            return
        assert node.left is not None and node.right is not None
        walk(node.left, path + [0])
        walk(node.right, path + [1])
    walk(root, [])
    return root, codes


def serialize_tree(root: HuffNode) -> bytes:
    bfs: list[HuffNode] = []
    queue = [root]
    while queue:
        node = queue.pop(0)
        node.node_id = len(bfs)
        bfs.append(node)
        if not node.leaf:
            assert node.right is not None and node.left is not None
            # LegendaryExplorer enqueues right then left.
            queue.append(node.right)
            queue.append(node.left)

    out = bytearray(struct.pack('>i', len(bfs)))
    for node in bfs:
        if node.leaf:
            cp = ord(node.char)
            if cp > 0xFFFF:
                raise ValueError(f'non-BMP character U+{cp:06X} is unsupported by ME1 TLK')
            out.append(1)
            out += struct.pack('>H', cp)
        else:
            assert node.right is not None and node.left is not None
            out.append(0)
            out += struct.pack('>hh', node.right.node_id, node.left.node_id)
    return bytes(out)


def encode_bits(bits: list[int]) -> bytes:
    out = bytearray((len(bits) + 7) // 8)
    for i, bit in enumerate(bits):
        if bit:
            out[i // 8] |= 1 << (i % 8)
    return bytes(out)


def build_tlk_export(prefix: bytes, entries: list[TlkEntry]) -> bytes:
    root, codes = build_huffman(entries)
    tree = serialize_tree(root)

    active_index = 0
    encoded: list[tuple[int, bytes]] = []
    normalized_entries: list[TlkEntry] = []
    for entry in entries:
        e = TlkEntry(entry.string_id, entry.flags, entry.index, entry.text)
        if e.flags == 1:
            e.index = active_index
            active_index += 1
            terminated = (e.text or '') + '\0'
            bits: list[int] = []
            for ch in terminated:
                bits.extend(codes[ch])
            # ME1's decoder emits a leaf on the following loop iteration and
            # reuses that look-ahead bit. Guarantee one trailing bit even when
            # the NUL code ends exactly on a byte boundary.
            bits.append(0)
            encoded.append((len(terminated), encode_bits(bits)))
        else:
            # Match LegendaryExplorer's convention for inactive entries.
            e.index = -1 if e.string_id > 0 else 0
        normalized_entries.append(e)

    out = bytearray(prefix)
    # Keep the original properties, including m_nHashTableSize. It already equals entry count.
    prop_count = struct.unpack_from('>i', out, 28)[0]
    if prop_count != len(normalized_entries):
        struct.pack_into('>i', out, 28, len(normalized_entries))

    out += struct.pack('>i', len(normalized_entries))
    for e in normalized_entries:
        out += struct.pack('>iii', e.string_id, e.flags, e.index)
    out += tree
    out += struct.pack('>i', len(encoded))
    for string_length, payload in encoded:
        out += struct.pack('>ii', string_length, len(payload))
        out += payload
    return bytes(out)


def merge_translation(original_entries: list[TlkEntry], source_entries: list[TlkEntry], xbox_only: dict[str, str]):
    source_by_id = {e.string_id: e.text for e in source_entries if e.flags == 1 and e.text is not None}
    result: list[TlkEntry] = []
    from_pc = 0
    from_xbox_map = 0
    retained_english = 0
    missing: list[dict] = []
    for e in original_entries:
        n = TlkEntry(e.string_id, e.flags, e.index, e.text)
        if n.flags == 1:
            if n.string_id in source_by_id:
                n.text = source_by_id[n.string_id]
                from_pc += 1
            elif (n.text or '') in xbox_only:
                n.text = xbox_only[n.text or '']
                from_xbox_map += 1
            else:
                retained_english += 1
                missing.append({'string_id': n.string_id, 'english': n.text})
        result.append(n)
    return result, {
        'from_pc_czech_by_string_id': from_pc,
        'from_xbox_only_dictionary': from_xbox_map,
        'retained_english': retained_english,
        'missing': missing,
        'active_total': sum(e.flags == 1 for e in result),
    }


def patch_export_header(header: bytes, export: ExportHeader, new_size: int, new_offset: int) -> bytes:
    out = bytearray(header)
    # In the common export header, data size/offset are at +32/+36.
    struct.pack_into('>ii', out, export.start + 32, new_size, new_offset)
    return bytes(out)


def build_lzo_package(source_pkg: bytes, logical: bytes, source_records: list[tuple[int, int, int, int]], package_source: bytes):
    # Preserve the known-working two-chunk layout start and first chunk size.
    first_uoff, first_usize, _coff, _csize = source_records[0]
    second_uoff = first_uoff + first_usize
    if second_uoff >= len(logical):
        raise ValueError('new logical package unexpectedly fits in one chunk')
    records_plain = [
        (first_uoff, first_usize),
        (second_uoff, len(logical) - second_uoff),
    ]

    physical_header_size = 125 + len(records_plain) * 16 + 4
    chunks = []
    cur = physical_header_size
    for uoff, usize in records_plain:
        chunk, blocks = lzoctl.build_chunk(logical[uoff:uoff + usize])
        chunks.append({
            'uoff': uoff,
            'usize': usize,
            'coff': cur,
            'csize': len(chunk),
            'chunk': chunk,
            'blocks': blocks,
        })
        cur += len(chunk)

    header = bytearray(source_pkg[:125])
    # chunk count remains two, so the physical header size remains exactly 161 bytes.
    for c in chunks:
        header += struct.pack('>iiii', c['uoff'], c['usize'], c['coff'], c['csize'])
    header += package_source
    if len(header) != physical_header_size:
        raise AssertionError((len(header), physical_header_size))
    return bytes(header) + b''.join(c['chunk'] for c in chunks), chunks


def main():
    original_pkg = ORIGINAL_XBOX.read_bytes()
    original_logical, source_records, source_blocks, _ = lzoctl.decompress_package(original_pkg)
    original_tables = parse_package_tables(original_logical, '>')
    names = original_tables['names']
    exports: list[ExportHeader] = original_tables['exports']

    expected_names = ['GlobalTlk_tlk', 'GlobalTlk_tlk_M', 'SeekFreeSaver', 'SeekFreeShaderCache']
    actual_names = [names[e.name_index] for e in exports]
    if actual_names != expected_names:
        raise ValueError(f'unexpected original exports: {actual_names}')

    source_upk, source_tables, source_exports = parse_source_upk()
    source_names = source_tables['names']
    if [source_names[e.name_index] for e in source_exports] != ['GlobalTlk_tlk', 'GlobalTlk_tlk_M']:
        raise ValueError('unexpected Czech source exports')

    # Parse original Xbox English and Czech PC source TLKs.
    original_parsed = []
    source_parsed = []
    for i in range(2):
        oe = exports[i]
        original_data = original_logical[oe.data_offset:oe.data_offset + oe.data_size]
        original_parsed.append(parse_tlk_export(original_data, '>'))

        se = source_exports[i]
        source_data = source_upk[se.data_offset:se.data_offset + se.data_size]
        source_parsed.append(parse_tlk_export(source_data, '<'))

    xbox_only = json.loads(XBOX_ONLY_JSON.read_text(encoding='utf-8'))
    merged_entries = []
    coverage = []
    for i in range(2):
        merged, cov = merge_translation(original_parsed[i][1], source_parsed[i][1], xbox_only)
        merged_entries.append(merged)
        coverage.append(cov)
        if cov['retained_english'] != 0:
            raise RuntimeError(f'gender {i}: {cov["retained_english"]} active strings remain untranslated')

    new_tlk0 = build_tlk_export(original_parsed[0][0], merged_entries[0])
    new_tlk1 = build_tlk_export(original_parsed[1][0], merged_entries[1])

    # Preserve the complete original header, imports, names, helper export headers and helper data.
    full_header_size = original_tables['full_header_size']
    header = bytes(original_logical[:full_header_size])
    helper2 = original_logical[exports[2].data_offset:exports[2].data_offset + exports[2].data_size]
    helper3 = original_logical[exports[3].data_offset:exports[3].data_offset + exports[3].data_size]

    data_offsets = []
    cursor = full_header_size
    for blob in (new_tlk0, new_tlk1, helper2, helper3):
        data_offsets.append(cursor)
        cursor += len(blob)

    patched_header = header
    for exp, blob, off in zip(exports, (new_tlk0, new_tlk1, helper2, helper3), data_offsets):
        patched_header = patch_export_header(patched_header, exp, len(blob), off)

    logical = patched_header + new_tlk0 + new_tlk1 + helper2 + helper3
    package_source_pos = 125 + 16 * len(source_records)
    package_source = original_pkg[package_source_pos:package_source_pos + 4]
    output_pkg, built_chunks = build_lzo_package(original_pkg, logical, source_records, package_source)

    # Full physical and logical validation.
    rebuilt_logical, rebuilt_records, rebuilt_blocks, _ = lzoctl.decompress_package(output_pkg)
    if rebuilt_logical != logical:
        raise RuntimeError('LZO package round-trip mismatch')
    rebuilt_tables = parse_package_tables(rebuilt_logical, '>')
    rebuilt_exports: list[ExportHeader] = rebuilt_tables['exports']
    if rebuilt_tables['names'] != names:
        raise RuntimeError('name table changed')
    if rebuilt_tables['import_count'] != original_tables['import_count']:
        raise RuntimeError('import table count changed')

    decoded_validation = []
    for i in range(2):
        e = rebuilt_exports[i]
        _prefix, decoded_entries, stats = parse_tlk_export(rebuilt_logical[e.data_offset:e.data_offset + e.data_size], '>')
        expected = {x.string_id: x.text for x in merged_entries[i] if x.flags == 1}
        actual = {x.string_id: x.text for x in decoded_entries if x.flags == 1}
        if actual != expected:
            raise RuntimeError(f'gender {i}: encoded TLK decode mismatch')
        decoded_validation.append(stats)

    # Verify both helper exports are byte-for-byte unchanged after relocation.
    for i, expected_blob in ((2, helper2), (3, helper3)):
        e = rebuilt_exports[i]
        actual_blob = rebuilt_logical[e.data_offset:e.data_offset + e.data_size]
        if actual_blob != expected_blob:
            raise RuntimeError(f'helper export {i} changed')

    OUTDIR.mkdir(parents=True, exist_ok=True)
    OUTFILE.write_bytes(output_pkg)
    shutil.copy2(ORIGINAL_XBOX, OUTDIR / 'GlobalTlk_original_backup.xxx')
    shutil.copy2(Path(__file__), OUTDIR / 'build_me1_x360_cz_base_v4.py')

    report = {
        'build': 'ME1 Xbox 360 Czech base-game package v4',
        'runtime_prerequisite': 'The English LZO control rebuild v3 was confirmed working on the user Xbox 360.',
        'source_files': {
            'original_xbox_globaltlk_sha256': sha256(original_pkg),
            'czech_pc_globaltlk_upk_sha256': sha256(source_upk),
            'xbox_only_translation_json_sha256': sha256(XBOX_ONLY_JSON.read_bytes()),
        },
        'output': {
            'file': 'GlobalTlk.xxx',
            'size': len(output_pkg),
            'sha256': sha256(output_pkg),
            'logical_size': len(logical),
            'logical_sha256': sha256(logical),
        },
        'package_structure': {
            'full_header_size': rebuilt_tables['full_header_size'],
            'name_count': rebuilt_tables['name_count'],
            'import_count': rebuilt_tables['import_count'],
            'export_count': rebuilt_tables['export_count'],
            'exports': [
                {
                    'name': rebuilt_tables['names'][e.name_index],
                    'size': e.data_size,
                    'offset': e.data_offset,
                }
                for e in rebuilt_exports
            ],
            'compression': 'UE3 type 2 / LZO1X',
            'chunk_records': rebuilt_records,
            'blocks': rebuilt_blocks,
        },
        'translation_coverage': {
            'female': coverage[0],
            'male': coverage[1],
        },
        'tlk_validation': {
            'female': decoded_validation[0],
            'male': decoded_validation[1],
            'encode_decode_round_trip': 'PASS',
        },
        'checks': [
            'original 113-name table preserved',
            'original 5 imports preserved',
            'all 4 original exports preserved',
            'SeekFreeSaver preserved byte-for-byte',
            'SeekFreeShaderCache preserved byte-for-byte',
            'all active base-game strings translated in both gender tables',
            'all new LZO blocks decompressed successfully',
            'rebuilt logical package matches the intended bytes exactly',
        ],
        'runtime_status': 'PENDING XBOX 360 TEST',
    }
    # Do not expose the large missing arrays in the normal report when they are empty.
    for key in ('female', 'male'):
        report['translation_coverage'][key]['missing'] = report['translation_coverage'][key]['missing'][:20]
    (OUTDIR / 'validation.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')

    readme = f'''Mass Effect 1 Xbox 360 – česká základní hra v4\n\nTato verze navazuje na úspěšný anglický LZO kontrolní rebuild v3.\nPoužívá originální xboxový GlobalTlk.xxx jako pevnou šablonu a mění pouze dva BioTlkFile exporty.\nOba pomocné cooked exporty zůstávají bitově shodné s originálem.\n\nTESTUJ NYNÍ JEN ZÁKLADNÍ HRU:\n1. Zálohuj Hdd1:/Games/Mass Effect 1/Layer0/MEInit/GlobalTlk.xxx\n2. Nahraď jej souborem GlobalTlk.xxx z tohoto balíčku.\n3. Obě oficiální DLC ponech originální.\n4. Odstraň nebo vypni všechna dřívější experimentální česká DLC.\n5. Proveď úplný restart konzole a spusť hru.\n\nOčekávání: hra naběhne a základní nabídka/texty budou česky.\nPo potvrzení této verze budou stejným LZO postupem upraveny Bring Down the Sky a Pinnacle Station.\n\nNový SHA-256: {sha256(output_pkg)}\nPůvodní SHA-256: {sha256(original_pkg)}\nPro návrat použij GlobalTlk_original_backup.xxx.\n'''
    (OUTDIR / 'README_CS.txt').write_text(readme, encoding='utf-8')

    with zipfile.ZipFile(OUTZIP, 'w', zipfile.ZIP_DEFLATED) as z:
        for p in sorted(OUTDIR.iterdir()):
            z.write(p, p.name)

    print(json.dumps(report, ensure_ascii=False, indent=2))
    print('OUTPUT', OUTFILE)
    print('ZIP', OUTZIP)


if __name__ == '__main__':
    main()
