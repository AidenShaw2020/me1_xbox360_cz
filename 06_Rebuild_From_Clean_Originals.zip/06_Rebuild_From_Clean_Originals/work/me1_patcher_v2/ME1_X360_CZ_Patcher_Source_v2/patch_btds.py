#!/usr/bin/env python3
"""Patch the original Bring Down the Sky STFS package with Czech TLKs."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import struct
import sys

from me1lib import lzo_ue3 as lzo
from me1lib import stfs
from me1lib import ue3_tlk as tlk

ROOT = Path(__file__).resolve().parent
DEFAULT_SOURCE_UPK = ROOT / "assets" / "GlobalTlk_CS.upk"
sys.path.insert(0, str(ROOT.parents[2] / "tools"))
from patch_me1_fallback_dialog import build_with_donor_tree  # noqa: E402
import patch_me1_map_dialogs as runtime_tlk  # noqa: E402

EXPECTED_ORIGINAL_SHA256 = "bfc495b1d687015209b830ef7c8097cd6a78fe2d5f7f33868ae41970d053e06c"
EXPECTED_SOURCE_UPK_SHA256 = "5d9afea8da2a3f149f5d8dbfdac1317255a01f41f4a73f858216d5c7306b9648"
EXPECTED_OUTPUT_SHA256 = "fc152e51004e2765c838f1aad6359f093b70321e07cbb96c17e14dd4a4e9d92c"
EXPECTED_OUTPUT_CONTENT_ID = "066134EE0B0841AFB85DE249C968D3BB82627363"
EXPECTED_OUTPUT_SIZE = 265666560

ENGLISH_PATH = "Content/Packages/Dialog/DLC_UNC_GlobalTlk.xxx"
DONOR_PATH = "Content/Packages/Localised/ES/Dialog/DLC_UNC_GlobalTlk_ES.xxx"
DISPLAY_NAME_CZ = "Strhnout oblohu [ENPLES]"
DESCRIPTION_CZ = (
    "Batariánští extremisté unesli asteroid X57 a nasměrovali jej na Terru Novu. "
    "Zastavte je dřív, než planetu zničí."
)
UNLOCKED_LICENSES = bytes.fromhex(
    "ffffffffffffffff0000000100000001"
    "ffffffffffffffff0000000100000000"
    "ffffffffffffffff0000000100000001"
) + bytes(0x100 - 0x30)


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while chunk := f.read(1024 * 1024):
            h.update(chunk)
    return h.hexdigest()


def require_hash(path: Path, expected: str, label: str, force: bool) -> str:
    found = sha256_file(path)
    if found != expected and not force:
        raise ValueError(
            f"{label} má nepodporovaný SHA-256.\nNalezeno: {found}\nOčekáváno: {expected}\n"
            "Použij --force pouze po nezávislém ověření vstupu."
        )
    return found


def build_czech_inner(original: bytes, source_upk: bytes) -> tuple[bytes, dict]:
    original_logical, source_records, source_blocks, _ = lzo.decompress_package(original)
    tables = tlk.parse_package_tables(original_logical, ">")
    names = tables["names"]
    exports = tables["exports"]
    expected = [
        "GlobalTlk_tlk",
        "GlobalTlk_tlk_M",
        "SeekFreeSaver",
        "SeekFreeShaderCache",
    ]
    if [names[e.name_index] for e in exports] != expected:
        raise RuntimeError("Nečekané exporty Bring Down the Sky")

    source_tables = tlk.parse_package_tables(source_upk, "<")
    source_exports = source_tables["exports"]
    source_names = source_tables["names"]
    if [source_names[e.name_index] for e in source_exports] != [
        "GlobalTlk_tlk",
        "GlobalTlk_tlk_M",
    ]:
        raise RuntimeError("Nečekané exporty v českém PC zdroji")

    new_tlks: list[bytes] = []
    translated_maps: list[dict[int, str | None]] = []
    original_parsed = []
    coverage = []
    for gender in range(2):
        oe = exports[gender]
        prefix, original_entries, original_stats = tlk.parse_tlk_export(
            original_logical[oe.data_offset : oe.data_offset + oe.data_size], ">"
        )
        se = source_exports[gender]
        _source_prefix, source_entries, _source_stats = tlk.parse_tlk_export(
            source_upk[se.data_offset : se.data_offset + se.data_size], "<"
        )
        source_by_id = {e.string_id: e.text for e in source_entries if e.flags == 1}
        merged: list[tlk.TlkEntry] = []
        missing = []
        for entry in original_entries:
            text = entry.text
            if entry.flags == 1:
                if entry.string_id not in source_by_id:
                    missing.append({"string_id": entry.string_id, "english": entry.text})
                else:
                    text = source_by_id[entry.string_id]
            merged.append(tlk.TlkEntry(entry.string_id, entry.flags, entry.index, text))
        if missing:
            raise RuntimeError(
                f"Tabulka {gender}: chybí {len(missing)} českých DLC řetězců; první: {missing[:3]}"
            )
        cooker_binary = source_upk[
            se.data_offset + len(_source_prefix) : se.data_offset + se.data_size
        ]
        runtime_binary = build_with_donor_tree(merged, cooker_binary, "<", ">")
        blob = prefix + runtime_binary
        new_tlks.append(blob)
        translated_maps.append(tlk.active_map(merged))
        original_parsed.append((prefix, original_entries, original_stats))
        coverage.append(
            {
                "gender": gender,
                "entry_count": len(merged),
                "active_count": sum(e.flags == 1 for e in merged),
                "translated_by_string_id": sum(e.flags == 1 for e in merged),
                "old_export_size": oe.data_size,
                "new_export_size": len(blob),
            }
        )

    # Rebuild the serial-data area compactly. Appending replacement exports left
    # stale copies in the seek-free package; the Xbox runtime rejects that even
    # though the generic UE3 parser can still decode it.
    first_data = min(e.data_offset for e in exports)
    logical = bytearray(original_logical[:first_data])
    offsets: list[int] = []
    export_blobs = new_tlks + [
        original_logical[e.data_offset : e.data_offset + e.data_size]
        for e in exports[2:]
    ]
    for i, blob in enumerate(export_blobs):
        offsets.append(len(logical))
        logical += blob
        struct.pack_into(">ii", logical, exports[i].start + 32, len(blob), offsets[i])

    # Original BDtS uses a single LZO chunk; preserve that layout.
    raw = bytes(logical[129:])
    chunk, blocks = lzo.build_chunk(raw)
    physical_header = bytearray(original[:125])
    struct.pack_into(">i", physical_header, 117, 2)
    struct.pack_into(">i", physical_header, 121, 1)
    physical_header += struct.pack(">iiii", 129, len(raw), 145, len(chunk))
    physical_header += original[141:145]
    if len(physical_header) != 145:
        raise RuntimeError("Nečekaná fyzická hlavička BDtS")
    output = bytes(physical_header) + chunk

    rebuilt_logical, rebuilt_records, rebuilt_blocks, _ = lzo.decompress_package(output)
    if rebuilt_logical != bytes(logical):
        raise RuntimeError("BDtS inner LZO round-trip nesouhlasí")
    rebuilt_tables = tlk.parse_package_tables(rebuilt_logical, ">")
    if rebuilt_tables["names"] != names:
        raise RuntimeError("BDtS tabulka názvů se změnila")
    if rebuilt_tables["import_count"] != tables["import_count"] or rebuilt_tables["export_count"] != 4:
        raise RuntimeError("BDtS identita importů/exportů se změnila")

    for i in range(2):
        e = rebuilt_tables["exports"][i]
        rebuilt_blob = rebuilt_logical[e.data_offset : e.data_offset + e.data_size]
        prefix = rebuilt_blob[:40]
        entries = runtime_tlk.ue3.parse_tlk(rebuilt_blob[40:], ">")
        if prefix != original_parsed[i][0]:
            raise RuntimeError(f"BDtS tabulka {i}: property prefix se změnil")
        if tlk.active_map(entries) != translated_maps[i]:
            raise RuntimeError(f"BDtS tabulka {i}: český round-trip nesouhlasí")

    helpers = []
    for i in (2, 3):
        old = exports[i]
        new = rebuilt_tables["exports"][i]
        old_blob = original_logical[old.data_offset : old.data_offset + old.data_size]
        new_blob = rebuilt_logical[new.data_offset : new.data_offset + new.data_size]
        if old.data_size != new.data_size or old_blob != new_blob:
            raise RuntimeError(f"Helper export {expected[i]} se změnil")
        helpers.append(
            {
                "name": expected[i],
                "offset": new.data_offset,
                "size": new.data_size,
                "sha256": sha256_bytes(new_blob),
                "byte_identical": True,
            }
        )

    report = {
        "source_inner_sha256": sha256_bytes(original),
        "output_inner_sha256": sha256_bytes(output),
        "source_inner_size": len(original),
        "output_inner_size": len(output),
        "logical_size": len(rebuilt_logical),
        "source_chunk_records": source_records,
        "source_lzo_blocks": source_blocks,
        "chunk_records": rebuilt_records,
        "lzo_blocks": rebuilt_blocks,
        "coverage": coverage,
        "helpers": helpers,
        "required_stfs_blocks": (len(output) + stfs.SECTOR - 1) // stfs.SECTOR,
    }
    return output, report


def patch_dlc(
    original_dlc: Path,
    source_upk_path: Path,
    output_dir: Path,
    *,
    force: bool = False,
) -> tuple[Path, dict]:
    input_hash = require_hash(
        original_dlc, EXPECTED_ORIGINAL_SHA256, "Originální Bring Down the Sky DLC", force
    )
    source_hash = require_hash(
        source_upk_path, EXPECTED_SOURCE_UPK_SHA256, "GlobalTlk_CS.upk", force
    )
    source_upk = source_upk_path.read_bytes()

    src_stfs = stfs.STFS(original_dlc)
    if src_stfs.title_id != 0x4D5307E8 or src_stfs.content_type != 2:
        raise RuntimeError("Nečekaná STFS identita Bring Down the Sky")
    english = src_stfs.entry_by_path(ENGLISH_PATH)
    donor = src_stfs.entry_by_path(DONOR_PATH)
    original_inner = src_stfs.read_file(english)
    inner, inner_report = build_czech_inner(original_inner, source_upk)

    english_blocks = list(range(english.start_block, english.start_block + english.alloc_blocks))
    required = (len(inner) + stfs.SECTOR - 1) // stfs.SECTOR
    extra = max(0, required - len(english_blocks))
    donor_blocks = list(range(donor.start_block, donor.start_block + donor.alloc_blocks))
    donated = donor_blocks[-extra:] if extra else []
    remaining_donor = donor_blocks[:-extra] if extra else donor_blocks
    chain = english_blocks + donated
    if required > len(chain):
        raise RuntimeError(
            f"Český BDtS balíček potřebuje {required} bloků, k dispozici je {len(chain)}"
        )

    output_dir.mkdir(parents=True, exist_ok=True)
    tmp = output_dir / ".btds_cz.tmp"
    shutil.copyfile(original_dlc, tmp)
    modified_data = set(chain)
    if remaining_donor:
        modified_data.add(remaining_donor[-1])
    modified_data.add(english.dir_block)
    modified_data.add(donor.dir_block)

    with tmp.open("r+b") as fp:
        fp.seek(0x22C)
        fp.write(UNLOCKED_LICENSES)
        stfs.patch_display_metadata(fp, DISPLAY_NAME_CZ, DESCRIPTION_CZ)
        stfs.write_chain(fp, src_stfs, chain, inner)
        stfs.patch_dir_entry(
            fp,
            src_stfs,
            english,
            valid_blocks=required,
            alloc_blocks=required,
            start_block=chain[0],
            size=len(inner),
            contiguous=all(b + 1 == chain[i + 1] for i, b in enumerate(chain[:-1])),
        )
        stfs.patch_dir_entry(
            fp,
            src_stfs,
            donor,
            valid_blocks=len(remaining_donor),
            alloc_blocks=len(remaining_donor),
            start_block=remaining_donor[0] if remaining_donor else 0xFFFFFF,
            size=min(donor.size, len(remaining_donor) * stfs.SECTOR),
            contiguous=True,
        )
        if remaining_donor:
            stfs.set_chain_record(fp, src_stfs, remaining_donor[-1], 0xFFFFFF)
        stfs.rehash(fp, src_stfs, modified_data)

    content_id = stfs.verify_stfs(tmp, modified_data)
    final = output_dir / content_id
    if final.exists():
        final.unlink()
    tmp.rename(final)

    check = stfs.STFS(final)
    check_english = check.entry_by_path(ENGLISH_PATH)
    extracted, observed_chain = stfs.read_chain(final, check, check_english)
    if extracted != inner:
        raise RuntimeError("BDtS STFS extrakce neodpovídá českému inner balíčku")
    if observed_chain != chain[: len(observed_chain)]:
        raise RuntimeError("BDtS blokový řetězec neodpovídá zamýšlenému řetězci")

    with final.open("rb") as fp:
        for i, block in enumerate(chain):
            fp.seek(stfs.hash_record_offset(check, block) + 20)
            status = fp.read(1)[0]
            nxt = int.from_bytes(fp.read(3), "big")
            expected_next = chain[i + 1] if i + 1 < len(chain) else 0xFFFFFF
            if status != 0x80 or nxt != expected_next:
                raise RuntimeError(
                    f"Neplatný BDtS chain record bloku {block}: {status:02X}/{nxt:06X}"
                )

    donor_check = check.entry_by_path(DONOR_PATH)
    if donor_check.alloc_blocks != len(remaining_donor):
        raise RuntimeError("Španělský donor nebyl správně uvolněn")

    output_hash = sha256_file(final)
    report = {
        "build": "Mass Effect 1 Xbox 360 – Bring Down the Sky Czech v1 reproducible patcher",
        "runtime_status": "PENDING XBOX 360 CONTENT TEST",
        "inputs": {
            "original_dlc": {
                "path": str(original_dlc),
                "size": original_dlc.stat().st_size,
                "sha256": input_hash,
                "content_id": src_stfs.content_id.hex().upper(),
            },
            "czech_source": {
                "path": str(source_upk_path),
                "sha256": source_hash,
            },
        },
        "inner_package": inner_report,
        "output": {
            "path": str(final),
            "filename_content_id": content_id,
            "size": final.stat().st_size,
            "sha256": output_hash,
            "tested_reference_content_id": EXPECTED_OUTPUT_CONTENT_ID,
            "tested_reference_sha256": EXPECTED_OUTPUT_SHA256,
            "tested_reference_size": EXPECTED_OUTPUT_SIZE,
            "exact_match_to_reference": (
                content_id == EXPECTED_OUTPUT_CONTENT_ID
                and output_hash == EXPECTED_OUTPUT_SHA256
                and final.stat().st_size == EXPECTED_OUTPUT_SIZE
            ),
        },
        "allocation": {
            "english_path": ENGLISH_PATH,
            "donor_path": DONOR_PATH,
            "required_blocks": required,
            "allocated_blocks": len(chain),
            "chain_first": chain[0],
            "chain_bridge": [english_blocks[-1], donor_blocks[0]],
            "chain_last": chain[-1],
            "language_impact": "Spanish DLC talk table is removed; INT/Czech is supported.",
        },
        "checks": [
            "417 active BDtS strings translated in both gender tables",
            "inner package LZO round trip and TLK semantic round trip",
            "helper exports byte-identical at original offsets",
            "STFS L0/L1/L2 hashes and Content ID verified",
            "patched chained extraction equals generated inner package",
        ],
    }
    report_path = output_dir / "validation_btds.json"
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    (output_dir / "DLC_UNC_GlobalTlk_CZ.xxx").write_bytes(inner)
    return final, report


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Vytvoří český Bring Down the Sky STFS balíček z originálu."
    )
    parser.add_argument("original_dlc", type=Path)
    parser.add_argument("--output-dir", type=Path, default=Path("output_btds"))
    parser.add_argument("--source-upk", type=Path, default=DEFAULT_SOURCE_UPK)
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--strict-tested-hash", action="store_true")
    args = parser.parse_args()

    try:
        final, report = patch_dlc(
            args.original_dlc.resolve(),
            args.source_upk.resolve(),
            args.output_dir.resolve(),
            force=args.force,
        )
        if args.strict_tested_hash and not report["output"]["exact_match_to_reference"]:
            raise RuntimeError("BDtS výstup se neshoduje s referenčním buildem")
    except Exception as exc:
        print(f"CHYBA: {exc}", file=sys.stderr)
        return 1

    print(f"Hotovo: {final}")
    print(f"SHA-256: {report['output']['sha256']}")
    print(
        "Shoda s referencí: "
        + ("ANO" if report["output"]["exact_match_to_reference"] else "NE")
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
