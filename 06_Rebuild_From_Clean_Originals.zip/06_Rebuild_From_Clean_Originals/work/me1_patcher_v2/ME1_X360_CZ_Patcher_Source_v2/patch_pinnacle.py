#!/usr/bin/env python3
"""Patch the original Pinnacle Station STFS package with Czech TLKs."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import struct
import sys

from me1lib import stfs
from me1lib import ue3_tlk as tlk

ROOT = Path(__file__).resolve().parent
DEFAULT_TRANSLATIONS = ROOT / "assets" / "DLC_Vegas_translation_cs.json"
DEFAULT_DONOR_UPK = ROOT / "assets" / "GlobalTlk_CS.upk"
sys.path.insert(0, str(ROOT.parents[2] / "tools"))
from patch_me1_fallback_dialog import build_with_donor_tree  # noqa: E402
import patch_me1_map_dialogs as runtime_tlk  # noqa: E402

EXPECTED_ORIGINAL_SHA256 = "a893369bb08393e5660c75591f8af653af8ccb5200df30dee50290a8f221e71a"
EXPECTED_TRANSLATION_SHA256 = "69f79046f49ce97aa15f1055efea84d76de377fcdb1b0b2c18ddacfe1f716876"
EXPECTED_OUTPUT_SHA256 = "c61721df77ea5912810afa3fee06d5f82c445732eba6c0b25d2bb044b07891c3"
EXPECTED_OUTPUT_CONTENT_ID = "FE46A00A9CC91D9982ADD6815E30E0607B2B52A9"
EXPECTED_OUTPUT_SIZE = 257900544

ENGLISH_PATH = "Content/Packages/Dialog/DLC_Vegas_GlobalTlk.xxx"
DONOR_PATH = "Content/Packages/Localised/ES/bioa_prc2_ccscoreboard_dsg_ES.xxx"
DISPLAY_NAME_CZ = "Stanice Pinnacle [ENPLES]"
DESCRIPTION_CZ = (
    "Navštivte stanici Pinnacle a zapojte se do série bojových simulací "
    "ve vojenském výcvikovém středisku Rady."
)
UNLOCKED_LICENSES = bytes.fromhex(
    "ffffffffffffffff0000000100000001"
    "ffffffffffffffff0000000100000000"
    "ffffffffffffffff0000000100000001"
) + bytes(0x100 - 0x30)


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while chunk := f.read(1024 * 1024):
            h.update(chunk)
    return h.hexdigest()


def require_hash(path: Path, expected: str, label: str, force: bool) -> str:
    found = sha256_file(path)
    if found != expected and not force:
        raise ValueError(
            f"{label} má nepodporovaný SHA-256.\nNalezeno: {found}\nOčekáváno: {expected}\n"
            "Použij --force pouze po nezávislém ověření vstupu."
        )
    return found


def build_czech_inner(
    original: bytes, translations: dict[str, str], donor_upk: bytes
) -> tuple[bytes, dict]:
    if len(original) < 129:
        raise RuntimeError("Pinnacle TLK balíček je nečekaně krátký")
    compression_type = struct.unpack_from(">i", original, 117)[0]
    chunk_count = struct.unpack_from(">i", original, 121)[0]
    if compression_type != 0 or chunk_count != 0:
        raise RuntimeError(
            f"Očekáván nekomprimovaný Pinnacle balíček, nalezen typ={compression_type}, chunky={chunk_count}"
        )

    tables = tlk.parse_package_tables(original, ">")
    names = tables["names"]
    exports = tables["exports"]
    expected = ["GlobalTlk_tlk", "GlobalTlk_tlk_M"]
    actual = [names[e.name_index] for e in exports]
    if actual != expected:
        raise RuntimeError(f"Nečekané exporty Pinnacle Station: {actual}")

    donor_tables = tlk.parse_package_tables(donor_upk, "<")
    donor_exports = donor_tables["exports"]
    new_tlks: list[bytes] = []
    translated_maps: list[dict[int, str | None]] = []
    original_prefixes: list[bytes] = []
    coverage = []

    for gender in range(2):
        oe = exports[gender]
        prefix, original_entries, original_stats = tlk.parse_tlk_export(
            original[oe.data_offset : oe.data_offset + oe.data_size], ">"
        )
        missing = []
        merged: list[tlk.TlkEntry] = []
        for entry in original_entries:
            text = entry.text
            if entry.flags == 1:
                if text not in translations:
                    missing.append({"string_id": entry.string_id, "english": text})
                else:
                    text = translations[text]
            merged.append(tlk.TlkEntry(entry.string_id, entry.flags, entry.index, text))
        if missing:
            raise RuntimeError(
                f"Tabulka {gender}: chybí {len(missing)} českých řetězců Pinnacle; první: {missing[:3]}"
            )

        donor_export = donor_exports[gender]
        donor_prefix, _donor_entries, _donor_stats = tlk.parse_tlk_export(
            donor_upk[
                donor_export.data_offset : donor_export.data_offset + donor_export.data_size
            ],
            "<",
        )
        donor_binary = donor_upk[
            donor_export.data_offset + len(donor_prefix) :
            donor_export.data_offset + donor_export.data_size
        ]
        runtime_binary = build_with_donor_tree(merged, donor_binary, "<", ">")
        blob = prefix + runtime_binary
        new_tlks.append(blob)
        translated_maps.append(tlk.active_map(merged))
        original_prefixes.append(prefix)
        coverage.append(
            {
                "gender": gender,
                "entry_count": len(merged),
                "active_count": sum(e.flags == 1 for e in merged),
                "unique_source_strings": len(
                    {e.text for e in original_entries if e.flags == 1}
                ),
                "translated_source_strings": len(
                    {e.text for e in original_entries if e.flags == 1}
                ),
                "old_export_size": oe.data_size,
                "new_export_size": len(blob),
                "original_tlk_stats": original_stats,
            }
        )

    first_data = min(e.data_offset for e in exports)
    logical = bytearray(original[:first_data])
    offsets: list[int] = []
    for i, blob in enumerate(new_tlks):
        offsets.append(len(logical))
        logical += blob
        struct.pack_into(">ii", logical, exports[i].start + 32, len(blob), offsets[i])
    output = bytes(logical)

    rebuilt_tables = tlk.parse_package_tables(output, ">")
    if rebuilt_tables["names"] != names:
        raise RuntimeError("Pinnacle tabulka názvů se změnila")
    if rebuilt_tables["import_count"] != tables["import_count"] or rebuilt_tables["export_count"] != 2:
        raise RuntimeError("Pinnacle identita importů/exportů se změnila")
    for i in range(2):
        e = rebuilt_tables["exports"][i]
        rebuilt_blob = output[e.data_offset : e.data_offset + e.data_size]
        prefix = rebuilt_blob[:40]
        entries = runtime_tlk.ue3.parse_tlk(rebuilt_blob[40:], ">")
        if prefix != original_prefixes[i]:
            raise RuntimeError(f"Pinnacle tabulka {i}: property prefix se změnil")
        if tlk.active_map(entries) != translated_maps[i]:
            raise RuntimeError(f"Pinnacle tabulka {i}: český round-trip nesouhlasí")
        if sum(item.flags == 1 for item in entries) != coverage[i]["active_count"]:
            raise RuntimeError(f"Pinnacle tabulka {i}: změnil se počet aktivních textů")

    allowed = set()
    for e in exports:
        allowed.update(range(e.start + 32, e.start + 40))
    changed_prefix = [
        i for i, (a, b) in enumerate(zip(original[:first_data], output[:first_data])) if a != b
    ]
    if any(i not in allowed for i in changed_prefix):
        raise RuntimeError("Nečekaná změna uvnitř původního Pinnacle balíčku")

    return output, {
        "source_inner_sha256": sha256_bytes(original),
        "output_inner_sha256": sha256_bytes(output),
        "source_inner_size": len(original),
        "output_inner_size": len(output),
        "compression_type": 0,
        "chunk_count": 0,
        "coverage": coverage,
        "changed_original_prefix_bytes": len(changed_prefix),
        "appended_tlk_offsets": offsets,
        "required_stfs_blocks": (len(output) + stfs.SECTOR - 1) // stfs.SECTOR,
    }


def patch_dlc(
    original_dlc: Path,
    translations_path: Path,
    output_dir: Path,
    *,
    force: bool = False,
) -> tuple[Path, dict]:
    input_hash = require_hash(
        original_dlc, EXPECTED_ORIGINAL_SHA256, "Originální Pinnacle Station DLC", force
    )
    translation_hash = require_hash(
        translations_path,
        EXPECTED_TRANSLATION_SHA256,
        "Česká překladová mapa Pinnacle",
        force,
    )
    translations = json.loads(translations_path.read_text(encoding="utf-8"))
    if not isinstance(translations, dict):
        raise RuntimeError("Překladový zdroj Pinnacle není JSON objekt")

    src_stfs = stfs.STFS(original_dlc)
    if src_stfs.title_id != 0x4D5307E8 or src_stfs.content_type != 2:
        raise RuntimeError("Nečekaná STFS identita Pinnacle Station")
    english = src_stfs.entry_by_path(ENGLISH_PATH)
    donor = src_stfs.entry_by_path(DONOR_PATH)
    original_inner = src_stfs.read_file(english)
    inner, inner_report = build_czech_inner(
        original_inner, translations, DEFAULT_DONOR_UPK.read_bytes()
    )

    required = (len(inner) + stfs.SECTOR - 1) // stfs.SECTOR
    if required > donor.alloc_blocks:
        raise RuntimeError(
            f"Český Pinnacle balíček potřebuje {required} bloků, donor má {donor.alloc_blocks}"
        )

    output_dir.mkdir(parents=True, exist_ok=True)
    tmp = output_dir / ".pinnacle_cz.tmp"
    shutil.copyfile(original_dlc, tmp)
    donor_blocks = list(range(donor.start_block, donor.start_block + donor.alloc_blocks))
    used_blocks = donor_blocks[-required:]
    remaining_donor = donor_blocks[:-required]
    modified_data = set(used_blocks)
    modified_data.add(english.dir_block)
    modified_data.add(donor.dir_block)

    with tmp.open("r+b") as fp:
        fp.seek(0x22C)
        fp.write(UNLOCKED_LICENSES)
        stfs.patch_display_metadata(fp, DISPLAY_NAME_CZ, DESCRIPTION_CZ)
        stfs.write_chain(fp, src_stfs, used_blocks, inner)
        stfs.patch_dir_entry(
            fp,
            src_stfs,
            english,
            valid_blocks=required,
            alloc_blocks=required,
            start_block=used_blocks[0],
            size=len(inner),
            contiguous=True,
        )
        stfs.patch_dir_entry(
            fp,
            src_stfs,
            donor,
            valid_blocks=len(remaining_donor),
            alloc_blocks=len(remaining_donor),
            start_block=remaining_donor[0] if remaining_donor else 0xFFFFFF,
            size=min(donor.size, len(remaining_donor) * stfs.SECTOR),
            contiguous=True,
        )
        if remaining_donor:
            stfs.set_chain_record(fp, src_stfs, remaining_donor[-1], 0xFFFFFF)
            modified_data.add(remaining_donor[-1])
        stfs.rehash(fp, src_stfs, modified_data)

    content_id = stfs.verify_stfs(tmp, modified_data)
    final = output_dir / content_id
    if final.exists():
        final.unlink()
    tmp.rename(final)

    check = stfs.STFS(final)
    check_english = check.entry_by_path(ENGLISH_PATH)
    extracted = check.read_file(check_english)
    if extracted != inner:
        raise RuntimeError("Pinnacle STFS extrakce neodpovídá českému inner balíčku")
    if check_english.start_block != used_blocks[0] or check_english.alloc_blocks != required:
        raise RuntimeError("Pinnacle adresářový záznam ukazuje na nesprávnou alokaci")

    donor_check = check.entry_by_path(DONOR_PATH)
    if donor_check.alloc_blocks != len(remaining_donor):
        raise RuntimeError("Španělský donor Pinnacle nebyl správně uvolněn")

    with final.open("rb") as fp:
        for i, block in enumerate(used_blocks):
            fp.seek(stfs.hash_record_offset(check, block) + 20)
            status = fp.read(1)[0]
            nxt = int.from_bytes(fp.read(3), "big")
            expected_next = used_blocks[i + 1] if i + 1 < len(used_blocks) else 0xFFFFFF
            if status != 0x80 or nxt != expected_next:
                raise RuntimeError(
                    f"Neplatný Pinnacle chain record bloku {block}: {status:02X}/{nxt:06X}"
                )

    output_hash = sha256_file(final)
    report = {
        "build": "Mass Effect 1 Xbox 360 – Pinnacle Station Czech v1 reproducible patcher",
        "runtime_status": "PENDING XBOX 360 CONTENT TEST",
        "inputs": {
            "original_dlc": {
                "path": str(original_dlc),
                "size": original_dlc.stat().st_size,
                "sha256": input_hash,
                "content_id": src_stfs.content_id.hex().upper(),
            },
            "translation_map": {
                "path": str(translations_path),
                "sha256": translation_hash,
            },
        },
        "inner_package": inner_report,
        "output": {
            "path": str(final),
            "filename_content_id": content_id,
            "size": final.stat().st_size,
            "sha256": output_hash,
            "tested_reference_content_id": EXPECTED_OUTPUT_CONTENT_ID,
            "tested_reference_sha256": EXPECTED_OUTPUT_SHA256,
            "tested_reference_size": EXPECTED_OUTPUT_SIZE,
            "exact_match_to_reference": (
                content_id == EXPECTED_OUTPUT_CONTENT_ID
                and output_hash == EXPECTED_OUTPUT_SHA256
                and final.stat().st_size == EXPECTED_OUTPUT_SIZE
            ),
        },
        "allocation": {
            "english_path": ENGLISH_PATH,
            "donor_path": DONOR_PATH,
            "required_blocks": required,
            "allocation_start": donor.start_block,
            "allocation_last": donor.start_block + required - 1,
            "donor_original_blocks": donor.alloc_blocks,
            "language_impact": "One Spanish-only scoreboard package is removed; INT/Czech is supported.",
        },
        "checks": [
            "1412 active entries translated in both gender tables",
            "1077 unique source strings covered",
            "uncompressed UE3 package identity preserved",
            "both rebuilt TLKs decoded back to expected Czech maps",
            "STFS L0/L1/L2 hashes and Content ID verified",
            "patched extraction equals generated inner package",
        ],
    }
    report_path = output_dir / "validation_pinnacle.json"
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    (output_dir / "DLC_Vegas_GlobalTlk_CZ.xxx").write_bytes(inner)
    return final, report


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Vytvoří český Pinnacle Station STFS balíček z originálu."
    )
    parser.add_argument("original_dlc", type=Path)
    parser.add_argument("--output-dir", type=Path, default=Path("output_pinnacle"))
    parser.add_argument("--translations", type=Path, default=DEFAULT_TRANSLATIONS)
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--strict-tested-hash", action="store_true")
    args = parser.parse_args()

    try:
        final, report = patch_dlc(
            args.original_dlc.resolve(),
            args.translations.resolve(),
            args.output_dir.resolve(),
            force=args.force,
        )
        if args.strict_tested_hash and not report["output"]["exact_match_to_reference"]:
            raise RuntimeError("Pinnacle výstup se neshoduje s referenčním buildem")
    except Exception as exc:
        print(f"CHYBA: {exc}", file=sys.stderr)
        return 1

    print(f"Hotovo: {final}")
    print(f"SHA-256: {report['output']['sha256']}")
    print(
        "Shoda s referencí: "
        + ("ANO" if report["output"]["exact_match_to_reference"] else "NE")
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
