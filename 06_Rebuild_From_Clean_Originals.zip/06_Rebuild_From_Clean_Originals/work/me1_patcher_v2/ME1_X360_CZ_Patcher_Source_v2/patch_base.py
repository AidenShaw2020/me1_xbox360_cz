#!/usr/bin/env python3
"""Rebuild the verified Czech GlobalTlk.xxx v6 from original Xbox files."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import struct
import sys

from me1lib import lzo_ue3 as lzo
from me1lib import ue3_tlk as tlk

ROOT = Path(__file__).resolve().parent
DEFAULT_SOURCE_UPK = ROOT / "assets" / "GlobalTlk_CS.upk"
DEFAULT_XBOX_ONLY = ROOT / "assets" / "base_xbox_only_translation_cs.json"

EXPECTED_ORIGINAL_SHA256 = "e85d70488852267f49653dc8c364b6bc9192fe407e37de493921abfb3e1bdf1f"
EXPECTED_SOURCE_UPK_SHA256 = "5d9afea8da2a3f149f5d8dbfdac1317255a01f41f4a73f858216d5c7306b9648"
EXPECTED_XBOX_ONLY_SHA256 = "dcae93a637f0a12dfa545075e589550746274012dd4fa5f76394c11564e05384"
EXPECTED_TESTED_OUTPUT_SHA256 = "47363c769e9b3ea261043e2cd9b138e1f52a74510b468ceec6a8a132cdb60604"
EXPECTED_TESTED_OUTPUT_SIZE = 2185651


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while chunk := f.read(1024 * 1024):
            h.update(chunk)
    return h.hexdigest()


def require_hash(path: Path, expected: str, label: str, force: bool) -> str:
    found = sha256_file(path)
    if found != expected and not force:
        raise ValueError(
            f"{label} má nepodporovaný SHA-256.\nNalezeno: {found}\nOčekáváno: {expected}\n"
            "Použij --force pouze po nezávislém ověření vstupu."
        )
    return found


def patch_export_size_offset(
    logical: bytearray, export: tlk.ExportHeader, new_size: int, new_offset: int
) -> None:
    struct.pack_into(">ii", logical, export.start + 32, new_size, new_offset)


def build_base(
    original_path: Path,
    source_upk_path: Path,
    xbox_only_path: Path,
    *,
    force: bool = False,
) -> tuple[bytes, dict]:
    original_hash = require_hash(
        original_path, EXPECTED_ORIGINAL_SHA256, "Originální GlobalTlk.xxx", force
    )
    source_hash = require_hash(
        source_upk_path, EXPECTED_SOURCE_UPK_SHA256, "GlobalTlk_CS.upk", force
    )
    xbox_only_hash = require_hash(
        xbox_only_path, EXPECTED_XBOX_ONLY_SHA256, "Xbox-only překladový slovník", force
    )

    source_pkg = original_path.read_bytes()
    original_logical, source_records, source_blocks, _ = lzo.decompress_package(source_pkg)
    tables = tlk.parse_package_tables(original_logical, ">")
    exports = tables["exports"]
    names = tables["names"]
    expected_exports = [
        "GlobalTlk_tlk",
        "GlobalTlk_tlk_M",
        "SeekFreeSaver",
        "SeekFreeShaderCache",
    ]
    actual_exports = [names[e.name_index] for e in exports]
    if actual_exports != expected_exports:
        raise RuntimeError(f"Nečekané exporty základní hry: {actual_exports}")

    source_upk = source_upk_path.read_bytes()
    source_tables = tlk.parse_package_tables(source_upk, "<")
    source_exports = source_tables["exports"]
    source_names = source_tables["names"]
    if [source_names[e.name_index] for e in source_exports] != [
        "GlobalTlk_tlk",
        "GlobalTlk_tlk_M",
    ]:
        raise RuntimeError("Nečekané exporty v českém PC zdroji")

    original_parsed = []
    czech_parsed = []
    for i in range(2):
        oe = exports[i]
        original_parsed.append(
            tlk.parse_tlk_export(
                original_logical[oe.data_offset : oe.data_offset + oe.data_size], ">"
            )
        )
        se = source_exports[i]
        czech_parsed.append(
            tlk.parse_tlk_export(
                source_upk[se.data_offset : se.data_offset + se.data_size], "<"
            )
        )

    xbox_only = json.loads(xbox_only_path.read_text(encoding="utf-8"))
    if not isinstance(xbox_only, dict):
        raise RuntimeError("Xbox-only překladový zdroj není JSON objekt")

    merged_entries: list[list[tlk.TlkEntry]] = []
    coverage = []
    for i in range(2):
        merged, cov = tlk.merge_base_translation(
            original_parsed[i][1], czech_parsed[i][1], xbox_only
        )
        if cov["retained_english"] != 0:
            raise RuntimeError(
                f"Tabulka {i}: {cov['retained_english']} aktivních textů zůstalo anglicky"
            )
        merged_entries.append(merged)
        coverage.append(cov)

    new_tlks = [
        tlk.build_tlk_export(original_parsed[0][0], merged_entries[0]),
        tlk.build_tlk_export(original_parsed[1][0], merged_entries[1]),
    ]

    # Runtime-verified v6 strategy: preserve the entire original logical package,
    # append both larger TLKs, and redirect only DataSize/DataOffset.
    patched = bytearray(original_logical)
    new_offsets: list[int] = []
    for blob in new_tlks:
        new_offsets.append(len(patched))
        patched += blob
    for i in range(2):
        patch_export_size_offset(patched, exports[i], len(new_tlks[i]), new_offsets[i])

    ranges = [(uoff, usize) for uoff, usize, _coff, _csize in source_records]
    ranges.extend((new_offsets[i], len(new_tlks[i])) for i in range(2))
    struct.pack_into(">i", patched, 121, len(ranges))
    intended_logical = bytes(patched)

    _, _records, package_source, _ = lzo.read_chunk_records(source_pkg)
    output_pkg, built_chunks = lzo.build_multichunk_package(
        source_pkg, intended_logical, ranges, package_source
    )

    rebuilt_logical, rebuilt_records, rebuilt_blocks, _ = lzo.decompress_package(output_pkg)
    if rebuilt_logical != intended_logical:
        raise RuntimeError("LZO round-trip logického balíčku nesouhlasí")
    rebuilt_tables = tlk.parse_package_tables(rebuilt_logical, ">")
    rebuilt_exports = rebuilt_tables["exports"]
    if rebuilt_tables["names"] != tables["names"]:
        raise RuntimeError("Tabulka názvů se změnila")
    if rebuilt_tables["import_count"] != tables["import_count"]:
        raise RuntimeError("Počet importů se změnil")
    if [rebuilt_tables["names"][e.name_index] for e in rebuilt_exports] != expected_exports:
        raise RuntimeError("Identita exportů se změnila")

    tlk_validation = []
    for i in range(2):
        exp = rebuilt_exports[i]
        if exp.data_offset != new_offsets[i] or exp.data_size != len(new_tlks[i]):
            raise RuntimeError(f"Hlavička TLK exportu {i} nesouhlasí")
        prefix, decoded_entries, stats = tlk.parse_tlk_export(
            rebuilt_logical[exp.data_offset : exp.data_offset + exp.data_size], ">"
        )
        if prefix != original_parsed[i][0]:
            raise RuntimeError(f"Property prefix TLK exportu {i} se změnil")
        if tlk.active_map(decoded_entries) != tlk.active_map(merged_entries[i]):
            raise RuntimeError(f"Dekódovaná česká mapa TLK exportu {i} nesouhlasí")
        stats.update(
            {
                "export_name": expected_exports[i],
                "size": exp.data_size,
                "offset": exp.data_offset,
            }
        )
        tlk_validation.append(stats)

    helpers = []
    for i in (2, 3):
        old_exp = exports[i]
        new_exp = rebuilt_exports[i]
        old_blob = original_logical[
            old_exp.data_offset : old_exp.data_offset + old_exp.data_size
        ]
        new_blob = rebuilt_logical[
            new_exp.data_offset : new_exp.data_offset + new_exp.data_size
        ]
        if new_exp.data_offset != old_exp.data_offset or new_exp.data_size != old_exp.data_size:
            raise RuntimeError(f"Offset/velikost helper exportu {expected_exports[i]} se změnily")
        if new_blob != old_blob:
            raise RuntimeError(f"Helper export {expected_exports[i]} se obsahově změnil")
        helpers.append(
            {
                "name": expected_exports[i],
                "offset": new_exp.data_offset,
                "size": new_exp.data_size,
                "sha256": sha256_bytes(new_blob),
                "byte_identical_to_original": True,
            }
        )

    output_hash = sha256_bytes(output_pkg)
    report = {
        "build": "ME1 Xbox 360 Czech relocated base TLK v6 – reproducible patcher",
        "runtime_status": "PASS on real Xbox 360",
        "inputs": {
            "original_globaltlk": {
                "path": str(original_path),
                "size": original_path.stat().st_size,
                "sha256": original_hash,
            },
            "czech_pc_source": {
                "path": str(source_upk_path),
                "size": source_upk_path.stat().st_size,
                "sha256": source_hash,
            },
            "xbox_only_map": {
                "path": str(xbox_only_path),
                "sha256": xbox_only_hash,
            },
        },
        "output": {
            "size": len(output_pkg),
            "sha256": output_hash,
            "tested_reference_size": EXPECTED_TESTED_OUTPUT_SIZE,
            "tested_reference_sha256": EXPECTED_TESTED_OUTPUT_SHA256,
            "exact_match_to_tested_reference": (
                len(output_pkg) == EXPECTED_TESTED_OUTPUT_SIZE
                and output_hash == EXPECTED_TESTED_OUTPUT_SHA256
            ),
            "logical_size": len(rebuilt_logical),
            "logical_sha256": sha256_bytes(rebuilt_logical),
        },
        "package_structure": {
            "full_header_size": rebuilt_tables["full_header_size"],
            "name_count": rebuilt_tables["name_count"],
            "import_count": rebuilt_tables["import_count"],
            "export_count": rebuilt_tables["export_count"],
            "chunk_records": rebuilt_records,
            "blocks": rebuilt_blocks,
        },
        "coverage": coverage,
        "tlk_validation": tlk_validation,
        "helpers": helpers,
        "checks": [
            "all active base-game strings translated",
            "full LZO decompression/recompression round trip",
            "name/import/export identity preserved",
            "SeekFreeSaver and SeekFreeShaderCache byte-identical at original offsets",
            "both rebuilt TLKs decoded back to the expected Czech maps",
        ],
    }
    return output_pkg, report


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Vytvoří ověřený český GlobalTlk.xxx v6 z originálního Xbox souboru."
    )
    parser.add_argument("original", type=Path, help="Originální Layer0/MEInit/GlobalTlk.xxx")
    parser.add_argument(
        "--output", type=Path, default=Path("output_base/GlobalTlk.xxx")
    )
    parser.add_argument("--source-upk", type=Path, default=DEFAULT_SOURCE_UPK)
    parser.add_argument("--xbox-only-map", type=Path, default=DEFAULT_XBOX_ONLY)
    parser.add_argument("--force", action="store_true", help="Povolit neznámé vstupní hashe")
    parser.add_argument(
        "--strict-tested-hash",
        action="store_true",
        help="Selhat, pokud výstup není bajtově shodný s verzí testovanou na Xboxu",
    )
    args = parser.parse_args()

    try:
        output, report = build_base(
            args.original.resolve(),
            args.source_upk.resolve(),
            args.xbox_only_map.resolve(),
            force=args.force,
        )
        if args.strict_tested_hash and not report["output"]["exact_match_to_tested_reference"]:
            raise RuntimeError("Výstup se neshoduje s referenční verzí testovanou na Xboxu")
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_bytes(output)
        report_path = args.output.with_name(args.output.name + ".validation.json")
        report_path.write_text(
            json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
        )
    except Exception as exc:
        print(f"CHYBA: {exc}", file=sys.stderr)
        return 1

    print(f"Hotovo: {args.output.resolve()}")
    print(f"SHA-256: {report['output']['sha256']}")
    print(
        "Shoda s verzí testovanou na Xboxu: "
        + ("ANO" if report["output"]["exact_match_to_tested_reference"] else "NE")
    )
    print(f"Validace: {report_path.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
