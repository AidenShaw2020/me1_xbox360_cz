#!/usr/bin/env python3
"""Build the complete ME1 Xbox 360 Czech set from original files."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import patch_base
import patch_btds
import patch_pinnacle


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Vytvoří českou základní hru, Bring Down the Sky a Pinnacle Station."
    )
    parser.add_argument("original_globaltlk", type=Path)
    parser.add_argument("original_btds", type=Path)
    parser.add_argument("original_pinnacle", type=Path)
    parser.add_argument("--output-dir", type=Path, default=Path("output_all"))
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--strict-tested-hash", action="store_true")
    args = parser.parse_args()

    out = args.output_dir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    try:
        base_bytes, base_report = patch_base.build_base(
            args.original_globaltlk.resolve(),
            patch_base.DEFAULT_SOURCE_UPK.resolve(),
            patch_base.DEFAULT_XBOX_ONLY.resolve(),
            force=args.force,
        )
        base_dir = out / "base_game"
        base_dir.mkdir(parents=True, exist_ok=True)
        base_file = base_dir / "GlobalTlk.xxx"
        base_file.write_bytes(base_bytes)
        (base_dir / "validation_base.json").write_text(
            json.dumps(base_report, ensure_ascii=False, indent=2), encoding="utf-8"
        )

        btds_file, btds_report = patch_btds.patch_dlc(
            args.original_btds.resolve(),
            patch_btds.DEFAULT_SOURCE_UPK.resolve(),
            out / "btds",
            force=args.force,
        )
        pinnacle_file, pinnacle_report = patch_pinnacle.patch_dlc(
            args.original_pinnacle.resolve(),
            patch_pinnacle.DEFAULT_TRANSLATIONS.resolve(),
            out / "pinnacle",
            force=args.force,
        )

        exact = (
            base_report["output"]["exact_match_to_tested_reference"]
            and btds_report["output"]["exact_match_to_reference"]
            and pinnacle_report["output"]["exact_match_to_reference"]
        )
        if args.strict_tested_hash and not exact:
            raise RuntimeError("Nejméně jeden výstup se neshoduje s referenčním buildem")

        manifest = {
            "project": "Mass Effect 1 Xbox 360 Czech localization patcher set",
            "base_game": {
                "file": str(base_file),
                "sha256": base_report["output"]["sha256"],
                "runtime_status": base_report["runtime_status"],
            },
            "bring_down_the_sky": {
                "file": str(btds_file),
                "sha256": btds_report["output"]["sha256"],
                "runtime_status": btds_report["runtime_status"],
            },
            "pinnacle_station": {
                "file": str(pinnacle_file),
                "sha256": pinnacle_report["output"]["sha256"],
                "runtime_status": pinnacle_report["runtime_status"],
            },
            "all_exact_reference_matches": exact,
        }
        (out / "manifest.json").write_text(
            json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
        )
    except Exception as exc:
        print(f"CHYBA: {exc}", file=sys.stderr)
        return 1

    print(f"Hotovo: {out}")
    print(f"Základní hra: {base_file}")
    print(f"Bring Down the Sky: {btds_file}")
    print(f"Pinnacle Station: {pinnacle_file}")
    print("Všechny hashe odpovídají referenci: " + ("ANO" if exact else "NE"))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
