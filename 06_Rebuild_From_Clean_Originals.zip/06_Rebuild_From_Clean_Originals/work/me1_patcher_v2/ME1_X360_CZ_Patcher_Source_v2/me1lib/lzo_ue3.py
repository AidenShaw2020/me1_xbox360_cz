#!/usr/bin/env python3
"""UE3 Xenon LZO package support used by Mass Effect 1 Xbox 360.

The game uses big-endian UE3 package headers, compression type 2 and LZO1X
blocks of at most 0x20000 bytes. This module intentionally implements only the
layout required by the verified ME1 localization files.
"""
from __future__ import annotations

import ctypes
import ctypes.util
import os
import struct
from pathlib import Path

MAGIC = 0x9E2A83C1
BLOCK_SIZE = 0x20000


def _load_lzo() -> ctypes.CDLL:
    candidates: list[str] = []
    explicit = os.environ.get("ME1_LZO_LIBRARY")
    if explicit:
        candidates.append(explicit)
    found = ctypes.util.find_library("lzo2")
    if found:
        candidates.append(found)
    candidates.extend([
        "liblzo2.so.2",
        "liblzo2.so",
        "liblzo2.dylib",
        "lzo2.dll",
        "liblzo2-2.dll",
    ])
    errors: list[str] = []
    seen: set[str] = set()
    for candidate in candidates:
        if not candidate or candidate in seen:
            continue
        seen.add(candidate)
        try:
            return ctypes.CDLL(candidate)
        except OSError as exc:
            errors.append(f"{candidate}: {exc}")
    raise RuntimeError(
        "Knihovna LZO2 nebyla nalezena. Na Debianu/Ubuntu nainstaluj "
        "balíček liblzo2-2. Ve Windows použij WSL nebo nastav proměnnou "
        "ME1_LZO_LIBRARY na cestu k lzo2.dll.\n" + "\n".join(errors)
    )


_lib = _load_lzo()
_lzo_dec = _lib.lzo1x_decompress_safe
_lzo_dec.argtypes = [
    ctypes.c_void_p,
    ctypes.c_size_t,
    ctypes.c_void_p,
    ctypes.POINTER(ctypes.c_size_t),
    ctypes.c_void_p,
]
_lzo_dec.restype = ctypes.c_int
_compressor_name = (
    "lzo1x_999_compress"
    if os.environ.get("ME1_LZO_LEVEL") == "999" and hasattr(_lib, "lzo1x_999_compress")
    else "lzo1x_1_compress"
)
_lzo_comp = getattr(_lib, _compressor_name)
_lzo_comp.argtypes = [
    ctypes.c_void_p,
    ctypes.c_size_t,
    ctypes.c_void_p,
    ctypes.POINTER(ctypes.c_size_t),
    ctypes.c_void_p,
]
_lzo_comp.restype = ctypes.c_int


def lzo_decompress(data: bytes, expected_size: int) -> bytes:
    src = ctypes.create_string_buffer(data)
    dst = ctypes.create_string_buffer(expected_size)
    out_len = ctypes.c_size_t(expected_size)
    rc = _lzo_dec(src, len(data), dst, ctypes.byref(out_len), None)
    if rc != 0 or out_len.value != expected_size:
        raise RuntimeError(
            f"LZO dekomprese selhala: rc={rc}, výstup={out_len.value}, "
            f"očekáváno={expected_size}"
        )
    return dst.raw[: out_len.value]


def lzo_compress(data: bytes) -> bytes:
    # Documented LZO worst-case bound.
    cap = len(data) + len(data) // 16 + 64 + 3
    src = ctypes.create_string_buffer(data)
    dst = ctypes.create_string_buffer(cap)
    out_len = ctypes.c_size_t(cap)
    # Safely larger than LZO1X_1_MEM_COMPRESS on supported builds.
    work = ctypes.create_string_buffer(1024 * 1024)
    rc = _lzo_comp(src, len(data), dst, ctypes.byref(out_len), work)
    if rc != 0:
        raise RuntimeError(f"LZO komprese selhala: rc={rc}")
    result = dst.raw[: out_len.value]
    if lzo_decompress(result, len(data)) != data:
        raise RuntimeError("LZO round-trip kontrola selhala")
    return result


def read_chunk_records(pkg: bytes):
    if len(pkg) < 129:
        raise ValueError("UE3 balíček je příliš krátký")
    compression_type, count = struct.unpack_from(">ii", pkg, 117)
    if compression_type != 2:
        raise ValueError(
            f"Očekávána UE3 komprese typu 2/LZO, nalezen typ {compression_type}"
        )
    records: list[tuple[int, int, int, int]] = []
    pos = 125
    for _ in range(count):
        records.append(struct.unpack_from(">iiii", pkg, pos))
        pos += 16
    package_source = pkg[pos : pos + 4]
    if len(package_source) != 4:
        raise ValueError("Chybí PackageSource")
    return compression_type, records, package_source, pos + 4


def decompress_package(pkg: bytes):
    _, records, _, physical_header_size = read_chunk_records(pkg)
    if not records:
        raise ValueError("Komprimovaný balíček nemá žádné chunky")
    logical_size = max(uoff + usize for uoff, usize, _, _ in records)
    logical = bytearray(logical_size)
    first_uoff = min(r[0] for r in records)
    logical[:first_uoff] = pkg[:first_uoff]
    block_meta: list[list[dict[str, int]]] = []
    for ci, (uoff, usize, coff, csize) in enumerate(records):
        chunk = pkg[coff : coff + csize]
        if len(chunk) != csize:
            raise ValueError(f"Chunk {ci} je zkrácen")
        m1, m2, payload_csize, total_usize = struct.unpack_from(">IIII", chunk, 0)
        if (m1, m2) != (MAGIC, MAGIC) or total_usize != usize:
            raise ValueError(f"Neplatná hlavička chunku {ci}")
        block_count = (usize + BLOCK_SIZE - 1) // BLOCK_SIZE
        table_end = 16 + block_count * 8
        pos = table_end
        out = bytearray()
        metas: list[dict[str, int]] = []
        for bi in range(block_count):
            bcs, bus = struct.unpack_from(">II", chunk, 16 + bi * 8)
            comp = chunk[pos : pos + bcs]
            if len(comp) != bcs:
                raise ValueError(f"LZO blok {ci}/{bi} je zkrácen")
            pos += bcs
            out += lzo_decompress(comp, bus)
            metas.append({"compressed_size": bcs, "uncompressed_size": bus})
        if pos != len(chunk):
            raise ValueError(f"Délka chunku {ci} nesouhlasí: {pos} != {len(chunk)}")
        if payload_csize != len(chunk) - table_end:
            raise ValueError(f"Velikost payloadu chunku {ci} nesouhlasí")
        if len(out) != usize:
            raise ValueError(f"Dekomprimovaná velikost chunku {ci} nesouhlasí")
        logical[uoff : uoff + usize] = out
        block_meta.append(metas)
    return bytes(logical), records, block_meta, physical_header_size


def build_chunk(raw: bytes):
    blocks: list[tuple[int, int]] = []
    payload = bytearray()
    table = bytearray()
    for pos in range(0, len(raw), BLOCK_SIZE):
        plain = raw[pos : pos + BLOCK_SIZE]
        comp = lzo_compress(plain)
        blocks.append((len(comp), len(plain)))
        table += struct.pack(">II", len(comp), len(plain))
        payload += comp
    header = struct.pack(">IIII", MAGIC, MAGIC, len(payload), len(raw))
    return header + table + payload, blocks


def build_multichunk_package(
    source_pkg: bytes,
    logical: bytes,
    ranges: list[tuple[int, int]],
    package_source: bytes | None = None,
):
    """Build a compressed package from explicit uncompressed ranges.

    Bytes before the first range remain in the physical header. The caller must
    already have updated the chunk count at logical/header offset 121.
    """
    if package_source is None:
        _, source_records, package_source, _ = read_chunk_records(source_pkg)
    physical_header_size = 125 + 16 * len(ranges) + 4
    header = bytearray(source_pkg[:125])
    struct.pack_into(">i", header, 121, len(ranges))

    chunks: list[dict[str, object]] = []
    compressed_offset = physical_header_size
    for uncompressed_offset, uncompressed_size in ranges:
        raw = logical[uncompressed_offset : uncompressed_offset + uncompressed_size]
        if len(raw) != uncompressed_size:
            raise RuntimeError(
                f"Rozsah {uncompressed_offset}+{uncompressed_size} přesahuje logická data"
            )
        chunk, blocks = build_chunk(raw)
        chunks.append(
            {
                "uoff": uncompressed_offset,
                "usize": uncompressed_size,
                "coff": compressed_offset,
                "csize": len(chunk),
                "chunk": chunk,
                "blocks": blocks,
            }
        )
        compressed_offset += len(chunk)

    for chunk in chunks:
        header += struct.pack(
            ">iiii",
            int(chunk["uoff"]),
            int(chunk["usize"]),
            int(chunk["coff"]),
            int(chunk["csize"]),
        )
    header += package_source
    if len(header) != physical_header_size:
        raise RuntimeError(
            f"Nečekaná fyzická hlavička: {len(header)} != {physical_header_size}"
        )
    return bytes(header) + b"".join(bytes(c["chunk"]) for c in chunks), chunks
