#!/usr/bin/env python3
"""Minimal read-only STFS parser plus targeted hash-tree rewriting.

Only the read-only LIVE/PIRS/CON layout used by the two official ME1 Xbox 360
DLC packages is supported. The patchers never modify their input in place.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import shutil
import struct
from pathlib import Path
from typing import BinaryIO, Iterable

SECTOR = 0x1000
ENT_SIZE = 0x40
ENT_PER_BLOCK = SECTOR // ENT_SIZE
DATA_PER_L0 = 0xAA
DATA_PER_L1 = 0x70E4


def u24le(b: bytes) -> int:
    return b[0] | (b[1] << 8) | (b[2] << 16)


def p24le(value: int) -> bytes:
    return bytes((value & 0xFF, (value >> 8) & 0xFF, (value >> 16) & 0xFF))


def p24be(value: int) -> bytes:
    return bytes(((value >> 16) & 0xFF, (value >> 8) & 0xFF, value & 0xFF))


@dataclass
class STFSEntry:
    id: int
    name: str
    path: str
    is_dir: bool
    flags: int
    valid_blocks: int
    alloc_blocks: int
    start_block: int
    parent: int
    size: int
    dir_block: int
    dir_pos: int


class STFS:
    def __init__(self, path: Path | str):
        self.path = Path(path)
        with self.path.open("rb") as f:
            magic = f.read(4)
            if magic not in (b"LIVE", b"PIRS", b"CON "):
                raise ValueError(f"{self.path.name}: soubor není STFS")
            self.magic = magic.decode("ascii", errors="replace")
            f.seek(0x340)
            self.header_size = struct.unpack(">I", f.read(4))[0]
            self.rounded_header = (self.header_size + SECTOR - 1) // SECTOR * SECTOR
            self.meta_off = 0x344
            self.vol_off = self.meta_off + 4 + 4 + 8 + 24 + 5 + 8
            f.seek(self.vol_off)
            vd = f.read(0x24)
            f.seek(0x344)
            self.content_type = struct.unpack(">I", f.read(4))[0]
            f.seek(0x354)
            self.media_id = struct.unpack(">I", f.read(4))[0]
            f.seek(0x360)
            self.title_id = struct.unpack(">I", f.read(4))[0]
            f.seek(0x32C)
            self.content_id = f.read(20)
        if len(vd) != 0x24 or vd[0] != 0x24:
            raise ValueError(f"{self.path.name}: neplatný STFS volume descriptor")
        self.flags = vd[2]
        if not (self.flags & 1):
            raise ValueError(
                f"{self.path.name}: nepodporované STFS rozložení (není read-only)"
            )
        self.dir_blocks = struct.unpack("<H", vd[3:5])[0]
        self.dir_first = u24le(vd[5:8])
        self.root_hash = vd[8:28]
        self.total_blocks = struct.unpack(">I", vd[28:32])[0]
        self.entries = self._read_entries()

    def backing_offset(self, backing_block: int) -> int:
        return self.rounded_header + backing_block * SECTOR

    def data_backing(self, block_num: int) -> int:
        block = block_num
        base = DATA_PER_L0
        for _ in range(3):
            block += (block_num + base) // base
            if block_num < base:
                break
            base *= DATA_PER_L0
        return block

    def data_offset(self, block_num: int) -> int:
        return self.backing_offset(self.data_backing(block_num))

    def hash_backing(self, block_num: int, level: int) -> int:
        if level == 0:
            num = (block_num // DATA_PER_L0) * 0xAB
            if block_num // DATA_PER_L0 == 0:
                return num
            num += (block_num // DATA_PER_L1) + 1
            if block_num // DATA_PER_L1 == 0:
                return num
            return num + 1
        if level == 1:
            num = (block_num // DATA_PER_L1) * 0x718F
            if block_num // DATA_PER_L1 == 0:
                return num + 0xAB
            return num + 1
        if level == 2:
            return 0x718F
        raise ValueError(level)

    def hash_offset(self, block_num: int, level: int) -> int:
        return self.backing_offset(self.hash_backing(block_num, level))

    @staticmethod
    def hash_record(block_num: int, level: int) -> int:
        record = block_num
        if level == 1:
            record //= DATA_PER_L0
        elif level == 2:
            record //= DATA_PER_L1
        return record % DATA_PER_L0

    def _read_entries(self) -> list[STFSEntry]:
        entries: list[STFSEntry] = []
        paths: dict[int, str] = {0xFFFF: ""}
        with self.path.open("rb") as f:
            for db in range(self.dir_first, self.dir_first + self.dir_blocks):
                f.seek(self.data_offset(db))
                table = f.read(SECTOR)
                if len(table) != SECTOR:
                    raise IOError(f"{self.path.name}: zkrácený adresářový blok")
                for j in range(ENT_PER_BLOCK):
                    idx = len(entries)
                    cur = table[j * ENT_SIZE : (j + 1) * ENT_SIZE]
                    name_len = cur[40] & 0x3F
                    if name_len == 0:
                        return entries
                    is_dir = bool(cur[40] & 0x80)
                    name = cur[:name_len].decode("ascii", errors="strict")
                    parent = struct.unpack(">H", cur[50:52])[0]
                    full = paths.get(parent, "") + name + ("/" if is_dir else "")
                    entry = STFSEntry(
                        id=idx,
                        name=name,
                        path=full,
                        is_dir=is_dir,
                        flags=cur[40],
                        valid_blocks=u24le(cur[41:44]),
                        alloc_blocks=u24le(cur[44:47]),
                        start_block=u24le(cur[47:50]),
                        parent=parent,
                        size=struct.unpack(">I", cur[52:56])[0],
                        dir_block=db,
                        dir_pos=j * ENT_SIZE,
                    )
                    entries.append(entry)
                    if is_dir:
                        paths[idx] = full
        return entries

    def entry_by_path(self, path: str) -> STFSEntry:
        wanted = path.replace("\\", "/").lower()
        for entry in self.entries:
            if entry.path.lower() == wanted:
                return entry
        raise KeyError(path)

    def read_file(self, entry: STFSEntry) -> bytes:
        """Read a file whose allocation is contiguous in the source package."""
        data = bytearray()
        remaining = entry.size
        with self.path.open("rb") as f:
            for i in range(entry.alloc_blocks):
                if remaining <= 0:
                    break
                f.seek(self.data_offset(entry.start_block + i))
                amount = min(SECTOR, remaining)
                chunk = f.read(amount)
                if len(chunk) != amount:
                    raise IOError(f"{self.path.name}: zkrácená data {entry.path}")
                data.extend(chunk)
                remaining -= len(chunk)
        if remaining != 0:
            raise IOError(f"{self.path.name}: neúplný soubor {entry.path}")
        return bytes(data)


def read_block(fp: BinaryIO, off: int) -> bytes:
    fp.seek(off)
    block = fp.read(SECTOR)
    if len(block) != SECTOR:
        raise IOError(f"Zkrácený STFS blok na 0x{off:X}")
    return block


def hash_record_offset(stfs: STFS, block_num: int) -> int:
    return stfs.hash_offset(block_num, 0) + stfs.hash_record(block_num, 0) * 0x18


def patch_dir_entry(
    fp: BinaryIO,
    stfs: STFS,
    entry: STFSEntry,
    *,
    valid_blocks: int | None = None,
    alloc_blocks: int | None = None,
    start_block: int | None = None,
    size: int | None = None,
    contiguous: bool | None = None,
) -> None:
    off = stfs.data_offset(entry.dir_block) + entry.dir_pos
    fp.seek(off)
    cur = bytearray(fp.read(ENT_SIZE))
    if len(cur) != ENT_SIZE:
        raise IOError("Zkrácený STFS adresářový záznam")
    if valid_blocks is not None:
        cur[41:44] = p24le(valid_blocks)
    if alloc_blocks is not None:
        cur[44:47] = p24le(alloc_blocks)
    if start_block is not None:
        cur[47:50] = p24le(start_block)
    if size is not None:
        cur[52:56] = struct.pack(">I", size)
    if contiguous is not None:
        if contiguous:
            cur[40] |= 0x40
        else:
            cur[40] &= ~0x40
    fp.seek(off)
    fp.write(cur)


def set_chain_record(fp: BinaryIO, stfs: STFS, block_num: int, next_block: int) -> None:
    fp.seek(hash_record_offset(stfs, block_num) + 20)
    fp.write(bytes([0x80]) + p24be(next_block))


def patch_display_metadata(
    fp: BinaryIO, display_name: str, description: str
) -> None:
    """Set all nine STFS locale slots to the supplied Czech DLC metadata."""
    for base, text in ((0x411, display_name), (0xD11, description)):
        encoded = (text + "\0").encode("utf-16be")
        if len(encoded) > 0x100:
            raise ValueError(f"STFS metadata text is too long: {text}")
        slot = encoded.ljust(0x100, b"\0")
        for locale in range(9):
            fp.seek(base + locale * 0x100)
            fp.write(slot)


def write_chain(fp: BinaryIO, stfs: STFS, blocks: list[int], data: bytes) -> None:
    if len(data) > len(blocks) * SECTOR:
        raise RuntimeError(
            f"Payload se nevejde do řetězce: {len(data)} > {len(blocks) * SECTOR}"
        )
    for i, block in enumerate(blocks):
        piece = data[i * SECTOR : (i + 1) * SECTOR].ljust(SECTOR, b"\0")
        fp.seek(stfs.data_offset(block))
        fp.write(piece)
        set_chain_record(
            fp,
            stfs,
            block,
            blocks[i + 1] if i + 1 < len(blocks) else 0xFFFFFF,
        )


def write_contiguous_payload(
    fp: BinaryIO, stfs: STFS, start_block: int, block_count: int, data: bytes
) -> None:
    blocks = list(range(start_block, start_block + block_count))
    write_chain(fp, stfs, blocks, data)


def read_chain(path: Path, stfs: STFS, entry: STFSEntry) -> tuple[bytes, list[int]]:
    remaining = entry.size
    out = bytearray()
    chain: list[int] = []
    block = entry.start_block
    with path.open("rb") as fp:
        for _ in range(entry.alloc_blocks):
            if block == 0xFFFFFF:
                break
            chain.append(block)
            fp.seek(stfs.data_offset(block))
            amount = min(SECTOR, remaining)
            chunk = fp.read(amount)
            if len(chunk) != amount:
                raise IOError("Zkrácený soubor v STFS řetězci")
            out += chunk
            remaining -= amount
            fp.seek(hash_record_offset(stfs, block) + 21)
            block = int.from_bytes(fp.read(3), "big")
            if remaining <= 0:
                break
    if remaining != 0:
        raise RuntimeError(f"STFS řetězec skončil o {remaining} bajtů dříve")
    return bytes(out), chain


def allocation_chain(path: Path, stfs: STFS, entry: STFSEntry) -> list[int]:
    """Return the complete allocation using the STFS contiguous flag."""
    if entry.alloc_blocks == 0:
        return []
    if entry.flags & 0x40:
        return list(range(entry.start_block, entry.start_block + entry.alloc_blocks))
    result = []
    block = entry.start_block
    with path.open("rb") as fp:
        for index in range(entry.alloc_blocks):
            if block == 0xFFFFFF:
                raise RuntimeError(f"STFS allocation ended early: {entry.path}")
            result.append(block)
            if index + 1 < entry.alloc_blocks:
                fp.seek(hash_record_offset(stfs, block) + 21)
                block = int.from_bytes(fp.read(3), "big")
    return result


def update_hash_entry(
    fp: BinaryIO, stfs: STFS, block_num: int, level: int, digest: bytes
) -> None:
    rec = stfs.hash_record(block_num, level)
    off = stfs.hash_offset(block_num, level) + rec * 0x18
    fp.seek(off)
    fp.write(digest)


def rehash(fp: BinaryIO, stfs: STFS, modified_data_blocks: Iterable[int]) -> bytes:
    l0_groups: set[int] = set()
    for n in sorted(set(modified_data_blocks)):
        digest = hashlib.sha1(read_block(fp, stfs.data_offset(n))).digest()
        update_hash_entry(fp, stfs, n, 0, digest)
        l0_groups.add(n // DATA_PER_L0)

    l1_groups: set[int] = set()
    for group in sorted(l0_groups):
        representative = group * DATA_PER_L0
        digest = hashlib.sha1(
            read_block(fp, stfs.hash_offset(representative, 0))
        ).digest()
        update_hash_entry(fp, stfs, representative, 1, digest)
        l1_groups.add(representative // DATA_PER_L1)

    for group in sorted(l1_groups):
        representative = group * DATA_PER_L1
        digest = hashlib.sha1(
            read_block(fp, stfs.hash_offset(representative, 1))
        ).digest()
        update_hash_entry(fp, stfs, representative, 2, digest)

    root = hashlib.sha1(read_block(fp, stfs.hash_offset(0, 2))).digest()
    fp.seek(stfs.vol_off + 8)
    fp.write(root)

    fp.flush()
    fp.seek(0x344)
    metadata = fp.read(stfs.rounded_header - 0x344)
    content_id = hashlib.sha1(metadata).digest()
    fp.seek(0x32C)
    fp.write(content_id)
    fp.flush()
    return content_id


def verify_stfs(path: Path, modified_blocks: Iterable[int]) -> str:
    stfs = STFS(path)
    with path.open("rb") as f:
        root_calc = hashlib.sha1(read_block(f, stfs.hash_offset(0, 2))).digest()
        if root_calc != stfs.root_hash:
            raise RuntimeError(f"{path.name}: kontrola root hashe selhala")
        for n in sorted(set(modified_blocks)):
            digest = hashlib.sha1(read_block(f, stfs.data_offset(n))).digest()
            rec = stfs.hash_record(n, 0)
            f.seek(stfs.hash_offset(n, 0) + rec * 0x18)
            if digest != f.read(20):
                raise RuntimeError(f"{path.name}: datový hash bloku {n} nesouhlasí")
        f.seek(0x344)
        cid_calc = hashlib.sha1(f.read(stfs.rounded_header - 0x344)).digest()
        f.seek(0x32C)
        cid_stored = f.read(20)
        if cid_calc != cid_stored:
            raise RuntimeError(f"{path.name}: kontrola Content ID selhala")
    return cid_stored.hex().upper()


def copy_for_patch(source: Path, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
