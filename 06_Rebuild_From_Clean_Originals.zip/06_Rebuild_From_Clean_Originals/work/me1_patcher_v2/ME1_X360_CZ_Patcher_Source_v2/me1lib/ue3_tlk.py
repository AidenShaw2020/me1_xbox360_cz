#!/usr/bin/env python3
"""Minimal ME1 UE3 package-table and BioTlkFile reader/writer.

This is intentionally scoped to the exact ME1 Xbox 360/PC TLK packages used by
this project (package version 391/92 and 40-byte BioTlkFile property prefix).
"""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
import heapq
import struct


@dataclass
class ExportHeader:
    index: int
    start: int
    end: int
    values: tuple[int, int, int, int, int, int, int, int, int]
    component_count: int
    export_flags: int
    generation_count: int
    guid: bytes

    @property
    def name_index(self) -> int:
        return self.values[3]

    @property
    def data_size(self) -> int:
        return self.values[7]

    @property
    def data_offset(self) -> int:
        return self.values[8]


@dataclass
class TlkEntry:
    string_id: int
    flags: int
    index: int
    text: str | None = None


@dataclass
class HuffNode:
    char: str | None
    freq: int
    left: "HuffNode | None" = None
    right: "HuffNode | None" = None
    node_id: int = -1

    @property
    def leaf(self) -> bool:
        return self.char is not None


def read_fstring(data: bytes, offset: int, endian: str) -> tuple[str, int]:
    n = struct.unpack_from(endian + "i", data, offset)[0]
    offset += 4
    if n > 0:
        raw = data[offset : offset + n]
        return raw[:-1].decode("latin1"), offset + n
    if n < 0:
        count = -n
        raw = data[offset : offset + count * 2]
        enc = "utf-16le" if endian == "<" else "utf-16be"
        return raw[:-2].decode(enc), offset + count * 2
    return "", offset


def parse_package_tables(logical: bytes, endian: str = ">"):
    full_header_size = struct.unpack_from(endian + "i", logical, 8)[0]
    (
        name_count,
        name_offset,
        export_count,
        export_offset,
        import_count,
        import_offset,
    ) = struct.unpack_from(endian + "iiiiii", logical, 25)

    names: list[str] = []
    pos = name_offset
    for _ in range(name_count):
        name, pos = read_fstring(logical, pos, endian)
        names.append(name)
        pos += 8
    if pos != import_offset:
        raise ValueError(
            f"Tabulka názvů skončila na {pos}, očekáván import offset {import_offset}"
        )

    exports: list[ExportHeader] = []
    pos = export_offset
    for i in range(export_count):
        start = pos
        values = struct.unpack_from(endian + "iiiiiiQii", logical, pos)
        pos += 40
        component_count = struct.unpack_from(endian + "i", logical, pos)[0]
        pos += 4 + component_count * 12
        export_flags = struct.unpack_from(endian + "I", logical, pos)[0]
        pos += 4
        generation_count = struct.unpack_from(endian + "i", logical, pos)[0]
        pos += 4 + generation_count * 4
        guid = logical[pos : pos + 16]
        pos += 16
        exports.append(
            ExportHeader(
                i,
                start,
                pos,
                values,
                component_count,
                export_flags,
                generation_count,
                guid,
            )
        )
    if pos != full_header_size:
        raise ValueError(
            f"Tabulka exportů skončila na {pos}, očekáváno {full_header_size}"
        )

    return {
        "full_header_size": full_header_size,
        "name_count": name_count,
        "name_offset": name_offset,
        "export_count": export_count,
        "export_offset": export_offset,
        "import_count": import_count,
        "import_offset": import_offset,
        "names": names,
        "exports": exports,
    }


def decode_huffman_string(payload: bytes, nodes: list[tuple]) -> str:
    cur = 0
    chars: list[str] = []
    bit_pos = 0
    max_bits = len(payload) * 8
    while bit_pos < max_bits:
        node = nodes[cur]
        if node[0] == "leaf":
            ch = node[1]
            if ch == "\0":
                return "".join(chars)
            chars.append(ch)
            cur = 0
            # The game emits a leaf before consuming the look-ahead bit.
            continue
        bit = (payload[bit_pos // 8] >> (bit_pos % 8)) & 1
        bit_pos += 1
        next_id = node[1] if bit else node[2]
        if next_id < 0:
            raise ValueError("Vnitřní Huffmanův uzel odkazuje na záporného potomka")
        cur = next_id
    raise ValueError("Huffmanův řetězec není ukončen nulovým znakem")


def parse_tlk_export(export_data: bytes, endian: str) -> tuple[bytes, list[TlkEntry], dict]:
    if len(export_data) < 44:
        raise ValueError("BioTlkFile export je příliš krátký")
    prefix = export_data[:40]
    pos = 40
    entry_count = struct.unpack_from(endian + "i", export_data, pos)[0]
    pos += 4
    entries: list[TlkEntry] = []
    for _ in range(entry_count):
        sid, flags, index = struct.unpack_from(endian + "iii", export_data, pos)
        pos += 12
        entries.append(TlkEntry(sid, flags, index))

    node_count = struct.unpack_from(endian + "i", export_data, pos)[0]
    pos += 4
    nodes: list[tuple] = []
    for _ in range(node_count):
        leaf = export_data[pos] != 0
        pos += 1
        if leaf:
            codepoint = struct.unpack_from(endian + "H", export_data, pos)[0]
            pos += 2
            nodes.append(("leaf", chr(codepoint)))
        else:
            right, left = struct.unpack_from(endian + "hh", export_data, pos)
            pos += 4
            nodes.append(("node", right, left))

    string_count = struct.unpack_from(endian + "i", export_data, pos)[0]
    pos += 4
    strings: list[str] = []
    for _ in range(string_count):
        _string_length, encoded_length = struct.unpack_from(
            endian + "ii", export_data, pos
        )
        pos += 8
        payload = export_data[pos : pos + encoded_length]
        pos += encoded_length
        strings.append(decode_huffman_string(payload, nodes))

    if pos != len(export_data):
        raise ValueError(f"TLK parser spotřeboval {pos} z {len(export_data)} bajtů")

    for entry in entries:
        if entry.flags == 1:
            if not (0 <= entry.index < len(strings)):
                raise ValueError(f"Neplatný aktivní TLK index {entry.index}")
            entry.text = strings[entry.index]

    stats = {
        "entry_count": entry_count,
        "node_count": node_count,
        "string_count": string_count,
        "active_count": sum(e.flags == 1 for e in entries),
    }
    return prefix, entries, stats


def build_huffman(entries: list[TlkEntry]) -> tuple[HuffNode, dict[str, list[int]]]:
    frequency = Counter()
    for entry in entries:
        if entry.flags == 1:
            frequency.update((entry.text or "") + "\0")
    if not frequency:
        raise ValueError("Nelze sestavit prázdný Huffmanův strom")

    heap: list[tuple[int, int, HuffNode]] = []
    serial = 0
    # Stable ordering is required for reproducible output.
    for ch in sorted(frequency):
        heapq.heappush(heap, (frequency[ch], serial, HuffNode(ch, frequency[ch])))
        serial += 1
    while len(heap) > 1:
        f1, _s1, left = heapq.heappop(heap)
        f2, _s2, right = heapq.heappop(heap)
        parent = HuffNode(None, f1 + f2, left=left, right=right)
        heapq.heappush(heap, (parent.freq, serial, parent))
        serial += 1
    root = heap[0][2]

    codes: dict[str, list[int]] = {}

    def walk(node: HuffNode, path: list[int]) -> None:
        if node.leaf:
            assert node.char is not None
            codes[node.char] = path[:] if path else [0]
            return
        assert node.left is not None and node.right is not None
        walk(node.left, path + [0])
        walk(node.right, path + [1])

    walk(root, [])
    return root, codes


def serialize_tree(root: HuffNode) -> bytes:
    bfs: list[HuffNode] = []
    queue = [root]
    while queue:
        node = queue.pop(0)
        node.node_id = len(bfs)
        bfs.append(node)
        if not node.leaf:
            assert node.right is not None and node.left is not None
            queue.append(node.right)
            queue.append(node.left)

    out = bytearray(struct.pack(">i", len(bfs)))
    for node in bfs:
        if node.leaf:
            assert node.char is not None
            cp = ord(node.char)
            if cp > 0xFFFF:
                raise ValueError(
                    f"Znak mimo BMP U+{cp:06X} není formátem ME1 TLK podporován"
                )
            out.append(1)
            out += struct.pack(">H", cp)
        else:
            assert node.right is not None and node.left is not None
            out.append(0)
            out += struct.pack(">hh", node.right.node_id, node.left.node_id)
    return bytes(out)


def encode_bits(bits: list[int]) -> bytes:
    out = bytearray((len(bits) + 7) // 8)
    for i, bit in enumerate(bits):
        if bit:
            out[i // 8] |= 1 << (i % 8)
    return bytes(out)


def build_tlk_export(prefix: bytes, entries: list[TlkEntry]) -> bytes:
    root, codes = build_huffman(entries)
    tree = serialize_tree(root)

    active_index = 0
    encoded: list[tuple[int, bytes]] = []
    normalized_entries: list[TlkEntry] = []
    for entry in entries:
        e = TlkEntry(entry.string_id, entry.flags, entry.index, entry.text)
        if e.flags == 1:
            e.index = active_index
            active_index += 1
            terminated = (e.text or "") + "\0"
            bits: list[int] = []
            for ch in terminated:
                bits.extend(codes[ch])
            # Required by the ME1 decoder when NUL ends exactly on a byte boundary.
            bits.append(0)
            encoded.append((len(terminated), encode_bits(bits)))
        else:
            e.index = -1 if e.string_id > 0 else 0
        normalized_entries.append(e)

    out = bytearray(prefix)
    prop_count = struct.unpack_from(">i", out, 28)[0]
    if prop_count != len(normalized_entries):
        struct.pack_into(">i", out, 28, len(normalized_entries))

    out += struct.pack(">i", len(normalized_entries))
    for e in normalized_entries:
        out += struct.pack(">iii", e.string_id, e.flags, e.index)
    out += tree
    out += struct.pack(">i", len(encoded))
    for string_length, payload in encoded:
        out += struct.pack(">ii", string_length, len(payload))
        out += payload
    return bytes(out)


def merge_base_translation(
    original_entries: list[TlkEntry],
    source_entries: list[TlkEntry],
    xbox_only: dict[str, str],
):
    source_by_id = {
        e.string_id: e.text
        for e in source_entries
        if e.flags == 1 and e.text is not None
    }
    result: list[TlkEntry] = []
    from_pc = 0
    from_xbox_map = 0
    retained_english = 0
    missing: list[dict[str, object]] = []
    for e in original_entries:
        n = TlkEntry(e.string_id, e.flags, e.index, e.text)
        if n.flags == 1:
            if n.string_id in source_by_id:
                n.text = source_by_id[n.string_id]
                from_pc += 1
            elif (n.text or "") in xbox_only:
                n.text = xbox_only[n.text or ""]
                from_xbox_map += 1
            else:
                retained_english += 1
                missing.append({"string_id": n.string_id, "english": n.text})
        result.append(n)
    return result, {
        "from_pc_czech_by_string_id": from_pc,
        "from_xbox_only_dictionary": from_xbox_map,
        "retained_english": retained_english,
        "missing": missing,
        "active_total": sum(e.flags == 1 for e in result),
    }


def active_map(entries: list[TlkEntry]) -> dict[int, str | None]:
    return {entry.string_id: entry.text for entry in entries if entry.flags == 1}
