#!/usr/bin/env python3
"""Build complete Czech ME1 DLC containers directly from untouched originals."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
from collections import defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PATCHER = ROOT / "work" / "me1_patcher_v2" / "ME1_X360_CZ_Patcher_Source_v2"
sys.path.insert(0, str(PATCHER))

from me1lib import stfs  # noqa: E402


CONFIG = {
    "btds": {
        "global_path": "Content/Packages/Dialog/DLC_UNC_GlobalTlk.xxx",
        "display_name": "Strhnout oblohu [ENPLES]",
        "description": (
            "Batariánští extrémisté unesli asteroid X57 a nasměrovali jej na Terru Novu. "
            "Zastavte je dřív, než planetu zničí."
        ),
    },
    "pinnacle": {
        "global_path": "Content/Packages/Dialog/DLC_Vegas_GlobalTlk.xxx",
        "display_name": "Stanice Pinnacle [ENPLES]",
        "description": (
            "Navštivte stanici Pinnacle a zapojte se do série bojových simulací "
            "ve vojenském výcvikovém středisku Rady."
        ),
    },
}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def load_patchset(patchset: Path) -> dict[str, bytes]:
    report = json.loads((patchset / "build_report.json").read_text(encoding="utf-8"))
    return {
        item["path"]: (patchset / "patched" / Path(item["path"])).read_bytes()
        for item in report["patched"]
    }


def extend_physical_file(stream, package: stfs.STFS, new_total_blocks: int) -> None:
    required_size = package.data_offset(new_total_blocks - 1) + stfs.SECTOR
    stream.seek(0, 2)
    current_size = stream.tell()
    if required_size < current_size:
        raise RuntimeError("Refusing to shrink the STFS physical file")
    if required_size > current_size:
        stream.write(bytes(required_size - current_size))
    stream.seek(package.vol_off + 28)
    stream.write(new_total_blocks.to_bytes(4, "big"))
    stream.seek(0x34C)
    stream.write((required_size - package.rounded_header).to_bytes(8, "big"))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("kind", choices=("btds", "pinnacle"))
    parser.add_argument("source_container", type=Path)
    parser.add_argument("global_tlk", type=Path)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("patchsets", nargs="+", type=Path)
    args = parser.parse_args()

    config = CONFIG[args.kind]
    source = stfs.STFS(args.source_container)
    replacements: dict[str, bytes] = {
        config["global_path"]: args.global_tlk.read_bytes()
    }
    for patchset_index, patchset in enumerate(args.patchsets):
        patchset_files = load_patchset(patchset)
        if args.kind == "btds" and patchset_index > 0:
            fallback_only = "Content/Maps/UNC52/DSG/BIOA_UNC52_02_DSG.xxx"
            patchset_files = {
                path: data for path, data in patchset_files.items() if path == fallback_only
            }
        for path, data in patchset_files.items():
            if path in replacements and replacements[path] != data:
                raise RuntimeError(f"Conflicting replacement: {path}")
            replacements[path] = data

    # BDtS has one file whose append-mode patch is the known runtime-safe result.
    if args.kind == "btds":
        fallback = "Content/Maps/UNC52/DSG/BIOA_UNC52_02_DSG.xxx"
        append_candidates = [
            patchset / "patched" / Path(fallback)
            for patchset in args.patchsets
            if (patchset / "patched" / Path(fallback)).exists()
        ]
        if append_candidates:
            replacements[fallback] = append_candidates[-1].read_bytes()

    referenced = set(range(source.dir_first, source.dir_first + source.dir_blocks))
    original_chains: dict[str, list[int]] = {}
    for entry in source.entries:
        if entry.is_dir or not entry.alloc_blocks:
            continue
        chain = stfs.allocation_chain(args.source_container, source, entry)
        original_chains[entry.path] = chain
        referenced.update(chain)
    free_blocks = [block for block in range(source.total_blocks) if block not in referenced]

    chains: dict[str, list[int]] = {}
    released_blocks: list[int] = []
    overflow: list[tuple[str, int]] = []
    for path, data in replacements.items():
        entry = source.entry_by_path(path)
        old_chain = original_chains[path]
        required = (len(data) + stfs.SECTOR - 1) // stfs.SECTOR
        chain = old_chain[:required]
        released_blocks.extend(old_chain[required:])
        if required > len(chain):
            overflow.append((path, required - len(chain)))
        chains[path] = chain

    available = free_blocks + released_blocks
    total_extra = sum(count for _path, count in overflow)
    extension_count = max(0, total_extra - len(available))
    extension_blocks = list(range(source.total_blocks, source.total_blocks + extension_count))
    available.extend(extension_blocks)
    cursor = 0
    for path, count in overflow:
        chains[path].extend(available[cursor : cursor + count])
        cursor += count

    args.output_dir.mkdir(parents=True, exist_ok=True)
    temp = args.output_dir / f".{args.kind}_fresh.tmp"
    shutil.copyfile(args.source_container, temp)
    modified = set()
    with temp.open("r+b") as stream:
        if extension_count:
            extend_physical_file(stream, source, source.total_blocks + extension_count)
        stfs.patch_display_metadata(
            stream, str(config["display_name"]), str(config["description"])
        )
        for path, data in replacements.items():
            entry = source.entry_by_path(path)
            chain = chains[path]
            stfs.write_chain(stream, source, chain, data)
            stfs.patch_dir_entry(
                stream,
                source,
                entry,
                valid_blocks=len(chain),
                alloc_blocks=len(chain),
                start_block=chain[0],
                size=len(data),
                contiguous=all(
                    block + 1 == chain[index + 1]
                    for index, block in enumerate(chain[:-1])
                ),
            )
            modified.update(chain)
            modified.add(entry.dir_block)
        stfs.rehash(stream, source, modified)

    # Verify every data block, the hash hierarchy root and the Content ID.
    rebuilt = stfs.STFS(temp)
    content_id = stfs.verify_stfs(temp, range(rebuilt.total_blocks))
    final = args.output_dir / content_id
    if final.exists():
        final.unlink()
    temp.rename(final)
    rebuilt = stfs.STFS(final)

    replacement_checks = []
    untouched_count = 0
    all_owners: dict[int, list[str]] = defaultdict(list)
    all_owners.update({block: ["<directory>"] for block in range(rebuilt.dir_first, rebuilt.dir_first + rebuilt.dir_blocks)})
    for entry in rebuilt.entries:
        if entry.is_dir or not entry.alloc_blocks:
            continue
        chain = stfs.allocation_chain(final, rebuilt, entry)
        for block in chain:
            all_owners[block].append(entry.path)
        actual, observed = stfs.read_chain(final, rebuilt, entry)
        if entry.path in replacements:
            expected = replacements[entry.path]
            if actual != expected:
                raise RuntimeError(f"Replacement extraction mismatch: {entry.path}")
            replacement_checks.append(
                {
                    "path": entry.path,
                    "size": len(actual),
                    "sha256": sha256(actual),
                    "blocks": len(observed),
                    "contiguous": bool(entry.flags & 0x40),
                }
            )
        else:
            source_entry = source.entry_by_path(entry.path)
            expected = source.read_file(source_entry)
            if actual != expected:
                raise RuntimeError(f"Untouched file changed: {entry.path}")
            untouched_count += 1

    overlaps = {
        str(block): owners
        for block, owners in all_owners.items()
        if len(owners) > 1
    }
    if overlaps:
        raise RuntimeError(f"STFS allocation overlap: {list(overlaps.items())[:3]}")

    autoload_path = "AutoLoad.ini"
    source_autoload = source.read_file(source.entry_by_path(autoload_path))
    rebuilt_autoload, _ = stfs.read_chain(final, rebuilt, rebuilt.entry_by_path(autoload_path))
    if source_autoload != rebuilt_autoload:
        raise RuntimeError("AutoLoad.ini changed")

    report = {
        "kind": args.kind,
        "source": str(args.source_container),
        "output": str(final),
        "content_id": content_id,
        "output_size": final.stat().st_size,
        "output_sha256": hashlib.sha256(final.read_bytes()).hexdigest(),
        "replacement_count": len(replacements),
        "untouched_file_count": untouched_count,
        "source_total_blocks": source.total_blocks,
        "output_total_blocks": rebuilt.total_blocks,
        "extension_blocks": extension_count,
        "free_source_blocks": len(free_blocks),
        "released_blocks": len(released_blocks),
        "overflow": overflow,
        "replacement_checks": replacement_checks,
        "checks": [
            "built directly from the untouched official DLC container",
            "AutoLoad.ini byte-identical to the official DLC",
            "every untouched file byte-identical to the official DLC",
            "every replacement extracted byte-identical to its generated payload",
            "no STFS allocation overlaps",
            "all data-block hashes, root hash and Content ID verified",
        ],
    }
    (args.output_dir / "validation.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps({"output": str(final), "content_id": content_id, "size": final.stat().st_size}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
