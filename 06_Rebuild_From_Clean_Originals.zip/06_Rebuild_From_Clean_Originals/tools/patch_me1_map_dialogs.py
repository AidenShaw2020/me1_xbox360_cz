#!/usr/bin/env python3
"""Put PC Czech local conversation TLKs into ME1 Xbox Polish language slots."""

from __future__ import annotations

import argparse
import copy
import json
import os
import struct
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PATCHER = ROOT / "work" / "me1_patcher_v2" / "ME1_X360_CZ_Patcher_Source_v2"
sys.path.insert(0, str(ROOT / "tools"))
sys.path.insert(0, str(PATCHER))

import me1_xbox_package as ue3  # noqa: E402

DLL = (
    ROOT
    / "work"
    / "LegendaryExplorer-master"
    / "LegendaryExplorer"
    / "LegendaryExplorerCore"
    / "Libraries"
    / "Windows"
    / "CompressionWrappers.dll"
)
MINILZO_DLL = ROOT / "work" / "minilzo-2.10" / "lzo2.dll"
_PC_INDEX_CACHE: dict[Path, dict[str, Path]] = {}
_PC_TLK_CACHE: dict[tuple[Path, bool], tuple[list[ue3.TlkEntry], bytes]] = {}


def build_chunk(dll, raw: bytes) -> bytes:
    blocks = []
    for pos in range(0, len(raw), 0x20000):
        plain = raw[pos : pos + 0x20000]
        blocks.append((ue3.lzo_compress(dll, plain), len(plain)))
    table = b"".join(struct.pack(">ii", len(comp), usize) for comp, usize in blocks)
    payload = b"".join(comp for comp, _usize in blocks)
    return struct.pack(">iIii", ue3.CHUNK_MAGIC, ue3.PACKAGE_MAGIC, len(table) + len(payload), len(raw)) + table + payload


def build_multichunk(source_pkg: bytes, header: ue3.Header, logical: bytes, ranges):
    dll = ue3.load_compression_dll(DLL)
    package_source_offset = header.compression_offset + 8 + 16 * len(header.chunks)
    package_source = source_pkg[package_source_offset : package_source_offset + 4]
    chunks = []
    physical_header_size = header.compression_offset + 8 + 16 * len(ranges) + 4
    compressed_offset = physical_header_size
    for uoff, usize in ranges:
        chunk = build_chunk(dll, logical[uoff : uoff + usize])
        chunks.append((uoff, usize, compressed_offset, len(chunk), chunk))
        compressed_offset += len(chunk)
    output = bytearray(source_pkg[: header.compression_offset])
    output += struct.pack(">ii", 2, len(chunks))
    for uoff, usize, coff, csize, _chunk in chunks:
        output += struct.pack(">iiii", uoff, usize, coff, csize)
    output += package_source
    if len(output) != physical_header_size:
        raise RuntimeError("Physical header size mismatch")
    output += b"".join(chunk for _u, _s, _c, _z, chunk in chunks)
    return bytes(output), chunks


def build_selective_package(
    source_pkg: bytes, original_logical: bytes, logical: bytes, ranges, lzo
):
    """Recompress only changed 128 KiB LZO blocks and copy every other block verbatim."""
    _ctype, records, package_source, _header_size = lzo.read_chunk_records(source_pkg)
    built = []
    changed_blocks = []
    compressed_offset = 125 + 16 * len(ranges) + 4
    for chunk_index, (uoff, usize, coff, csize) in enumerate(records):
        source_chunk = source_pkg[coff : coff + csize]
        block_count = (usize + lzo.BLOCK_SIZE - 1) // lzo.BLOCK_SIZE
        source_meta = [
            struct.unpack_from(">II", source_chunk, 16 + block_index * 8)
            for block_index in range(block_count)
        ]
        source_pos = 16 + block_count * 8
        source_blocks = []
        for compressed_size, uncompressed_size in source_meta:
            source_blocks.append(source_chunk[source_pos : source_pos + compressed_size])
            source_pos += compressed_size

        new_blocks = []
        changed_in_chunk = []
        raw_pos = uoff
        for block_index, ((old_csize, block_usize), old_block) in enumerate(
            zip(source_meta, source_blocks)
        ):
            old_raw = original_logical[raw_pos : raw_pos + block_usize]
            new_raw = logical[raw_pos : raw_pos + block_usize]
            if new_raw == old_raw:
                new_block = old_block
            else:
                new_block = lzo.lzo_compress(new_raw)
                changed_in_chunk.append(block_index)
                changed_blocks.append(
                    {
                        "chunk": chunk_index,
                        "block": block_index,
                        "uncompressed_offset": raw_pos,
                        "uncompressed_size": block_usize,
                        "old_compressed_size": old_csize,
                        "new_compressed_size": len(new_block),
                    }
                )
            new_blocks.append((new_block, block_usize))
            raw_pos += block_usize

        if not changed_in_chunk:
            new_chunk = source_chunk
        else:
            table = b"".join(
                struct.pack(">II", len(block), block_usize)
                for block, block_usize in new_blocks
            )
            payload = b"".join(block for block, _block_usize in new_blocks)
            new_chunk = struct.pack(">IIII", ue3.PACKAGE_MAGIC, ue3.PACKAGE_MAGIC, len(payload), usize) + table + payload
        built.append((uoff, usize, compressed_offset, len(new_chunk), new_chunk))
        compressed_offset += len(new_chunk)

    for uoff, usize in ranges[len(records) :]:
        new_chunk, _blocks = lzo.build_chunk(logical[uoff : uoff + usize])
        built.append((uoff, usize, compressed_offset, len(new_chunk), new_chunk))
        compressed_offset += len(new_chunk)

    header = bytearray(logical[:125])
    struct.pack_into(">i", header, 121, len(built))
    for uoff, usize, coff, csize, _chunk in built:
        header += struct.pack(">iiii", uoff, usize, coff, csize)
    header += package_source
    output = bytes(header) + b"".join(chunk for _u, _s, _c, _z, chunk in built)
    return output, built, changed_blocks


def bio_tlk_exports(data: bytes, header: ue3.Header):
    names = ue3.parse_names(data, header)
    imports = ue3.parse_imports(data, header)
    exports = ue3.parse_exports(data, header)
    found = []
    for index, exp in enumerate(exports, 1):
        cls = ue3.entry_name(exp.class_index, names, imports, exports)
        if cls == "BioTlkFile":
            found.append((index, exp, names[exp.object_name]))
    return names, imports, exports, found


def parse_export_tlk(data: bytes, exp: ue3.ExportEntry, names: list[str], endian: str):
    blob = data[exp.data_offset : exp.data_offset + exp.data_size]
    prefix_len = ue3.find_binary_start(blob, names, endian)
    return blob[:prefix_len], ue3.parse_tlk(blob[prefix_len:], endian)


def locate_pc_package(root: Path, package_name: str) -> Path:
    resolved_root = root.resolve()
    if resolved_root not in _PC_INDEX_CACHE:
        index: dict[str, Path] = {}
        duplicates = set()
        for path in resolved_root.rglob("*.upk"):
            key = path.stem.casefold()
            if key in index:
                duplicates.add(key)
            else:
                index[key] = path
        for key in duplicates:
            index.pop(key, None)
        _PC_INDEX_CACHE[resolved_root] = index
    match = _PC_INDEX_CACHE[resolved_root].get(package_name.casefold())
    if match is None:
        raise RuntimeError(
            f"PC package {package_name!r}: expected one unique match below {root}"
        )
    return match


def get_pc_czech_tlk(path: Path, male: bool):
    cache_key = (path.resolve(), male)
    if cache_key in _PC_TLK_CACHE:
        return _PC_TLK_CACHE[cache_key]
    data = path.read_bytes()
    header = ue3.parse_header(data)
    if header.chunks:
        raise RuntimeError(f"Compressed PC package is not supported: {path}")
    names, _imports, _exports, tlks = bio_tlk_exports(data, header)
    wanted = "tlk_M_CS" if male else "tlk_CS"
    matches = [(exp, obj) for _i, exp, obj in tlks if obj.casefold() == wanted.casefold()]
    if len(matches) != 1:
        raise RuntimeError(f"{path}: expected one {wanted}, got {len(matches)}")
    exp, _obj = matches[0]
    blob = data[exp.data_offset : exp.data_offset + exp.data_size]
    prefix_len = ue3.find_binary_start(blob, names, "<")
    binary = blob[prefix_len:]
    result = (ue3.parse_tlk(binary, "<"), binary)
    _PC_TLK_CACHE[cache_key] = result
    return result


def merge_into_xbox_skeleton(xbox_entries, pc_entries):
    pc_active = {e.string_id: e.text for e in pc_entries if e.flags == 1 and e.text is not None}
    merged = copy.deepcopy(xbox_entries)
    active = 0
    translated = 0
    missing = []
    whitespace_only_missing = []
    for entry in merged:
        if entry.flags != 1:
            continue
        active += 1
        if entry.string_id in pc_active:
            entry.text = pc_active[entry.string_id]
            translated += 1
        else:
            if (entry.text or "").strip() == "":
                whitespace_only_missing.append(entry.string_id)
            else:
                missing.append(entry.string_id)
    return merged, {
        "active": active,
        "translated": translated,
        "missing_ids": missing,
        "whitespace_only_missing_ids": whitespace_only_missing,
    }


def patch_map(
    source: Path,
    pc_root: Path,
    slot: str = "pl",
    mode: str = "append",
    backend: str = "windows",
    encoding: str = "rebuilt",
    package_filter: set[str] | None = None,
    root_package_name: str | None = None,
):
    source_pkg = source.read_bytes()
    disk_header = ue3.parse_header(source_pkg)
    uncompressed_package = not disk_header.chunks and disk_header.compression_type == 0
    native_lzo = None
    native_records = None
    if uncompressed_package:
        logical = source_pkg
    elif backend in {"minilzo", "minilzo-selective"}:
        os.environ.setdefault("ME1_LZO_LIBRARY", str(MINILZO_DLL.resolve()))
        from me1lib import lzo_ue3 as native_lzo

        logical, native_records, _native_blocks, _native_header = native_lzo.decompress_package(
            source_pkg
        )
    elif backend == "windows":
        logical = ue3.decompress_package(source_pkg, disk_header, DLL)
    else:
        raise ValueError(f"Unsupported backend: {backend}")
    header = ue3.parse_header(logical)
    names, imports, exports, tlks = bio_tlk_exports(logical, header)

    if slot == "pl":
        target_names = {"tlk_pl", "tlk_m_pl"}
    elif slot == "int":
        target_names = {"tlk", "tlk_m"}
    else:
        raise ValueError(f"Unsupported slot: {slot}")
    targets = []
    for export_index, exp, object_name in tlks:
        lowered = object_name.casefold()
        if lowered not in target_names:
            continue
        if exp.parent <= 0:
            if not root_package_name:
                raise RuntimeError(f"{object_name} has no export parent")
            package_name = root_package_name
        else:
            package_name = names[exports[exp.parent - 1].object_name]
        if package_filter and package_name.casefold() not in package_filter:
            continue
        pc_path = locate_pc_package(pc_root, package_name)
        male = lowered in {"tlk_m", "tlk_m_pl"}
        pc_entries, pc_binary = get_pc_czech_tlk(pc_path, male)
        prefix, xbox_entries = parse_export_tlk(logical, exp, names, ">")
        merged, coverage = merge_into_xbox_skeleton(xbox_entries, pc_entries)
        if coverage["missing_ids"]:
            raise RuntimeError(
                f"{source.name}/{package_name}/{object_name}: missing PC Czech IDs "
                f"{coverage['missing_ids'][:10]} (total {len(coverage['missing_ids'])})"
            )
        if encoding == "pc-raw":
            converted = ue3.convert_tlk_endian(pc_binary, "<", ">")
            converted_entries = ue3.parse_tlk(converted, ">")
            converted_map = {
                e.string_id: e.text for e in converted_entries if e.flags == 1
            }
            merged_map = {e.string_id: e.text for e in merged if e.flags == 1}
            if any(
                converted_map.get(string_id) != text
                for string_id, text in merged_map.items()
                if string_id not in coverage["whitespace_only_missing_ids"]
            ):
                raise RuntimeError(f"{package_name}/{object_name}: raw endian conversion mismatch")
            blob = prefix + converted
            expected_entries = converted_entries
        elif encoding == "rebuilt":
            blob = prefix + ue3.build_tlk(merged, ">")
            expected_entries = merged
        else:
            raise ValueError(f"Unsupported TLK encoding: {encoding}")
        targets.append(
            {
                "export_index": export_index,
                "export": exp,
                "object_name": object_name,
                "package_name": package_name,
                "pc_path": str(pc_path),
                "coverage": coverage,
                "blob": blob,
                "expected": {e.string_id: e.text for e in expected_entries if e.flags == 1},
            }
        )

    if not targets:
        raise RuntimeError(f"No tlk_PL/tlk_M_PL exports found in {source}")

    ranges = (
        [(uoff, usize) for uoff, usize, _coff, _csize in native_records]
        if native_records is not None
        else [(c.uncompressed_offset, c.uncompressed_size) for c in disk_header.chunks]
    )
    patched = bytearray(logical)
    if mode in {"append", "append-zero-old"}:
        for target in targets:
            target["new_offset"] = len(patched)
            target["overwritten_exports"] = []
            patched += target["blob"]
            exp = target["export"]
            struct.pack_into(">ii", patched, exp.table_offset + 32, len(target["blob"]), target["new_offset"])
            if mode == "append-zero-old":
                patched[exp.data_offset : exp.data_offset + exp.data_size] = bytes(exp.data_size)
        if not uncompressed_package:
            ranges.extend((t["new_offset"], len(t["blob"])) for t in targets)
            struct.pack_into(">i", patched, 121, len(ranges))
    elif mode in {"reuse-pl", "swap-pl", "swap-any"}:
        if slot != "int":
            raise RuntimeError("reuse-pl is intended only for the active INT slot")
        for target in targets:
            exp = target["export"]
            male_target = target["object_name"].casefold() == "tlk_m"
            if mode == "swap-any":
                candidate_names = {
                    ("tlk_m_" if male_target else "tlk_") + suffix
                    for suffix in ("de", "es", "fr", "it", "pl")
                }
                replacement_matches = [
                    (replacement_index, replacement)
                    for replacement_index, replacement in enumerate(exports, 1)
                    if replacement.parent == exp.parent
                    and names[replacement.object_name].casefold() in candidate_names
                    and replacement.data_size >= len(target["blob"])
                ]
                replacement_matches.sort(key=lambda pair: pair[1].data_size)
                replacement_matches = replacement_matches[:1]
                replacement_name = (
                    names[replacement_matches[0][1].object_name]
                    if replacement_matches
                    else "any inactive language slot"
                )
            else:
                replacement_name = "tlk_M_PL" if male_target else "tlk_PL"
                replacement_matches = [
                    (replacement_index, replacement)
                    for replacement_index, replacement in enumerate(exports, 1)
                    if replacement.parent == exp.parent
                    and names[replacement.object_name].casefold() == replacement_name.casefold()
                ]
            if len(replacement_matches) != 1:
                raise RuntimeError(
                    f"Cannot find sibling {replacement_name} for {target['package_name']}"
                )
            replacement_index, replacement = replacement_matches[0]
            if len(target["blob"]) > replacement.data_size:
                raise RuntimeError(
                    f"{target['package_name']}/{target['object_name']}: Czech TLK "
                    f"{len(target['blob'])} does not fit PL slot {replacement.data_size}"
                )
            start = replacement.data_offset
            end = start + len(target["blob"])
            patched[start:end] = target["blob"]
            target["new_offset"] = start
            target["overwritten_exports"] = [
                {
                    "export_index": replacement_index,
                    "object_name": replacement_name,
                    "reused_as_czech_storage": True,
                    "original_size": replacement.data_size,
                }
            ]
            struct.pack_into(">ii", patched, exp.table_offset + 32, len(target["blob"]), start)
            if mode == "reuse-pl":
                struct.pack_into(
                    ">ii", patched, replacement.table_offset + 32, len(target["blob"]), start
                )
            else:
                # Keep every export on a unique valid serialized range: INT uses
                # the larger former PL range, while PL takes over the untouched
                # original INT range.
                struct.pack_into(
                    ">ii",
                    patched,
                    replacement.table_offset + 32,
                    exp.data_size,
                    exp.data_offset,
                )
                target["overwritten_exports"][0]["swapped_to_original_int"] = {
                    "offset": exp.data_offset,
                    "size": exp.data_size,
                }
    elif mode == "inplace-overlap":
        if slot != "int":
            raise RuntimeError("inplace-overlap is intended only for the active INT slot")
        allowed_overlap = {"tlk_es", "tlk_m_es", "tlk_pl", "tlk_m_pl"}
        target_exports = {t["export_index"] for t in targets}
        for target in targets:
            exp = target["export"]
            start = exp.data_offset
            end = start + len(target["blob"])
            overwritten = []
            for other_index, other in enumerate(exports, 1):
                if other_index == target["export_index"]:
                    continue
                other_start = other.data_offset
                other_end = other.data_offset + other.data_size
                if start < other_end and other_start < end:
                    other_name = names[other.object_name]
                    if other_index in target_exports or other_name.casefold() not in allowed_overlap:
                        raise RuntimeError(
                            f"{target['package_name']}/{target['object_name']} would overlap "
                            f"unsafe export {other_index}:{other_name}"
                        )
                    replacement_name = "tlk_M_PL" if other_name.casefold() == "tlk_m_es" else "tlk_PL"
                    replacement_matches = [
                        (replacement_index, replacement)
                        for replacement_index, replacement in enumerate(exports, 1)
                        if replacement.parent == other.parent
                        and names[replacement.object_name].casefold() == replacement_name.casefold()
                    ]
                    if len(replacement_matches) != 1:
                        raise RuntimeError(
                            f"Cannot redirect overwritten {other_name} to sibling {replacement_name}"
                        )
                    replacement_index, replacement = replacement_matches[0]
                    overwritten.append(
                        {
                            "export_index": other_index,
                            "object_name": other_name,
                            "redirected_to_export": replacement_index,
                            "redirected_to_object": replacement_name,
                        }
                    )
                    struct.pack_into(
                        ">ii",
                        patched,
                        other.table_offset + 32,
                        replacement.data_size,
                        replacement.data_offset,
                    )
            if end > len(patched):
                raise RuntimeError("In-place TLK exceeds logical package size")
            patched[start:end] = target["blob"]
            target["new_offset"] = start
            target["overwritten_exports"] = overwritten
            struct.pack_into(">ii", patched, exp.table_offset + 32, len(target["blob"]), start)
    else:
        raise ValueError(f"Unsupported mode: {mode}")
    intended = bytes(patched)
    selective_changes = []
    if uncompressed_package:
        output = intended
        chunks = []
        rebuilt = output
    elif backend == "minilzo-selective":
        output, chunks, selective_changes = build_selective_package(
            source_pkg, logical, intended, ranges, native_lzo
        )
        rebuilt, _rr, _rb, _rh = native_lzo.decompress_package(output)
    elif native_lzo is not None:
        _ct, _cr, package_source, _ph = native_lzo.read_chunk_records(source_pkg)
        output, chunks = native_lzo.build_multichunk_package(
            source_pkg, intended, ranges, package_source
        )
        rebuilt, _rr, _rb, _rh = native_lzo.decompress_package(output)
    else:
        output, chunks = build_multichunk(source_pkg, disk_header, intended, ranges)
        rebuilt_header_on_disk = ue3.parse_header(output)
        rebuilt = ue3.decompress_package(output, rebuilt_header_on_disk, DLL)
    if rebuilt != intended:
        raise RuntimeError("LZO round-trip mismatch")
    rebuilt_header = ue3.parse_header(rebuilt)
    rebuilt_names, _ri, rebuilt_exports, _rt = bio_tlk_exports(rebuilt, rebuilt_header)
    for target in targets:
        exp = rebuilt_exports[target["export_index"] - 1]
        prefix, decoded = parse_export_tlk(rebuilt, exp, rebuilt_names, ">")
        actual = {e.string_id: e.text for e in decoded if e.flags == 1}
        if actual != target["expected"]:
            raise RuntimeError(f"Decoded TLK mismatch: {target['package_name']}/{target['object_name']}")

    report_targets = []
    for t in targets:
        report_targets.append(
            {
                "export_index": t["export_index"],
                "package_name": t["package_name"],
                "object_name": t["object_name"],
                "pc_path": t["pc_path"],
                "coverage": t["coverage"],
                "new_offset": t["new_offset"],
                "new_size": len(t["blob"]),
                "original_offset": t["export"].data_offset,
                "original_size": t["export"].data_size,
                "fits_in_place": len(t["blob"]) <= t["export"].data_size,
                "overwritten_exports": t["overwritten_exports"],
            }
        )
    return output, {
        "source": str(source),
        "source_size": len(source_pkg),
        "output_size": len(output),
        "original_chunks": len(disk_header.chunks),
        "output_chunks": len(chunks),
        "slot": slot,
        "mode": mode,
        "compression_backend": backend,
        "tlk_encoding": encoding,
        "selectively_recompressed_blocks": selective_changes,
        "targets": report_targets,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("pc_dialog_root", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--report", type=Path)
    parser.add_argument("--slot", choices=["int", "pl"], default="pl")
    parser.add_argument(
        "--mode",
        choices=[
            "append",
            "append-zero-old",
            "reuse-pl",
            "swap-pl",
            "swap-any",
            "inplace-overlap",
        ],
        default="append",
    )
    parser.add_argument(
        "--backend",
        choices=["windows", "minilzo", "minilzo-selective"],
        default="windows",
    )
    parser.add_argument("--encoding", choices=["rebuilt", "pc-raw"], default="rebuilt")
    parser.add_argument(
        "--package",
        action="append",
        default=[],
        help="Patch only this embedded PC package stem; may be repeated",
    )
    args = parser.parse_args()
    output, report = patch_map(
        args.source,
        args.pc_dialog_root,
        args.slot,
        args.mode,
        args.backend,
        args.encoding,
        {name.casefold() for name in args.package} or None,
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_bytes(output)
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
