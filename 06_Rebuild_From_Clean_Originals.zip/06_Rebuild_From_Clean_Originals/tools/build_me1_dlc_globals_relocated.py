#!/usr/bin/env python3
"""Build runtime-safe Czech DLC global TLKs by relocating only TLK exports."""

from __future__ import annotations

import argparse
import hashlib
import json
import struct
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PATCHER = ROOT / "work" / "me1_patcher_v2" / "ME1_X360_CZ_Patcher_Source_v2"
sys.path.insert(0, str(PATCHER))

from me1lib import lzo_ue3 as lzo  # noqa: E402
from me1lib import stfs  # noqa: E402
from me1lib import ue3_tlk as tlk  # noqa: E402


BDTS_PATH = "Content/Packages/Dialog/DLC_UNC_GlobalTlk.xxx"
PINNACLE_PATH = "Content/Packages/Dialog/DLC_Vegas_GlobalTlk.xxx"


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def signed_sort_key(entry: tlk.TlkEntry) -> int:
    return entry.string_id if entry.string_id >= 0 else entry.string_id - (-2147483648)


def translated_entries_btds(original_entries: list[tlk.TlkEntry], gender: int) -> list[tlk.TlkEntry]:
    pc = (PATCHER / "assets" / "GlobalTlk_CS.upk").read_bytes()
    tables = tlk.parse_package_tables(pc, "<")
    source_export = tables["exports"][gender]
    source_blob = pc[source_export.data_offset : source_export.data_offset + source_export.data_size]
    _prefix, source_entries, _stats = tlk.parse_tlk_export(source_blob, "<")
    source_by_id = {entry.string_id: entry.text for entry in source_entries if entry.flags == 1}
    result = []
    for entry in original_entries:
        text = entry.text
        if entry.flags == 1:
            if entry.string_id not in source_by_id:
                raise RuntimeError(f"BDtS StringID {entry.string_id} is missing in the PC Czech source")
            text = source_by_id[entry.string_id]
        result.append(tlk.TlkEntry(entry.string_id, entry.flags, entry.index, text))
    return result


def translated_entries_pinnacle(original_entries: list[tlk.TlkEntry]) -> list[tlk.TlkEntry]:
    translations = json.loads(
        (PATCHER / "assets" / "DLC_Vegas_translation_cs.json").read_text(encoding="utf-8")
    )
    result = []
    for entry in original_entries:
        text = entry.text
        if entry.flags == 1:
            if text not in translations:
                raise RuntimeError(
                    f"Pinnacle StringID {entry.string_id} lacks a Czech translation: {text!r}"
                )
            text = translations[text]
        result.append(tlk.TlkEntry(entry.string_id, entry.flags, entry.index, text))
    return result


def build_relocated(source_inner: bytes, kind: str) -> tuple[bytes, dict]:
    compression_type = struct.unpack_from(">i", source_inner, 117)[0]
    if compression_type == 2:
        logical, source_records, _source_blocks, _ = lzo.decompress_package(source_inner)
    elif compression_type == 0:
        logical = source_inner
        source_records = []
    else:
        raise RuntimeError(f"Unsupported UE3 compression type {compression_type}")

    tables = tlk.parse_package_tables(logical, ">")
    exports = tables["exports"]
    names = tables["names"]
    expected = (
        ["GlobalTlk_tlk", "GlobalTlk_tlk_M", "SeekFreeSaver", "SeekFreeShaderCache"]
        if kind == "btds"
        else ["GlobalTlk_tlk", "GlobalTlk_tlk_M"]
    )
    if [names[item.name_index] for item in exports] != expected:
        raise RuntimeError(f"Unexpected {kind} export layout")

    new_blobs = []
    expected_maps = []
    coverage = []
    for gender in range(2):
        export = exports[gender]
        old_blob = logical[export.data_offset : export.data_offset + export.data_size]
        prefix, original_entries, old_stats = tlk.parse_tlk_export(old_blob, ">")
        translated = (
            translated_entries_btds(original_entries, gender)
            if kind == "btds"
            else translated_entries_pinnacle(original_entries)
        )
        # The Xbox runtime does not treat the entry table as an arbitrary list.
        # Preserve the cooker's exact StringID/flag order; sorting by StringID
        # still decodes in generic tools but breaks lookups in the game.
        if [(item.string_id, item.flags) for item in translated] != [
            (item.string_id, item.flags) for item in original_entries
        ]:
            raise RuntimeError(f"{kind} gender {gender}: entry order changed")
        new_blob = tlk.build_tlk_export(prefix, translated)
        new_prefix, decoded, new_stats = tlk.parse_tlk_export(new_blob, ">")
        if new_prefix != prefix or tlk.active_map(decoded) != tlk.active_map(translated):
            raise RuntimeError(f"{kind} gender {gender}: semantic TLK round-trip failed")
        if [(item.string_id, item.flags) for item in decoded] != [
            (item.string_id, item.flags) for item in original_entries
        ]:
            raise RuntimeError(f"{kind} gender {gender}: serialized entry order changed")
        new_blobs.append(new_blob)
        expected_maps.append(tlk.active_map(translated))
        coverage.append(
            {
                "gender": gender,
                "entry_count": new_stats["entry_count"],
                "active_count": new_stats["active_count"],
                "old_export_size": len(old_blob),
                "new_export_size": len(new_blob),
                "old_stats": old_stats,
            }
        )

    # Preserve the entire original logical package, including old TLKs and all
    # helper exports. Only the two export-table pointers change; replacement
    # TLKs are appended, matching the base-game relocation that passed on Xbox.
    patched = bytearray(logical)
    new_offsets = []
    for blob in new_blobs:
        new_offsets.append(len(patched))
        patched += blob
    for gender in range(2):
        struct.pack_into(">ii", patched, exports[gender].start + 32, len(new_blobs[gender]), new_offsets[gender])

    if compression_type == 2:
        ranges = [(uoff, usize) for uoff, usize, _coff, _csize in source_records]
        ranges.extend((new_offsets[i], len(new_blobs[i])) for i in range(2))
        struct.pack_into(">i", patched, 121, len(ranges))
        output, built_chunks = lzo.build_multichunk_package(source_inner, bytes(patched), ranges)
        rebuilt, rebuilt_records, _rebuilt_blocks, _ = lzo.decompress_package(output)
    else:
        output = bytes(patched)
        rebuilt = output
        rebuilt_records = []
        built_chunks = []

    if rebuilt != bytes(patched):
        raise RuntimeError(f"{kind}: complete package round-trip failed")
    rebuilt_tables = tlk.parse_package_tables(rebuilt, ">")
    if rebuilt_tables["names"] != names or rebuilt_tables["import_count"] != tables["import_count"]:
        raise RuntimeError(f"{kind}: package identity changed")

    for gender in range(2):
        export = rebuilt_tables["exports"][gender]
        blob = rebuilt[export.data_offset : export.data_offset + export.data_size]
        if tlk.active_map(tlk.parse_tlk_export(blob, ">")[1]) != expected_maps[gender]:
            raise RuntimeError(f"{kind} gender {gender}: final TLK mismatch")

    helpers = []
    for index in range(2, len(exports)):
        before = exports[index]
        after = rebuilt_tables["exports"][index]
        old_blob = logical[before.data_offset : before.data_offset + before.data_size]
        new_blob = rebuilt[after.data_offset : after.data_offset + after.data_size]
        if (before.data_offset, before.data_size) != (after.data_offset, after.data_size):
            raise RuntimeError(f"{kind}: helper export moved")
        if old_blob != new_blob:
            raise RuntimeError(f"{kind}: helper export changed")
        helpers.append(
            {
                "name": names[before.name_index],
                "offset": before.data_offset,
                "size": before.data_size,
                "sha256": sha256(old_blob),
                "byte_identical": True,
            }
        )

    return output, {
        "kind": kind,
        "source_size": len(source_inner),
        "output_size": len(output),
        "source_sha256": sha256(source_inner),
        "output_sha256": sha256(output),
        "logical_size": len(rebuilt),
        "compression_type": compression_type,
        "source_chunk_count": len(source_records),
        "output_chunk_count": len(built_chunks),
        "chunk_records": rebuilt_records,
        "coverage": coverage,
        "helpers": helpers,
        "checks": [
            "original logical package retained byte-for-byte outside export pointers",
            "original cooker StringID and flag order preserved exactly",
            "replacement TLKs appended after every original export",
            "all helper exports remain at original offsets and are byte-identical",
            "both Czech TLKs pass semantic round-trip",
            "complete package compression round-trip",
        ],
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("kind", choices=("btds", "pinnacle"))
    parser.add_argument("source_container", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    package = stfs.STFS(args.source_container)
    path = BDTS_PATH if args.kind == "btds" else PINNACLE_PATH
    source_inner = package.read_file(package.entry_by_path(path))
    output, report = build_relocated(source_inner, args.kind)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_bytes(output)
    args.output.with_suffix(args.output.suffix + ".validation.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps({"output": str(args.output), "size": len(output), "sha256": sha256(output)}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
