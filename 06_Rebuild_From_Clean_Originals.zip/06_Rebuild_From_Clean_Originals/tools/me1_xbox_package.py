#!/usr/bin/env python3
"""Inspect and decompress Mass Effect 1 Xbox 360 Unreal packages."""

from __future__ import annotations

import argparse
import ctypes
import heapq
import json
import struct
from collections import Counter, deque
from dataclasses import asdict, dataclass
from pathlib import Path


PACKAGE_MAGIC = 0x9E2A83C1
CHUNK_MAGIC = -1641380927


class Reader:
    def __init__(self, data: bytes, endian: str):
        self.data = data
        self.endian = endian
        self.pos = 0

    def read(self, size: int) -> bytes:
        value = self.data[self.pos : self.pos + size]
        if len(value) != size:
            raise EOFError(f"read past end at 0x{self.pos:X}")
        self.pos += size
        return value

    def unpack(self, fmt: str):
        size = struct.calcsize(fmt)
        return struct.unpack(self.endian + fmt, self.read(size))[0]

    def i32(self) -> int:
        return self.unpack("i")

    def u32(self) -> int:
        return self.unpack("I")

    def seek(self, pos: int) -> None:
        self.pos = pos


@dataclass
class Chunk:
    uncompressed_offset: int
    uncompressed_size: int
    compressed_offset: int
    compressed_size: int


@dataclass
class Header:
    endian: str
    xenon_layout: bool
    unreal_version: int
    licensee_version: int
    full_header_size: int
    flags: int
    name_count: int
    name_offset: int
    export_count: int
    export_offset: int
    import_count: int
    import_offset: int
    compression_offset: int
    compression_type: int
    chunks: list[Chunk]


@dataclass
class ImportEntry:
    package_name: int
    class_name: int
    parent: int
    object_name: int


@dataclass
class ExportEntry:
    table_offset: int
    class_index: int
    parent: int
    object_name: int
    data_size: int
    data_offset: int
    header_size: int


@dataclass
class TlkEntry:
    string_id: int
    flags: int
    index: int
    text: str | None = None


def read_unreal_string(r: Reader) -> str:
    length = r.i32()
    if length == 0:
        return ""
    if length > 0:
        return r.read(length).rstrip(b"\0").decode("latin-1")
    raw = r.read(-length * 2)
    encoding = "utf-16-be" if r.endian == ">" else "utf-16-le"
    return raw.decode(encoding).rstrip("\0")


def parse_header(data: bytes) -> Header:
    if len(data) < 128:
        raise ValueError("package is too small")
    if struct.unpack(">I", data[:4])[0] == PACKAGE_MAGIC:
        endian = ">"
    elif struct.unpack("<I", data[:4])[0] == PACKAGE_MAGIC:
        endian = "<"
    else:
        raise ValueError("not an Unreal package")

    r = Reader(data, endian)
    r.u32()
    version_packed = r.u32()
    unreal_version = version_packed & 0xFFFF
    licensee_version = version_packed >> 16
    xenon_layout = unreal_version == 391 and licensee_version == 92
    full_header_size = r.i32()
    read_unreal_string(r)  # Folder name, normally None.
    flags = r.u32()
    name_count, name_offset = r.i32(), r.i32()
    export_count, export_offset = r.i32(), r.i32()
    import_count, import_offset = r.i32(), r.i32()

    if not xenon_layout:
        r.i32()  # dependency table offset
    r.read(16)  # Package GUID
    generation_count = r.u32()
    if generation_count:
        r.read(generation_count * 12)
    r.read(8)  # engine and cooked content versions
    r.read(16)  # ME1/2 Xenon cooker fields
    r.read(8)  # build and branch
    r.read(4)  # ME1 unknown / -1
    compression_offset = r.pos
    compression_type = r.i32()
    chunk_count = r.i32()
    chunks = [Chunk(r.i32(), r.i32(), r.i32(), r.i32()) for _ in range(chunk_count)]
    return Header(
        endian=endian,
        xenon_layout=xenon_layout,
        unreal_version=unreal_version,
        licensee_version=licensee_version,
        full_header_size=full_header_size,
        flags=flags,
        name_count=name_count,
        name_offset=name_offset,
        export_count=export_count,
        export_offset=export_offset,
        import_count=import_count,
        import_offset=import_offset,
        compression_offset=compression_offset,
        compression_type=compression_type,
        chunks=chunks,
    )


def load_compression_dll(path: Path):
    dll = ctypes.CDLL(str(path.resolve()))
    for name in ("LZODecompress", "LZXDecompress"):
        fn = getattr(dll, name)
        fn.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_void_p, ctypes.POINTER(ctypes.c_uint32)]
        fn.restype = ctypes.c_int
    dll.LZOCompress.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_void_p, ctypes.POINTER(ctypes.c_uint32)]
    dll.LZOCompress.restype = ctypes.c_int
    return dll


def native_decompress(fn, source: bytes, output_size: int) -> bytes:
    src = ctypes.create_string_buffer(source)
    dst = ctypes.create_string_buffer(output_size)
    dst_len = ctypes.c_uint32(output_size)
    result = fn(src, len(source), dst, ctypes.byref(dst_len))
    if result != 0 or dst_len.value != output_size:
        raise RuntimeError(f"decompression failed: result={result}, size={dst_len.value}/{output_size}")
    return dst.raw[:output_size]


def lzo_compress(dll, source: bytes) -> bytes:
    src = ctypes.create_string_buffer(source)
    capacity = len(source) + len(source) // 16 + 67
    dst = ctypes.create_string_buffer(capacity)
    dst_len = ctypes.c_uint32(capacity)
    result = dll.LZOCompress(src, len(source), dst, ctypes.byref(dst_len))
    if result != 0 or dst_len.value <= 0:
        raise RuntimeError(f"LZO compression failed: result={result}, size={dst_len.value}")
    return dst.raw[: dst_len.value]


def decompress_package(data: bytes, header: Header, dll_path: Path) -> bytes:
    if not header.chunks:
        return data
    if header.compression_type not in (2, 4):
        raise ValueError(f"expected Xbox LZO/LZX compression, got {header.compression_type}")
    dll = load_compression_dll(dll_path)
    fn = dll.LZODecompress if header.compression_type == 2 else dll.LZXDecompress
    first_offset = min(c.uncompressed_offset for c in header.chunks)
    output_size = max(c.uncompressed_offset + c.uncompressed_size for c in header.chunks)
    output = bytearray(output_size)
    output[:first_offset] = data[:first_offset]

    for chunk in header.chunks:
        raw = data[chunk.compressed_offset : chunk.compressed_offset + chunk.compressed_size]
        r = Reader(raw, header.endian)
        magic = r.i32()
        r.i32()  # ME1 Xenon stores the package tag in place of block size.
        compressed_size = r.i32()
        uncompressed_size = r.i32()
        if magic != CHUNK_MAGIC:
            raise ValueError(f"bad chunk magic at 0x{chunk.compressed_offset:X}")
        if (compressed_size, uncompressed_size) != (chunk.compressed_size - 16, chunk.uncompressed_size):
            # The compressed size excludes the 16-byte chunk header but includes block headers.
            if uncompressed_size != chunk.uncompressed_size:
                raise ValueError("chunk size mismatch")
        block_count = (uncompressed_size + 0x1FFFF) // 0x20000
        blocks = [(r.i32(), r.i32()) for _ in range(block_count)]
        out_pos = chunk.uncompressed_offset
        for compressed_len, uncompressed_len in blocks:
            block = r.read(compressed_len)
            decoded = native_decompress(fn, block, uncompressed_len)
            output[out_pos : out_pos + uncompressed_len] = decoded
            out_pos += uncompressed_len
        if out_pos != chunk.uncompressed_offset + chunk.uncompressed_size:
            raise ValueError("decompressed chunk length mismatch")
    return bytes(output)


def parse_names(data: bytes, header: Header) -> list[str]:
    r = Reader(data, header.endian)
    r.seek(header.name_offset)
    names = []
    for _ in range(header.name_count):
        names.append(read_unreal_string(r))
        r.read(8)
    return names


def parse_imports(data: bytes, header: Header) -> list[ImportEntry]:
    r = Reader(data, header.endian)
    r.seek(header.import_offset)
    imports = []
    for _ in range(header.import_count):
        package_name = r.i32()
        r.i32()
        class_name = r.i32()
        r.i32()
        parent = r.i32()
        object_name = r.i32()
        r.i32()
        imports.append(ImportEntry(package_name, class_name, parent, object_name))
    return imports


def parse_exports(data: bytes, header: Header) -> list[ExportEntry]:
    r = Reader(data, header.endian)
    r.seek(header.export_offset)
    exports = []
    for _ in range(header.export_count):
        start = r.pos
        class_index = r.i32()
        r.i32()  # superclass
        parent = r.i32()
        object_name = r.i32()
        r.i32()  # object name instance
        r.i32()  # archetype
        r.read(8)  # object flags
        data_size = r.i32()
        data_offset = r.i32()
        component_count = r.i32()
        r.read(component_count * 12)
        r.read(4)  # export flags
        generation_count = r.i32()
        r.read(generation_count * 4)
        r.read(16)  # package GUID
        if not header.xenon_layout:
            r.read(4)  # package flags are absent from ME1 Xenon export headers
        exports.append(ExportEntry(start, class_index, parent, object_name, data_size, data_offset, r.pos - start))
    return exports


def entry_name(index: int, names: list[str], imports: list[ImportEntry], exports: list[ExportEntry]) -> str:
    if index == 0:
        return "Class"
    if index < 0:
        return names[imports[-index - 1].object_name]
    return names[exports[index - 1].object_name]


def find_binary_start(export_data: bytes, names: list[str], endian: str) -> int:
    # BioTlkFile exports in these packages carry the standard 32-byte ME1 stack.
    r = Reader(export_data, endian)
    r.seek(32)
    while True:
        name_index = r.i32()
        r.i32()
        if names[name_index] == "None":
            return r.pos
        type_index = r.i32()
        r.i32()
        size = r.i32()
        r.i32()
        prop_type = names[type_index]
        if prop_type == "BoolProperty":
            r.read(1)
        else:
            r.read(size)


def parse_tlk(binary: bytes, endian: str) -> list[TlkEntry]:
    r = Reader(binary, endian)
    entries = [TlkEntry(r.i32(), r.i32(), r.i32()) for _ in range(r.i32())]
    nodes = []
    for _ in range(r.i32()):
        leaf = r.read(1)[0] != 0
        if leaf:
            nodes.append((True, int.from_bytes(r.read(2), "big" if endian == ">" else "little"), -1))
        else:
            nodes.append((False, r.unpack("h"), r.unpack("h")))  # right, left
    string_count = r.i32()
    encoded = r.read(len(binary) - r.pos)

    def bit(index: int) -> int:
        return (encoded[index // 8] >> (index % 8)) & 1

    strings = []
    offset = 0
    for _ in range(string_count):
        if offset + 8 > len(encoded):
            raise ValueError("truncated TLK string record")
        record_order = "big" if endian == ">" else "little"
        _character_count = int.from_bytes(encoded[offset : offset + 4], record_order, signed=True)
        encoded_length = int.from_bytes(encoded[offset + 4 : offset + 8], record_order, signed=True)
        start_bit = (offset + 8) * 8
        node = 0
        chars = []
        for bit_index in range(start_bit, (offset + 8 + encoded_length) * 8):
            is_leaf, right, left = nodes[node]
            if is_leaf:
                raise ValueError("invalid Huffman root traversal")
            node = right if bit(bit_index) else left
            is_leaf, value, _ = nodes[node]
            if is_leaf:
                if value == 0:
                    break
                chars.append(chr(value))
                node = 0
        else:
            raise ValueError("unterminated TLK string")
        strings.append("".join(chars))
        offset += 8 + encoded_length

    for entry in entries:
        if entry.flags == 1:
            if not 0 <= entry.index < len(strings):
                raise ValueError(f"bad TLK string index {entry.index}")
            entry.text = strings[entry.index]
    return entries


def convert_tlk_endian(binary: bytes, source_endian: str, target_endian: str) -> bytes:
    source = Reader(binary, source_endian)
    output = bytearray()

    def put_i32(value: int) -> None:
        output.extend(struct.pack(target_endian + "i", value))

    def put_i16(value: int) -> None:
        output.extend(struct.pack(target_endian + "h", value))

    entry_count = source.i32()
    put_i32(entry_count)
    for _ in range(entry_count):
        put_i32(source.i32())
        put_i32(source.i32())
        put_i32(source.i32())

    node_count = source.i32()
    put_i32(node_count)
    for _ in range(node_count):
        leaf = source.read(1)
        output.extend(leaf)
        if leaf != b"\0":
            char_value = int.from_bytes(source.read(2), "big" if source_endian == ">" else "little")
            output.extend(char_value.to_bytes(2, "big" if target_endian == ">" else "little"))
        else:
            put_i16(source.unpack("h"))
            put_i16(source.unpack("h"))

    string_count = source.i32()
    put_i32(string_count)
    source_order = "big" if source_endian == ">" else "little"
    target_order = "big" if target_endian == ">" else "little"
    for _ in range(string_count):
        char_count = int.from_bytes(source.read(4), source_order, signed=True)
        encoded_length = int.from_bytes(source.read(4), source_order, signed=True)
        output.extend(char_count.to_bytes(4, target_order, signed=True))
        output.extend(encoded_length.to_bytes(4, target_order, signed=True))
        output.extend(source.read(encoded_length))
    if source.pos != len(binary):
        raise ValueError(f"unparsed TLK data: {len(binary) - source.pos} bytes")
    return bytes(output)


def build_tlk(entries: list[TlkEntry], endian: str) -> bytes:
    entries = sorted(
        entries,
        key=lambda x: x.string_id if x.string_id >= 0 else x.string_id - (-2147483648),
    )
    frequency = Counter()
    for entry in entries:
        if entry.flags == 1 and entry.string_id > 0:
            frequency.update((entry.text or "") + "\0")
    if not frequency:
        raise ValueError("cannot build an empty TLK")

    # Heap nodes are (frequency, stable serial, character, left, right).
    heap = []
    serial = 0
    for char, count in sorted(frequency.items(), key=lambda item: ord(item[0])):
        heapq.heappush(heap, (count, serial, char, None, None))
        serial += 1
    while len(heap) > 1:
        left = heapq.heappop(heap)
        right = heapq.heappop(heap)
        heapq.heappush(heap, (left[0] + right[0], serial, None, left, right))
        serial += 1
    root = heap[0]

    codes: dict[str, list[int]] = {}

    def visit(node, bits: list[int]) -> None:
        if node[2] is not None:
            codes[node[2]] = bits
            return
        visit(node[3], bits + [0])
        visit(node[4], bits + [1])

    visit(root, [])

    nodes = []
    node_ids = {}
    queue = deque([root])
    while queue:
        node = queue.popleft()
        node_ids[node[1]] = len(nodes)
        nodes.append(node)
        if node[2] is None:
            # The game format stores right first, then left.
            queue.append(node[4])
            queue.append(node[3])

    order = "big" if endian == ">" else "little"
    output = bytearray(struct.pack(endian + "i", len(entries)))
    encoded_strings = []
    valid_index = 0
    for entry in entries:
        if entry.flags == 1:
            entry.index = valid_index
            valid_index += 1
            text = (entry.text or "") + "\0"
            bits = [bit for char in text for bit in codes[char]]
            encoded = bytearray((len(bits) + 7) // 8)
            for bit_index, value in enumerate(bits):
                if value:
                    encoded[bit_index // 8] |= 1 << (bit_index % 8)
            encoded_strings.append((len(text), bytes(encoded)))
        else:
            entry.index = -1 if entry.string_id > 0 else 0
        output.extend(struct.pack(endian + "iii", entry.string_id, entry.flags, entry.index))

    output.extend(struct.pack(endian + "i", len(nodes)))
    for node in nodes:
        if node[2] is not None:
            output.append(1)
            output.extend(ord(node[2]).to_bytes(2, order))
        else:
            output.append(0)
            output.extend(struct.pack(endian + "h", node_ids[node[4][1]]))
            output.extend(struct.pack(endian + "h", node_ids[node[3][1]]))

    output.extend(struct.pack(endian + "i", len(encoded_strings)))
    for char_count, encoded in encoded_strings:
        output.extend(char_count.to_bytes(4, order, signed=True))
        output.extend(len(encoded).to_bytes(4, order, signed=True))
        output.extend(encoded)
    return bytes(output)


def build_lzo_package(uncompressed: bytes, base_header: Header, dll_path: Path) -> bytes:
    dll = load_compression_dll(dll_path)
    first_offset = min(c.uncompressed_offset for c in base_header.chunks)
    chunk_ranges = []
    offset = first_offset
    while offset < len(uncompressed):
        size = min(0x100000, len(uncompressed) - offset)
        chunk_ranges.append((offset, size))
        offset += size

    compressed_chunks = []
    for uncompressed_offset, uncompressed_size in chunk_ranges:
        payload = uncompressed[uncompressed_offset : uncompressed_offset + uncompressed_size]
        blocks = []
        for block_offset in range(0, len(payload), 0x20000):
            raw_block = payload[block_offset : block_offset + 0x20000]
            compressed_block = lzo_compress(dll, raw_block)
            blocks.append((compressed_block, len(raw_block)))
        block_table = b"".join(struct.pack(">ii", len(block), raw_size) for block, raw_size in blocks)
        block_data = b"".join(block for block, _ in blocks)
        compressed_payload_size = len(block_table) + len(block_data)
        chunk_data = (
            struct.pack(">iIii", CHUNK_MAGIC, PACKAGE_MAGIC, compressed_payload_size, uncompressed_size)
            + block_table
            + block_data
        )
        compressed_chunks.append((uncompressed_offset, uncompressed_size, chunk_data))

    header_length = base_header.compression_offset + 8 + len(compressed_chunks) * 16 + 4
    compressed_offset = header_length
    table = bytearray()
    for uncompressed_offset, uncompressed_size, chunk_data in compressed_chunks:
        table.extend(struct.pack(">iiii", uncompressed_offset, uncompressed_size, compressed_offset, len(chunk_data)))
        compressed_offset += len(chunk_data)

    disk_header = bytearray(uncompressed[: base_header.compression_offset])
    disk_header.extend(struct.pack(">ii", 2, len(compressed_chunks)))
    disk_header.extend(table)
    disk_header.extend(struct.pack(">I", 0))  # package source
    if len(disk_header) != header_length:
        raise AssertionError("compressed header length mismatch")
    return bytes(disk_header) + b"".join(x[2] for x in compressed_chunks)


def build_czech_xbox_package(
    template_path: Path,
    czech_path: Path,
    dll_path: Path,
    pc_english_path: Path | None = None,
    translation_map_path: Path | None = None,
) -> tuple[bytes, dict]:
    template_raw = template_path.read_bytes()
    template_header = parse_header(template_raw)
    template = bytearray(decompress_package(template_raw, template_header, dll_path))
    template_names = parse_names(template, template_header)
    template_imports = parse_imports(template, template_header)
    template_exports = parse_exports(template, template_header)
    template_tlk_exports = [
        x
        for x in template_exports
        if entry_name(x.class_index, template_names, template_imports, template_exports) == "BioTlkFile"
    ]

    czech = czech_path.read_bytes()
    czech_header = parse_header(czech)
    if czech_header.chunks:
        czech = decompress_package(czech, czech_header, dll_path)
    czech_names = parse_names(czech, czech_header)
    czech_imports = parse_imports(czech, czech_header)
    czech_exports = parse_exports(czech, czech_header)
    czech_tlk_exports = [
        x
        for x in czech_exports
        if entry_name(x.class_index, czech_names, czech_imports, czech_exports) == "BioTlkFile"
    ]
    if len(template_tlk_exports) != 2 or len(czech_tlk_exports) != 2:
        raise ValueError("expected exactly two BioTlkFile exports in both packages")

    translation_map = {}
    if translation_map_path:
        translation_map = json.loads(translation_map_path.read_text(encoding="utf-8"))
    translation_map_first = template_path.resolve() == czech_path.resolve()

    pc_english_sets = None
    if pc_english_path:
        pc_english = pc_english_path.read_bytes()
        pc_english_header = parse_header(pc_english)
        if pc_english_header.chunks:
            pc_english = decompress_package(pc_english, pc_english_header, dll_path)
        pc_english_names = parse_names(pc_english, pc_english_header)
        pc_english_imports = parse_imports(pc_english, pc_english_header)
        pc_english_exports = parse_exports(pc_english, pc_english_header)
        pc_english_tlk_exports = [
            x
            for x in pc_english_exports
            if entry_name(x.class_index, pc_english_names, pc_english_imports, pc_english_exports) == "BioTlkFile"
        ]
        if len(pc_english_tlk_exports) != 2:
            raise ValueError("expected two BioTlkFile exports in PC English package")
        pc_english_sets = []
        for export in pc_english_tlk_exports:
            export_data = pc_english[export.data_offset : export.data_offset + export.data_size]
            binary_start = find_binary_start(export_data, pc_english_names, pc_english_header.endian)
            pc_english_sets.append(parse_tlk(export_data[binary_start:], pc_english_header.endian))

    replacements = []
    mapping_report = []
    for set_index, (template_export, czech_export) in enumerate(zip(template_tlk_exports, czech_tlk_exports)):
        template_data = bytes(template[template_export.data_offset : template_export.data_offset + template_export.data_size])
        czech_data = czech[czech_export.data_offset : czech_export.data_offset + czech_export.data_size]
        template_binary_start = find_binary_start(template_data, template_names, template_header.endian)
        czech_binary_start = find_binary_start(czech_data, czech_names, czech_header.endian)
        template_entries = parse_tlk(template_data[template_binary_start:], template_header.endian)
        czech_entries = parse_tlk(czech_data[czech_binary_start:], czech_header.endian)
        czech_by_id = {x.string_id: x.text for x in czech_entries if x.flags == 1}
        translated = 0
        translated_by_english_text = 0
        translated_by_override_map = 0
        missing = 0
        pc_text_to_czech = {}
        if pc_english_sets is not None:
            candidates: dict[str, set[str]] = {}
            for pc_entry in pc_english_sets[set_index]:
                if pc_entry.flags == 1 and pc_entry.string_id in czech_by_id:
                    candidates.setdefault(pc_entry.text or "", set()).add(czech_by_id[pc_entry.string_id] or "")
            pc_text_to_czech = {text: next(iter(values)) for text, values in candidates.items() if len(values) == 1}
        for entry in template_entries:
            if entry.flags != 1:
                continue
            original_text = entry.text or ""
            if translation_map_first and original_text in translation_map:
                entry.text = translation_map[original_text]
                translated_by_override_map += 1
            elif entry.string_id in czech_by_id:
                entry.text = czech_by_id[entry.string_id]
                translated += 1
            elif (entry.text or "") in pc_text_to_czech:
                entry.text = pc_text_to_czech[entry.text or ""]
                translated_by_english_text += 1
            elif original_text in translation_map:
                entry.text = translation_map[original_text]
                translated_by_override_map += 1
            else:
                missing += 1
        converted_binary = build_tlk(template_entries, template_header.endian)
        # Decode immediately, before package reconstruction, to verify the writer.
        rebuilt_entries = parse_tlk(converted_binary, template_header.endian)
        if [(x.string_id, x.flags, x.text) for x in rebuilt_entries] != [
            (x.string_id, x.flags, x.text) for x in sorted(
                template_entries,
                key=lambda x: x.string_id if x.string_id >= 0 else x.string_id - (-2147483648),
            )
        ]:
            raise AssertionError("TLK encode/decode round trip failed")
        replacement = template_data[:template_binary_start] + converted_binary
        replacements.append((template_export, replacement))
        mapping_report.append(
            {
                "object": template_names[template_export.object_name],
                "template_entries": len(template_entries),
                "valid_entries": sum(x.flags == 1 for x in template_entries),
                "translated": translated,
                "translated_by_pc_english_text": translated_by_english_text,
                "translated_by_override_map": translated_by_override_map,
                "kept_english_missing_in_pc_czech": missing,
            }
        )

    # Rebuild the complete serialized export area in its original order.  UE3
    # Xenon packages are sensitive to export ordering: appending replacement
    # TLKs behind the shader cache produces a package our parser can read, but
    # the retail game rejects it during startup.  Compact reconstruction keeps
    # every untouched export byte-identical while moving later exports and
    # updating their serial offsets in the export table.
    replacement_by_table_offset = {export.table_offset: data for export, data in replacements}
    ordered_exports = sorted(template_exports, key=lambda item: item.data_offset)
    first_export_offset = min(item.data_offset for item in ordered_exports)
    rebuilt = bytearray(template[:first_export_offset])
    placement = []
    for export in ordered_exports:
        export_data = replacement_by_table_offset.get(
            export.table_offset,
            bytes(template[export.data_offset : export.data_offset + export.data_size]),
        )
        new_offset = len(rebuilt)
        rebuilt.extend(export_data)
        struct.pack_into(">i", rebuilt, export.table_offset + 32, len(export_data))
        struct.pack_into(">i", rebuilt, export.table_offset + 36, new_offset)
        placement.append(
            {
                "object": template_names[export.object_name],
                "offset": new_offset,
                "size": len(export_data),
                "replaced": export.table_offset in replacement_by_table_offset,
            }
        )
    last_export_end = max(item.data_offset + item.data_size for item in ordered_exports)
    rebuilt.extend(template[last_export_end:])
    template = rebuilt

    built = (
        build_lzo_package(bytes(template), template_header, dll_path)
        if template_header.chunks
        else bytes(template)
    )
    return built, {
        "mapping": mapping_report,
        "placements": placement,
        "uncompressed_size": len(template),
        "compressed_size": len(built),
    }


def extract_tlks(data: bytes, header: Header) -> list[dict]:
    names = parse_names(data, header)
    imports = parse_imports(data, header)
    exports = parse_exports(data, header)
    result = []
    for i, export in enumerate(exports):
        if entry_name(export.class_index, names, imports, exports) != "BioTlkFile":
            continue
        export_data = data[export.data_offset : export.data_offset + export.data_size]
        binary_start = find_binary_start(export_data, names, header.endian)
        entries = parse_tlk(export_data[binary_start:], header.endian)
        valid = [x for x in entries if x.flags == 1]
        result.append(
            {
                "uindex": i + 1,
                "object": names[export.object_name],
                "binary_start": binary_start,
                "entry_count": len(entries),
                "valid_count": len(valid),
                "sample": [asdict(x) for x in valid[:8]],
            }
        )
    return result


def dump_tlks(data: bytes, header: Header) -> dict[str, list[dict]]:
    names = parse_names(data, header)
    imports = parse_imports(data, header)
    exports = parse_exports(data, header)
    result = {}
    for export in exports:
        if entry_name(export.class_index, names, imports, exports) != "BioTlkFile":
            continue
        export_data = data[export.data_offset : export.data_offset + export.data_size]
        binary_start = find_binary_start(export_data, names, header.endian)
        result[names[export.object_name]] = [asdict(x) for x in parse_tlk(export_data[binary_start:], header.endian)]
    return result


def describe_package(data: bytes, header: Header) -> dict:
    names = parse_names(data, header)
    imports = parse_imports(data, header)
    exports = parse_exports(data, header)
    return {
        "names": names,
        "imports": [
            {
                "uindex": -i - 1,
                "package": names[x.package_name],
                "class": names[x.class_name],
                "object": names[x.object_name],
                "parent": x.parent,
            }
            for i, x in enumerate(imports)
        ],
        "exports": [
            {
                **asdict(x),
                "uindex": i + 1,
                "class": entry_name(x.class_index, names, imports, exports),
                "object": names[x.object_name],
                "first_bytes": data[x.data_offset : x.data_offset + min(x.data_size, 64)].hex(),
            }
            for i, x in enumerate(exports)
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("package", type=Path)
    parser.add_argument("--dll", type=Path)
    parser.add_argument("--decompress", type=Path)
    parser.add_argument("--describe", action="store_true")
    parser.add_argument("--tlk-stats", action="store_true")
    parser.add_argument("--make-czech", type=Path, metavar="PC_CZECH_PACKAGE")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--dump-tlk-json", type=Path)
    parser.add_argument("--pc-english", type=Path)
    parser.add_argument("--translation-map", type=Path)
    args = parser.parse_args()
    if args.make_czech:
        if not args.dll or not args.output:
            parser.error("--dll and --output are required with --make-czech")
        built, build_info = build_czech_xbox_package(
            args.package,
            args.make_czech,
            args.dll,
            args.pc_english,
            args.translation_map,
        )
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_bytes(built)
        print(json.dumps(build_info, indent=2))
        return

    data = args.package.read_bytes()
    header = parse_header(data)
    result = {"header": asdict(header)}
    if args.decompress:
        if not args.dll:
            parser.error("--dll is required with --decompress")
        args.decompress.parent.mkdir(parents=True, exist_ok=True)
        data = decompress_package(data, header, args.dll)
        args.decompress.write_bytes(data)
    if args.describe:
        result["package"] = describe_package(data, header)
    if args.tlk_stats:
        result["tlks"] = extract_tlks(data, header)
    if args.dump_tlk_json:
        args.dump_tlk_json.parent.mkdir(parents=True, exist_ok=True)
        args.dump_tlk_json.write_text(
            json.dumps(dump_tlks(data, header), ensure_ascii=False, indent=2), encoding="utf-8"
        )
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
