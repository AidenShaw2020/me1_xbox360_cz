param(
    [Parameter(Mandatory=$true)][string]$GamePath,
    [Parameter(Mandatory=$true)][string]$PcCzechPath,
    [Parameter(Mandatory=$true)][string]$BDtSContainer,
    [Parameter(Mandatory=$true)][string]$PinnacleContainer,
    [string]$OutputPath = ""
)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
$Patcher = Join-Path $Root "work\me1_patcher_v2\ME1_X360_CZ_Patcher_Source_v2"
$Recipes = Join-Path $Root "recipes"
if ([string]::IsNullOrWhiteSpace($OutputPath)) {
    $OutputPath = Join-Path $Root "rebuilt_output"
}

foreach ($Path in @($GamePath, $PcCzechPath, $BDtSContainer, $PinnacleContainer)) {
    if (-not (Test-Path -LiteralPath $Path)) { throw "Vstup neexistuje: $Path" }
}
$Python = Get-Command python -ErrorAction SilentlyContinue
if (-not $Python) { $Python = Get-Command py -ErrorAction SilentlyContinue }
if (-not $Python) { throw "Nebyl nalezen Python 3 (python.exe ani py.exe)." }
$Py = $Python.Source
$env:ME1_LZO_LIBRARY = Join-Path $Root "work\minilzo-2.10\lzo2.dll"
if (-not (Test-Path -LiteralPath $env:ME1_LZO_LIBRARY -PathType Leaf)) {
    throw "Chybi pribaleny LZO runtime: $env:ME1_LZO_LIBRARY"
}

$GamePath = (Resolve-Path -LiteralPath $GamePath).Path
$PcCzechPath = (Resolve-Path -LiteralPath $PcCzechPath).Path
$BDtSContainer = (Resolve-Path -LiteralPath $BDtSContainer).Path
$PinnacleContainer = (Resolve-Path -LiteralPath $PinnacleContainer).Path
$OutputPath = [IO.Path]::GetFullPath($OutputPath)
New-Item -ItemType Directory -Force -Path $OutputPath | Out-Null

function Run-Python([string[]]$Arguments) {
    & $Py @Arguments
    if ($LASTEXITCODE -ne 0) { throw "Konverzní krok selhal (exit code $LASTEXITCODE)." }
}

Write-Host "1/6 Globální texty základní hry"
$BaseOut = Join-Path $OutputPath "01_Base_Game_CZ\GameFiles"
$GlobalOut = Join-Path $BaseOut "Layer0\MEInit\GlobalTlk.xxx"
New-Item -ItemType Directory -Force -Path (Split-Path -Parent $GlobalOut) | Out-Null
Run-Python @(
    (Join-Path $Patcher "patch_base.py"),
    (Join-Path $GamePath "Layer0\MEInit\GlobalTlk.xxx"),
    "--output", $GlobalOut,
    "--strict-tested-hash"
)

Write-Host "2/6 Dialogy, dialogové volby, meziscény a hlášky základní hry"
Run-Python @(
    (Join-Path $PSScriptRoot "build_me1_base_dialog_patchset_local.py"),
    $GamePath, $PcCzechPath, (Join-Path $OutputPath "01_Base_Game_CZ"),
    (Join-Path $Recipes "base_dialogs_deployment_manifest.json"),
    (Join-Path $Recipes "base_cinematics_deployment_manifest.json"),
    "--donor-global-cs", (Join-Path $Patcher "assets\GlobalTlk_CS.upk")
)

Write-Host "3/6 Globální texty DLC"
$WorkOut = Join-Path $OutputPath "_build"
New-Item -ItemType Directory -Force -Path $WorkOut | Out-Null
$BDtSGlobal = Join-Path $WorkOut "DLC_UNC_GlobalTlk.xxx"
$PinnacleGlobal = Join-Path $WorkOut "DLC_Vegas_GlobalTlk.xxx"
Run-Python @((Join-Path $PSScriptRoot "build_me1_dlc_globals_relocated.py"), "btds", $BDtSContainer, $BDtSGlobal)
Run-Python @((Join-Path $PSScriptRoot "build_me1_dlc_globals_relocated.py"), "pinnacle", $PinnacleContainer, $PinnacleGlobal)

Write-Host "4/6 Dialogy Strhnout oblohu"
$BDtSSwap = Join-Path $WorkOut "btds_swap"
$BDtSAppend = Join-Path $WorkOut "btds_append"
Run-Python @((Join-Path $PSScriptRoot "build_me1_dlc_dialog_patchset.py"), $BDtSContainer, $PcCzechPath, $BDtSSwap, "--mode", "swap-any")
Run-Python @((Join-Path $PSScriptRoot "build_me1_dlc_dialog_patchset.py"), $BDtSContainer, $PcCzechPath, $BDtSAppend, "--mode", "append")

Write-Host "5/6 Dialogy Stanice Pinnacle"
$PinnacleLocal = Join-Path $WorkOut "pinnacle_local"
Run-Python @(
    (Join-Path $PSScriptRoot "build_me1_pinnacle_dialog_patchset.py"),
    $PinnacleContainer,
    (Join-Path $Patcher "assets\DLC_Vegas_translation_cs.json"),
    $PinnacleLocal,
    "--donor-root", $PcCzechPath,
    "--mode", "append-zero-old"
)

Write-Host "6/6 Nové ověřené STFS kontejnery DLC"
Run-Python @(
    (Join-Path $PSScriptRoot "rebuild_me1_dlc_complete_fresh.py"),
    "btds", $BDtSContainer, $BDtSGlobal,
    (Join-Path $OutputPath "02_Bring_Down_the_Sky_CZ"),
    $BDtSSwap, $BDtSAppend
)
Run-Python @(
    (Join-Path $PSScriptRoot "rebuild_me1_dlc_complete_fresh.py"),
    "pinnacle", $PinnacleContainer, $PinnacleGlobal,
    (Join-Path $OutputPath "03_Pinnacle_Station_CZ"),
    $PinnacleLocal
)

Write-Host ""
Write-Host "HOTOVO: $OutputPath"
Write-Host "Vstupní soubory nebyly změněny. Výstup vznikl v novém adresáři."
