#!/usr/bin/env python3
"""Build validated Czech local Pinnacle TLKs using minimal PC-cooker donor trees."""

from __future__ import annotations

import argparse
import copy
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PATCHER = ROOT / "work" / "me1_patcher_v2" / "ME1_X360_CZ_Patcher_Source_v2"
sys.path.insert(0, str(PATCHER))
from me1lib import lzo_ue3 as lzo, stfs  # noqa: E402
import patch_me1_map_dialogs as patcher  # noqa: E402
from patch_me1_fallback_dialog import build_with_donor_tree, donor_nodes  # noqa: E402


OVERRIDES = {
    "Not now, Shepard!": "Teď ne!",
    "Take out those hostiles!": "Zlikvidujte ty nepřátele!",
    "Not now, Commander!": "Teď ne!",
    "Now is not the time!": "Teď není vhodná chvíle!",
    "I'm a little busy here!": "Mám teď trochu napilno!",
    "Not in the middle of a fight!": "Ne uprostřed boje!",
    "We are in the middle of a fight!": "Jsme uprostřed boje!",
    "Why would you accept a position on a turian facility if you hate them so much?": (
        "Proč pracujete v turianském zařízení, když Turiany tolik nenávidíte?"
    ),
}


def donor_catalog(roots: list[Path]):
    catalog = []
    seen = set()
    for root in roots:
        for path in root.rglob("*.upk"):
            if path.resolve() in seen:
                continue
            seen.add(path.resolve())
            try:
                data = path.read_bytes()
                header = patcher.ue3.parse_header(data)
                if header.chunks:
                    continue
                names, _imports, _exports, tlks = patcher.bio_tlk_exports(data, header)
                for _index, exp, obj in tlks:
                    lowered = obj.casefold()
                    if lowered not in {
                        "tlk_cs",
                        "tlk_m_cs",
                        "globaltlk_tlk",
                        "globaltlk_tlk_m",
                    }:
                        continue
                    blob = data[exp.data_offset : exp.data_offset + exp.data_size]
                    prefix_len = patcher.ue3.find_binary_start(blob, names, "<")
                    binary = blob[prefix_len:]
                    nodes = donor_nodes(binary, "<")
                    charset = {chr(right) for leaf, right, _left in nodes if leaf}
                    catalog.append(
                        {
                            "path": str(path),
                            "object": obj,
                            "male": "_m" in lowered,
                            "nodes": len(nodes),
                            "charset": charset,
                            "binary": binary,
                        }
                    )
            except Exception:
                continue
    if not catalog:
        raise RuntimeError("No PC Czech donor TLKs found")
    return catalog


def choose_donor(catalog, required: set[str], male: bool):
    candidates = [
        item for item in catalog if required <= item["charset"] and item["male"] == male
    ]
    if not candidates:
        candidates = [item for item in catalog if required <= item["charset"]]
    if not candidates:
        raise RuntimeError(f"No donor tree covers characters: {sorted(required)}")
    return min(candidates, key=lambda item: (item["nodes"], len(item["binary"])))


def prepare_synthetic_sources(
    source_path: Path,
    synthetic_root: Path,
    translations: dict[str, str],
    catalog,
    root_package_name: str,
):
    raw = source_path.read_bytes()
    header = patcher.ue3.parse_header(raw)
    logical = raw if not header.chunks else lzo.decompress_package(raw)[0]
    header = patcher.ue3.parse_header(logical)
    names, _imports, exports, tlks = patcher.bio_tlk_exports(logical, header)
    index = patcher._PC_INDEX_CACHE.setdefault(synthetic_root.resolve(), {})
    donors_used = []
    for _export_index, exp, obj in tlks:
        lowered = obj.casefold()
        if lowered not in {"tlk", "tlk_m"}:
            continue
        parent = (
            names[exports[exp.parent - 1].object_name]
            if exp.parent > 0
            else root_package_name
        )
        male = lowered == "tlk_m"
        _prefix, entries = patcher.parse_export_tlk(logical, exp, names, header.endian)
        translated = copy.deepcopy(entries)
        missing = []
        for item in translated:
            if item.flags != 1:
                continue
            english = item.text or ""
            if english.strip() == "":
                continue
            if english not in translations:
                missing.append((item.string_id, english))
            else:
                item.text = translations[english]
        if missing:
            raise RuntimeError(f"{parent}/{obj}: missing translations {missing[:5]}")
        required = set("".join((item.text or "") + "\0" for item in translated if item.flags == 1))
        donor = choose_donor(catalog, required, male)
        binary = build_with_donor_tree(translated, donor["binary"], "<", "<")
        decoded = patcher.ue3.parse_tlk(binary, "<")
        if {item.string_id: item.text for item in decoded if item.flags == 1} != {
            item.string_id: item.text for item in translated if item.flags == 1
        }:
            raise RuntimeError(f"{parent}/{obj}: donor-tree round trip mismatch")
        fake = synthetic_root / f"{parent}.upk"
        index[parent.casefold()] = fake
        patcher._PC_TLK_CACHE[(fake.resolve(), male)] = (translated, binary)
        donors_used.append(
            {
                "parent": parent,
                "object": obj,
                "donor": donor["path"],
                "donor_object": donor["object"],
                "donor_nodes": donor["nodes"],
            }
        )
    return donors_used


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("container", type=Path)
    parser.add_argument("translations", type=Path)
    parser.add_argument("output_root", type=Path)
    parser.add_argument("--donor-root", type=Path, action="append", required=True)
    parser.add_argument(
        "--mode", choices=["append", "append-zero-old", "swap-any"], default="append"
    )
    args = parser.parse_args()
    translations = json.loads(args.translations.read_text(encoding="utf-8"))
    translations.update(OVERRIDES)
    catalog = donor_catalog(args.donor_root)
    print(f"Czech cooker donor TLKs: {len(catalog)}", flush=True)
    package = stfs.STFS(args.container)
    synthetic_root = args.output_root / "synthetic"
    candidates = [
        entry
        for entry in package.entries
        if not entry.is_dir
        and entry.path.lower().endswith(".xxx")
        and "globaltlk" not in entry.path.lower()
        and "/localised/" not in entry.path.lower()
    ]
    report = {"patched": [], "failed": [], "skipped": [], "donor_catalog_size": len(catalog)}
    temp = args.output_root / "_current.xxx"
    args.output_root.mkdir(parents=True, exist_ok=True)
    for number, entry in enumerate(candidates, 1):
        source = package.read_file(entry)
        temp.write_bytes(source)
        try:
            root_name = Path(entry.path).stem
            donors = prepare_synthetic_sources(
                temp, synthetic_root, translations, catalog, root_name
            )
            if not donors:
                report["skipped"].append(entry.path)
                continue
            output, validation = patcher.patch_map(
                temp,
                synthetic_root,
                slot="int",
                mode=args.mode,
                backend="minilzo-selective",
                encoding="pc-raw",
                root_package_name=root_name,
            )
        except Exception as exc:
            report["failed"].append({"path": entry.path, "error": str(exc)})
            print(f"[{number}/{len(candidates)}] FAILED {entry.path}: {exc}", flush=True)
            continue
        relative = Path(entry.path)
        original_path = args.output_root / "originals" / relative
        patched_path = args.output_root / "patched" / relative
        original_path.parent.mkdir(parents=True, exist_ok=True)
        patched_path.parent.mkdir(parents=True, exist_ok=True)
        original_path.write_bytes(source)
        patched_path.write_bytes(output)
        required = (len(output) + stfs.SECTOR - 1) // stfs.SECTOR
        item = {
            "path": entry.path,
            "source_size": len(source),
            "output_size": len(output),
            "allocated_blocks": entry.alloc_blocks,
            "required_blocks": required,
            "fits_existing_allocation": required <= entry.alloc_blocks,
            "target_count": len(validation["targets"]),
            "translated_active_strings": sum(
                target["coverage"]["translated"] for target in validation["targets"]
            ),
            "donors": donors,
        }
        report["patched"].append(item)
        patched_path.with_suffix(patched_path.suffix + ".validation.json").write_text(
            json.dumps(validation, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        print(
            f"[{number}/{len(candidates)}] PATCHED {entry.path}: "
            f"{item['target_count']} TLK fits={item['fits_existing_allocation']}",
            flush=True,
        )
    temp.unlink(missing_ok=True)
    report["summary"] = {
        "patched_files": len(report["patched"]),
        "patched_tlks": sum(item["target_count"] for item in report["patched"]),
        "translated_active_strings": sum(
            item["translated_active_strings"] for item in report["patched"]
        ),
        "failed_files": len(report["failed"]),
        "files_exceeding_allocation": sum(
            not item["fits_existing_allocation"] for item in report["patched"]
        ),
    }
    (args.output_root / "build_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(report["summary"], ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
