#!/usr/bin/env python3
"""Rebuild the tested ME1 base-game local TLKs from a clean local Xbox tree."""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path

from patch_me1_map_dialogs import patch_map


FALLBACK = "Layer0/Maps/BIOA_LAV60_03_DSG.xxx"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(4 * 1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def load_recipes(paths: list[Path]) -> list[dict]:
    recipes: dict[str, dict] = {}
    for path in paths:
        data = json.loads(path.read_text(encoding="utf-8"))
        for item in data["deployed"]:
            previous = recipes.get(item["path"])
            if previous is not None and previous != item:
                raise RuntimeError(f"Conflicting recipe for {item['path']}")
            recipes[item["path"]] = item
    return [recipes[key] for key in sorted(recipes)]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("game_root", type=Path)
    parser.add_argument("pc_czech_root", type=Path)
    parser.add_argument("output_root", type=Path)
    parser.add_argument("recipes", nargs="+", type=Path)
    parser.add_argument("--donor-global-cs", type=Path, required=True)
    args = parser.parse_args()

    game_root = args.game_root.resolve()
    pc_root = args.pc_czech_root.resolve()
    output_root = args.output_root.resolve()
    output_root.mkdir(parents=True, exist_ok=True)
    recipes = load_recipes(args.recipes)
    report = {"game_root": str(game_root), "files": [], "failures": []}

    for index, item in enumerate(recipes, 1):
        relative = item["path"]
        source = game_root / Path(relative)
        target = output_root / "GameFiles" / Path(relative)
        validation_path = target.with_suffix(target.suffix + ".validation.json")
        print(f"[{index}/{len(recipes)}] {relative}", flush=True)
        try:
            if not source.is_file():
                raise RuntimeError("source file is missing")
            found_source_hash = sha256(source)
            if source.stat().st_size != item["original_size"] or found_source_hash != item["original_sha256"]:
                raise RuntimeError(
                    f"unsupported source (size={source.stat().st_size}, sha256={found_source_hash})"
                )
            target.parent.mkdir(parents=True, exist_ok=True)
            if relative == FALLBACK:
                command = [
                    sys.executable,
                    str(Path(__file__).with_name("patch_me1_fallback_dialog.py")),
                    str(source),
                    str(pc_root),
                    str(args.donor_global_cs.resolve()),
                    str(target),
                ]
                subprocess.run(command, check=True)
            else:
                output, validation = patch_map(
                    source,
                    pc_root,
                    slot="int",
                    mode="append",
                    backend="minilzo-selective",
                    encoding="pc-raw",
                )
                target.write_bytes(output)
                validation_path.write_text(
                    json.dumps(validation, ensure_ascii=False, indent=2), encoding="utf-8"
                )
            found_output_hash = sha256(target)
            if target.stat().st_size != item["patched_size"] or found_output_hash != item["patched_sha256"]:
                raise RuntimeError(
                    f"output differs from hardware-tested reference "
                    f"(size={target.stat().st_size}, sha256={found_output_hash})"
                )
            report["files"].append(
                {"path": relative, "sha256": found_output_hash, "status": "PASS"}
            )
        except Exception as exc:
            report["failures"].append({"path": relative, "error": str(exc)})
            (output_root / "rebuild_report.json").write_text(
                json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            raise

    report["summary"] = {
        "expected_files": len(recipes),
        "rebuilt_files": len(report["files"]),
        "failures": len(report["failures"]),
        "all_exact_hardware_reference_matches": not report["failures"],
    }
    (output_root / "rebuild_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(report["summary"], ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
