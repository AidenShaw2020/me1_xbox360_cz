#!/usr/bin/env python3
"""Extract, patch and validate local dialog packages from an ME1 STFS DLC."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PATCHER = ROOT / "work" / "me1_patcher_v2" / "ME1_X360_CZ_Patcher_Source_v2"
sys.path.insert(0, str(PATCHER))

from me1lib import stfs  # noqa: E402
import patch_me1_map_dialogs as patcher  # noqa: E402


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("container", type=Path)
    parser.add_argument("pc_dialog_root", type=Path)
    parser.add_argument("output_root", type=Path)
    parser.add_argument("--base-dialog-root", type=Path)
    parser.add_argument(
        "--mode",
        choices=["append", "append-zero-old", "swap-pl", "swap-any"],
        default="append",
    )
    args = parser.parse_args()
    package = stfs.STFS(args.container)
    candidates = [
        entry
        for entry in package.entries
        if not entry.is_dir
        and entry.path.lower().endswith(".xxx")
        and "globaltlk" not in entry.path.lower()
    ]
    roots = [args.pc_dialog_root]
    if args.base_dialog_root:
        roots.append(args.base_dialog_root)
    combined = {}
    for root in reversed(roots):
        for path in root.resolve().rglob("*.upk"):
            combined[path.stem.casefold()] = path
    patcher._PC_INDEX_CACHE[args.pc_dialog_root.resolve()] = combined
    args.output_root.mkdir(parents=True, exist_ok=True)
    temp = args.output_root / "_current.xxx"
    report = {"container": str(args.container), "candidates": len(candidates), "patched": [], "skipped": [], "failed": []}
    for number, entry in enumerate(candidates, 1):
        print(f"[{number}/{len(candidates)}] {entry.path}", flush=True)
        source = package.read_file(entry)
        temp.write_bytes(source)
        try:
            output, validation = patcher.patch_map(
                temp,
                args.pc_dialog_root,
                slot="int",
                mode=args.mode,
                backend="minilzo-selective",
                encoding="pc-raw",
            )
        except (RuntimeError, ValueError) as exc:
            message = str(exc)
            if message.startswith("No tlk_PL/tlk_M_PL exports found"):
                report["skipped"].append(entry.path)
                continue
            report["failed"].append({"path": entry.path, "error": message})
            print(f"  FAILED: {message}", flush=True)
            continue
        relative = Path(entry.path)
        original_path = args.output_root / "originals" / relative
        patched_path = args.output_root / "patched" / relative
        original_path.parent.mkdir(parents=True, exist_ok=True)
        patched_path.parent.mkdir(parents=True, exist_ok=True)
        original_path.write_bytes(source)
        patched_path.write_bytes(output)
        patched_path.with_suffix(patched_path.suffix + ".validation.json").write_text(
            json.dumps(validation, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        required = (len(output) + stfs.SECTOR - 1) // stfs.SECTOR
        item = {
            "path": entry.path,
            "entry_id": entry.id,
            "source_size": len(source),
            "output_size": len(output),
            "allocated_blocks": entry.alloc_blocks,
            "required_blocks": required,
            "fits_existing_allocation": required <= entry.alloc_blocks,
            "target_count": len(validation["targets"]),
            "translated_active_strings": sum(target["coverage"]["translated"] for target in validation["targets"]),
        }
        report["patched"].append(item)
        print(f"  PATCHED: {item['target_count']} TLK, fits={item['fits_existing_allocation']}", flush=True)
    temp.unlink(missing_ok=True)
    report["summary"] = {
        "patched_files": len(report["patched"]),
        "patched_tlks": sum(item["target_count"] for item in report["patched"]),
        "translated_active_strings": sum(item["translated_active_strings"] for item in report["patched"]),
        "failed_files": len(report["failed"]),
        "files_exceeding_allocation": sum(not item["fits_existing_allocation"] for item in report["patched"]),
    }
    (args.output_root / "build_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(report["summary"], ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
