#!/usr/bin/env python3
"""Patch the one PC package that lacks tlk_CS using a cooker-made Czech donor tree."""

from __future__ import annotations

import argparse
import copy
import json
import struct
from pathlib import Path

import patch_me1_map_dialogs as patcher
from patch_me1_map_dialogs import (
    bio_tlk_exports,
    parse_export_tlk,
    ue3,
)


TRANSLATIONS = {
    15974: "Nemyslím, že bychom tu pevnost zvládli dobýt čelním útokem.",
    15970: "Jen hlupák udeří nathaka do tlamy. Měli bychom se proplížit kolem a zatahat ho za ocas.",
    15975: "Poručík má pravdu. Měli bychom je obejít a zkusit napadnout z boku.",
    15976: "Dobývat hlavní vchod je hloupost. Možná najdeme boční cestu.",
    15971: "Tudy to nepůjde. Mají výškovou převahu a krytí.",
    15972: "Velitel má pravdu. V tomhle terénu se jim můžeme vkrást do boku.",
}


def donor_nodes(binary: bytes, endian: str):
    reader = ue3.Reader(binary, endian)
    entry_count = reader.i32()
    reader.read(entry_count * 12)
    count = reader.i32()
    nodes = []
    for _ in range(count):
        leaf = reader.read(1)[0] != 0
        if leaf:
            value = int.from_bytes(
                reader.read(2), "big" if endian == ">" else "little"
            )
            nodes.append((True, value, -1))
        else:
            nodes.append((False, reader.unpack("h"), reader.unpack("h")))
    return nodes


def build_with_donor_tree(entries, donor_binary: bytes, donor_endian: str, target_endian: str):
    nodes = donor_nodes(donor_binary, donor_endian)
    codes = {}

    def visit(index: int, bits: list[int]):
        leaf, right, left = nodes[index]
        if leaf:
            codes[chr(right)] = bits
        else:
            visit(right, bits + [1])
            visit(left, bits + [0])

    visit(0, [])
    entries = sorted(
        copy.deepcopy(entries),
        key=lambda item: item.string_id
        if item.string_id >= 0
        else item.string_id - (-2147483648),
    )
    output = bytearray(struct.pack(target_endian + "i", len(entries)))
    strings = []
    index = 0
    for entry in entries:
        if entry.flags == 1:
            entry.index = index
            index += 1
            text = (entry.text or "") + "\0"
            missing = sorted(set(text) - set(codes))
            if missing:
                raise RuntimeError(f"Donor tree lacks characters: {missing}")
            bits = [bit for char in text for bit in codes[char]]
            encoded = bytearray((len(bits) + 7) // 8)
            for bit_index, value in enumerate(bits):
                if value:
                    encoded[bit_index // 8] |= 1 << (bit_index % 8)
            strings.append((len(text), bytes(encoded)))
        else:
            entry.index = -1 if entry.string_id > 0 else 0
        output += struct.pack(
            target_endian + "iii", entry.string_id, entry.flags, entry.index
        )

    output += struct.pack(target_endian + "i", len(nodes))
    target_order = "big" if target_endian == ">" else "little"
    for leaf, right, left in nodes:
        if leaf:
            output.append(1)
            output += right.to_bytes(2, target_order)
        else:
            output.append(0)
            output += struct.pack(target_endian + "hh", right, left)
    output += struct.pack(target_endian + "i", len(strings))
    for char_count, encoded in strings:
        output += struct.pack(target_endian + "ii", char_count, len(encoded))
        output += encoded
    return bytes(output)


def load_global_donors(path: Path):
    data = path.read_bytes()
    header = ue3.parse_header(data)
    names, _imports, _exports, tlks = bio_tlk_exports(data, header)
    result = {}
    for _index, exp, obj in tlks:
        if obj in {"GlobalTlk_tlk", "GlobalTlk_tlk_M"}:
            blob = data[exp.data_offset : exp.data_offset + exp.data_size]
            prefix_len = ue3.find_binary_start(blob, names, "<")
            result[obj.endswith("_M")] = blob[prefix_len:]
    if set(result) != {False, True}:
        raise RuntimeError("Czech global donor lacks female/male TLKs")
    return result


def load_english_entries(path: Path, male: bool):
    data = path.read_bytes()
    header = ue3.parse_header(data)
    names, _imports, _exports, tlks = bio_tlk_exports(data, header)
    wanted = "tlk_M" if male else "tlk"
    matches = [(exp, obj) for _index, exp, obj in tlks if obj == wanted]
    if len(matches) != 1:
        raise RuntimeError(f"Expected one English {wanted} in {path}")
    exp, _obj = matches[0]
    _prefix, entries = parse_export_tlk(data, exp, names, "<")
    return entries


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("pc_dialog_root", type=Path)
    parser.add_argument("donor_global_cs", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--build-report", type=Path)
    args = parser.parse_args()
    package_name = "lav60_trig02_base_fallback_D"
    pc_path = patcher.locate_pc_package(args.pc_dialog_root, package_name)
    donors = load_global_donors(args.donor_global_cs)
    translation_ids = set(TRANSLATIONS)
    for male in (False, True):
        entries = load_english_entries(pc_path, male)
        active_ids = {entry.string_id for entry in entries if entry.flags == 1}
        if active_ids != translation_ids:
            raise RuntimeError(
                f"Fallback ID set differs: {sorted(active_ids)} != {sorted(translation_ids)}"
            )
        for entry in entries:
            if entry.flags == 1:
                entry.text = TRANSLATIONS[entry.string_id]
        binary = build_with_donor_tree(entries, donors[male], "<", "<")
        decoded = ue3.parse_tlk(binary, "<")
        if {entry.string_id: entry.text for entry in decoded if entry.flags == 1} != {
            entry.string_id: entry.text for entry in entries if entry.flags == 1
        }:
            raise RuntimeError("Donor-tree encode/decode mismatch")
        patcher._PC_TLK_CACHE[(pc_path.resolve(), male)] = (entries, binary)

    output, report = patcher.patch_map(
        args.source,
        args.pc_dialog_root,
        slot="int",
        mode="append",
        backend="minilzo-selective",
        encoding="pc-raw",
        package_filter={package_name.casefold()},
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_bytes(output)
    report_path = args.output.with_suffix(args.output.suffix + ".validation.json")
    report_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    if args.build_report:
        build_report = json.loads(args.build_report.read_text(encoding="utf-8"))
        relative = "Layer0/Maps/BIOA_LAV60_03_DSG.xxx"
        build_report["failed"] = [
            item for item in build_report["failed"] if item["path"] != relative
        ]
        build_report["patched"] = [
            item for item in build_report["patched"] if item["path"] != relative
        ]
        build_report["patched"].append(
            {
                "path": relative,
                "source_size": args.source.stat().st_size,
                "output_size": len(output),
                "target_count": len(report["targets"]),
                "translated_active_strings": sum(
                    target["coverage"]["translated"] for target in report["targets"]
                ),
                "new_chunks": report["output_chunks"] - report["original_chunks"],
                "recompressed_original_blocks": len(
                    report["selectively_recompressed_blocks"]
                ),
                "manual_czech_donor_tree": True,
            }
        )
        build_report["summary"] = {
            "patched_files": len(build_report["patched"]),
            "patched_tlks": sum(item["target_count"] for item in build_report["patched"]),
            "translated_active_strings": sum(
                item["translated_active_strings"] for item in build_report["patched"]
            ),
            "failed_files": len(build_report["failed"]),
        }
        args.build_report.write_text(
            json.dumps(build_report, ensure_ascii=False, indent=2), encoding="utf-8"
        )
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
