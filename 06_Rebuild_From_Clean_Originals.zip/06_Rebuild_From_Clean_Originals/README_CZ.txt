﻿Nova konverze z cistych originalu
==================================

Tato cast neinstaluje predem hotove soubory. Znovu vytvori ceske soubory
z ciste Xbox 360 hry, pocestene PC instalace a obou originalnich DLC.

Vstupy:
- koren ciste Xbox 360 verze Mass Effect 1 (Title ID 4D5307E8, Media ID 572BA75D),
- koren pocestene PC instalace Mass Effect 1,
- originalni funkcni STFS kontejner Bring Down the Sky,
- originalni funkcni STFS kontejner Pinnacle Station.

Spusteni:
1. Nainstalujte 64bitovy Python 3 a ponechte jej v PATH.
2. Spustte Rebuild_ME1_CZ_From_Clean.bat.
3. Zadejte vsechny ctyri vstupni cesty.

Hlavni skript:
tools\Rebuild_ME1_CZ_From_Clean.ps1

Vystup se uklada do noveho adresare rebuilt_output. Originaly se nemeni.
Kazdy soubor zakladni hry se porovnava s presnym vstupnim hashem a novy
vysledek s hardwarove testovanou referenci. STFS kontejnery se po sestaveni
kompletne prepocitaji a overi.

Poznamka: kompletni nove sestaveni zpracovava 297 velkych mapovych balicku,
proto vyzaduje dostatek volneho mista a muze trvat dlouho.
